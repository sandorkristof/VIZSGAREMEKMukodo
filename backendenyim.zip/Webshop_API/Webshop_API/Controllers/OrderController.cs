﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Webshop_API.Dtos;
using Webshop_API.Models;

namespace Webshop_API.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        [HttpGet("getAktivRendeles")]
        public ActionResult<OrderDto> GetActiveOrder(Guid userId) 
        {
            try
            {
                using(var dbContext = new MesaWebshopContext())
                {
                    var existing = dbContext.Rendeles.FirstOrDefault(x => x.FelhaszId == userId && x.Allapot < 4);
                    if (existing != null)
                    {
                        var orderedItems = dbContext.RendeltElem.Where(x => x.RendelesId == existing.Id).ToList();
                        List<OrderedItemDto> itemDtos = new List<OrderedItemDto>();
                        foreach (var item in orderedItems)
                        {
                            var product = dbContext.Termek.FirstOrDefault(x => x.Id == item.TermekId);
                            var placeholder = new OrderedItemDto(item.Id, product.Foto, product.Nev, product.Ar, item.TermekDarab);
                            itemDtos.Add(placeholder);
                        }

                        var address = dbContext.FelhasznaloCim.FirstOrDefault(x => x.FelhaszId == userId && x.Id == existing.Cim);
                        if (address.EmeletAjto == null)
                        {
                            address.EmeletAjto = " ";
                        }
                        AddressDto addressDto = new AddressDto(
                            address.Id,
                            address.FelhaszId,
                            address.Irsz,
                            address.Telepules,
                            address.Utca,
                            address.Hazszam,
                            address.EmeletAjto
                            );

                        OrderDto result = new OrderDto(
                            existing.Id,
                            existing.FelhaszId,
                            existing.Datum,
                            addressDto,
                            existing.Vegosszeg,
                            Extensions.StringifyState(existing.Allapot),
                            itemDtos
                            );

                        return Ok(result);
                    }
                    else
                    {
                        return NotFound("Nem található aktív rendelés!");
                    }
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("postRendeles")]
        public ActionResult CreateOrder(CreateOrderDto createOrderDto)
        {
            try
            {
                using(var dbContext = new MesaWebshopContext())
                {
                    var orderId = Guid.NewGuid();
                    int cost = 0;
                    var newOrder = new Rendeles()
                    {
                        Id = orderId,
                        FelhaszId = createOrderDto.UserId,
                        Datum = DateTime.Now,
                        Cim = createOrderDto.AddressId,
                        Vegosszeg = 0
                    };

                    dbContext.Rendeles.Add(newOrder);

                    foreach (var item in createOrderDto.orderedItems)
                    {
                        var orderedItem = new RendeltElem()
                        {
                            Id = Guid.NewGuid(),
                            RendelesId = orderId,
                            TermekId = item.ProductId,
                            TermekDarab = item.Quantity,
                        };
                        cost += item.ProductPrice;

                        dbContext.RendeltElem.Add(orderedItem);
                    }
                    newOrder.Vegosszeg += cost;
                    dbContext.Rendeles.Update(newOrder);
                    dbContext.SaveChanges();

                    return Ok("Sikeres rendelés!");
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
