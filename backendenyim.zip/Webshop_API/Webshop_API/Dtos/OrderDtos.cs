﻿using Webshop_API.Dtos;

namespace Webshop_API.Dtos
{
    public record OrderDto(Guid Id, Guid UserId, DateTime OrderDate, AddressDto Address, int Cost, string OrderState, List<OrderedItemDto> ordereditems);
    public record OrderedItemDto(Guid ProductId, byte[] Photo, string ProductName, int ProductPrice, int Quantity);
    public record CreateOrderDto(Guid UserId, Guid AddressId, List<OrderedItemDto> orderedItems);
}
