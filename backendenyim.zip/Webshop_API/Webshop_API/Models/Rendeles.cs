﻿using System;
using System.Collections.Generic;

namespace Webshop_API.Models;

public partial class Rendeles
{
    public Guid Id { get; set; }

    public Guid FelhaszId { get; set; }

    public DateTime Datum { get; set; }

    public Guid Cim { get; set; }

    public int Vegosszeg { get; set; }

    public int Allapot { get; set; }

    public virtual RendelesAllapot AllapotNavigation { get; set; } = null!;

    public virtual Felhasznalo FelhasznaloId { get; set; } = null!;

    public virtual FelhasznaloCim CimNavigation { get; set; } = null!;
}
