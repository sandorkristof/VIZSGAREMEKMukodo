﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace WebshopKarbantarto.Dtos
{
    public class OrderDto
    {
        public Guid Id { get; set; }
        public Guid UserId { get; set; }
        public string OrderDate { get; set; }
        public string Address { get; set; }
        public int Cost { get; set; }
        public string OrderState { get; set; }
        public List<OrderedItemDto> OrderedItems { get; set; }

        public OrderDto(Guid id, Guid userId, string orderdate, string address, int cost, string orderState, List<OrderedItemDto> orderedItems)
        {
            Id = id;
            UserId = userId;
            OrderDate = orderdate;
            Address = address;
            Cost = cost;
            OrderState = orderState;
            OrderedItems = orderedItems;
        }
    }

    public record UpdateOrderDto(Guid Id, int OrderState);
    public record OrderedItemDto(string Name, byte[] Photo, int Cost, int Quantity);
    
    public class ViewOrderedItemsDto
    {
        
        public string Name { get; set; }
        public BitmapImage Photo { get; set; }
        public int Price { get; set; }
        public int Quantity { get; set; }

        public ViewOrderedItemsDto(string name, BitmapImage photo, int price, int quantity)
        {
            Name = name;
            Photo = photo;
            Price = price;
            Quantity = quantity;
        }

    }
    //public record ViewOrderedItemsDto(string Name, BitmapImage Photo, int Cost, int Quantity);
}
