﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebshopKarbantarto.Dtos
{
    //public record ProductDto(Guid Id, byte[] Photo, int CategoryId, string Brand, string Name, double Review, string Description, int Stock, int Price);
    public class ProductDto
    {
        public Guid Id { get; set; }
        public byte[] Photo { get; set; }
        public int CategoryId { get; set; }
        public string Brand { get; set; }
        public string Name { get; set; }
        public double Review { get; set; }
        public string Description { get; set; }
        public int Stock { get; set; }
        public int Price { get; set; }

        public ProductDto(Guid id, byte[] photo, int categoryId, string brand, string name, double review, string description, int stock, int price)
        {
            Id = id;
            Photo = photo;
            CategoryId = categoryId;
            Brand = brand;
            Name = name;
            Review = review;
            Description = description;
            Stock = stock;
            Price = price;
        }
    }

    public record CreateProductDto(byte[] Photo, int CategoryId, string Brand, string Name, string Description, int Stock, int Price);
}
