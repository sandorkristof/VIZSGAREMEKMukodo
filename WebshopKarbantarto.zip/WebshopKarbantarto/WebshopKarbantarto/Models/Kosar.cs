﻿using System;
using System.Collections.Generic;

namespace WebshopKarbantarto.Models;

public partial class Kosar
{
    public Guid Id { get; set; }

    public Guid FelhaszId { get; set; }

    public virtual Felhasznalo Felhasz { get; set; } = null!;

    public virtual ICollection<KosarElem> KosarElems { get; set; } = new List<KosarElem>();
}
