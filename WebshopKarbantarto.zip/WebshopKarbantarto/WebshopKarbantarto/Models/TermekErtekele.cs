﻿using System;
using System.Collections.Generic;

namespace WebshopKarbantarto.Models;

public partial class TermekErtekele
{
    public Guid Id { get; set; }

    public Guid FelhasznaloId { get; set; }

    public Guid TermekId { get; set; }

    public int Ertekeles { get; set; }

    public string ErtekelesSzoveg { get; set; } = null!;

    public virtual Felhasznalo Felhasznalo { get; set; } = null!;

    public virtual Termek Termek { get; set; } = null!;
}
