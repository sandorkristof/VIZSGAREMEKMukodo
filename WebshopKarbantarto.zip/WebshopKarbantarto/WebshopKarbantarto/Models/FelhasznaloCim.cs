﻿using System;
using System.Collections.Generic;

namespace WebshopKarbantarto.Models;

public partial class FelhasznaloCim
{
    public Guid Id { get; set; }

    public Guid FelhaszId { get; set; }

    public int Irsz { get; set; }

    public string Telepules { get; set; } = null!;

    public string Utca { get; set; } = null!;

    public int Hazszam { get; set; }

    public string? EmeletAjto { get; set; }

    public virtual Felhasznalo Felhasz { get; set; } = null!;

    public virtual Rendele? Rendele { get; set; }
}
