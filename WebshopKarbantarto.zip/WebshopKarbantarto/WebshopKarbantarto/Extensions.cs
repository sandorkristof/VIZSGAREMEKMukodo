﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Media.Imaging;
using WebshopKarbantarto.Dtos;

namespace WebshopKarbantarto
{
    public class Extensions
    {
        public static BitmapImage LoadImage(byte[] imageData)
        {
           if (imageData == null || imageData.Length == 0) return null;
           var image = new BitmapImage();
           using (var mem = new MemoryStream(imageData))
           {
                mem.Position = 0;
                image.BeginInit();
                image.CreateOptions = BitmapCreateOptions.PreservePixelFormat;
                image.CacheOption = BitmapCacheOption.OnLoad;
                image.UriSource = null;
                image.StreamSource = mem;
                image.EndInit();
           }
           image.Freeze();
           return image;
        }
        public static byte[] ConvertBitmapImageToByteArray(BitmapImage bitmapImage)
        {
            byte[] imageData = null;

            if (bitmapImage != null)
            {
                using (MemoryStream stream = new MemoryStream())
                {
                    BitmapEncoder encoder = new PngBitmapEncoder();
                    encoder.Frames.Add(BitmapFrame.Create(bitmapImage));
                    encoder.Save(stream);

                    imageData = stream.ToArray();
                }
            }

            return imageData;
        }

        public static ProductDto ConvertToProductDto(ViewModelDto viewModel)
        {
            var result = new ProductDto(viewModel.Id, ConvertBitmapImageToByteArray(viewModel.Image), viewModel.CategoryId, viewModel.Brand, viewModel.Name, viewModel.Review, viewModel.Description, viewModel.Stock, viewModel.Stock);

            return result;
        }
    }
}
