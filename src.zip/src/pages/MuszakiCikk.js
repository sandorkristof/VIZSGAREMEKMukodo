import React, { useState } from 'react'
import './MuszakiCikk.css'
import { Link,Route,Routes } from "react-router-dom";
import TV from '../image/tv.png'
import Console from '../image/game-console.png'
import WIFI from '../image/wifi-router.png'
import Camera from '../image/camera.png'
import Laptop from '../image/laptop.png'
import Earbuds from '../image/headphones.png'


export default function MuszakiCikk() {
 


  return (
    <div>

      <div className=''>
      <div style={{marginTop:'30px'}} class="container">
        <div  class="row justify-content-center">
        <Link class="col-sm-2 shadow border me-3 mb-3" to="/Televíziók" style={{textDecoration:'none'}}>
            <img src={TV} alt="image1" class="img-fluid rounded" />
            <div style={{marginBottom:'3px',fontSize:'20px'}} class="font-weight-bold text-uppercase text-dark">TV</div>
          </Link>
          <Link class="col-sm-2 shadow border me-3 mb-3" to="/Konzol" style={{textDecoration:'none'}}>
            <img src={Console} alt="image2" class="img-fluid rounded"/>
            <div style={{marginBottom:'3px',fontSize:'20px'}} class="font-weight-bold text-uppercase text-dark">Konzolok</div>
          </Link>
          <Link class="col-sm-2 shadow border me-3 mb-3" to="/Routerek" style={{textDecoration:'none'}}>
            <img src={WIFI} alt="image3" class="img-fluid rounded"/>
            <div style={{marginBottom:'3px',fontSize:'20px'}} class="font-weight-bold text-uppercase text-dark">Routerek</div>
          </Link>
          </div>
          <div class="row justify-content-center">
          <Link class="col-sm-2 shadow border me-3 mb-3" to="/Kamerák" style={{textDecoration:'none'}}>
              <img src={Camera} alt="image4" class="img-fluid rounded"/>
              <div style={{marginBottom:'3px',fontSize:'20px'}} class="font-weight-bold text-uppercase text-dark">Kamerák</div>
          </Link>
          <Link class="col-sm-2 shadow border me-3 mb-3" to="/Laptopok" style={{textDecoration:'none'}}>
              <img src={Laptop} alt="image5" class="img-fluid rounded"/>
              <div style={{marginBottom:'3px',fontSize:'20px'}} class="font-weight-bold text-uppercase text-dark">Laptopok</div>
          </Link>
          <Link class="col-sm-2 shadow border me-3 mb-3" to="/Fülhallgatók" style={{textDecoration:'none'}}>
              <img src={Earbuds} alt="image6" class="img-fluid rounded"/>
              <div style={{marginBottom:'3px',fontSize:'20px'}} class="font-weight-bold text-uppercase text-dark">Fülhallgatók</div>
          </Link>
        </div>
      </div>
      </div>
      
    </div>
  )
}
