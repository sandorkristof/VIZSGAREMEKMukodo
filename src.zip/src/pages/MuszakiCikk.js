import React, { useState } from 'react'
import './CardPageSelect.css';
import { Link,Route,Routes } from "react-router-dom";
import TV from '../image/tv.png'
import Console from '../image/game-console.png'
import WIFI from '../image/wifi-router.png'
import Camera from '../image/camera.png'
import Laptop from '../image/laptop.png'
import Earbuds from '../image/headphones.png'


export default function MuszakiCikk() {
 


  return (
    <div>

      
<div className="container mt-4">
  <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-3 justify-content-center">
    <Link id='Dobozok' className="col border rounded mb-3" to="/Televíziók" style={{ textDecoration: 'none' }}>
      <img src={TV} alt="image1" className="img-fluid rounded" style={{ maxWidth: '100%', maxHeight: '150px' }} />
      <div style={{ marginBottom: '3px', fontSize: '14px' }} className="font-weight-bold text-uppercase text-dark">TV</div>
    </Link>
    <Link id='Dobozok' className="col border rounded mb-3" to="/Konzol" style={{ textDecoration: 'none' }}>
      <img src={Console} alt="image2" className="img-fluid rounded" style={{ maxWidth: '100%', maxHeight: '150px' }} />
      <div style={{ marginBottom: '3px', fontSize: '14px' }} className="font-weight-bold text-uppercase text-dark">Konzolok</div>
    </Link>
    <Link id='Dobozok' className="col border rounded mb-3" to="/Routerek" style={{ textDecoration: 'none' }}>
      <img src={WIFI} alt="image3" className="img-fluid rounded" style={{ maxWidth: '100%', maxHeight: '150px' }} />
      <div style={{ marginBottom: '3px', fontSize: '14px' }} className="font-weight-bold text-uppercase text-dark">Routerek</div>
    </Link>
    <Link id='Dobozok' className="col border rounded mb-3" to="/Kamerák" style={{ textDecoration: 'none' }}>
      <img src={Camera} alt="image4" className="img-fluid rounded" style={{ maxWidth: '100%', maxHeight: '150px' }} />
      <div style={{ marginBottom: '3px', fontSize: '14px' }} className="font-weight-bold text-uppercase text-dark">Kamerák</div>
    </Link>
    <Link id='Dobozok' className="col border rounded mb-3" to="/Laptopok" style={{ textDecoration: 'none' }}>
      <img src={Laptop} alt="image5" className="img-fluid rounded" style={{ maxWidth: '100%', maxHeight: '150px' }} />
      <div style={{ marginBottom: '3px', fontSize: '14px' }} className="font-weight-bold text-uppercase text-dark">Laptopok</div>
    </Link>
    <Link id='Dobozok' className="col border rounded mb-3" to="/Fülhallgatók" style={{ textDecoration: 'none' }}>
      <img src={Earbuds} alt="image6" className="img-fluid rounded" style={{ maxWidth: '100%', maxHeight: '150px' }} />
      <div style={{ marginBottom: '3px', fontSize: '14px' }} className="font-weight-bold text-uppercase text-dark">Fülhallgatók</div>
    </Link>
  </div>
</div>


      
    </div>
  )
}
