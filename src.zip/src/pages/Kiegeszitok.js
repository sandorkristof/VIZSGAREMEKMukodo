import React from 'react'

export default function Kiegeszitok() {
  return (
    <div>
      Kiegeszitok
    </div>
  )
}
