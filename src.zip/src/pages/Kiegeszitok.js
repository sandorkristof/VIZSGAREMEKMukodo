import React from 'react'
import './CardPageSelect.css';
import { Link,Route,Routes } from "react-router-dom";
import Paste from '../image/paste.png'
import Speaker from '../image/speaker.png'
import Cables from '../image/cable.png'



export default function Kiegeszitok() {
  return (
    <div>
      <div className="container mt-4 w-50">
  <div className="row row-cols-2 row-cols-md-4 g-3 justify-content-center">
    <Link id='Dobozok' className="col  border rounded me-3 mb-3" to="/Paszták" style={{ textDecoration: 'none' }}>
      <img src={Paste} alt="image1" className="img-fluid rounded" />
      <div style={{ marginBottom: '3px', fontSize: '20px' }} className="font-weight-bold text-uppercase text-dark">Paszták</div>
    </Link>
    <Link id='Dobozok' className="col  border rounded me-3 mb-3" to="/Hangszórók" style={{ textDecoration: 'none' }}>
      <img src={Speaker} alt="image2" className="img-fluid rounded" />
      <div style={{ marginBottom: '3px', fontSize: '20px' }} className="font-weight-bold text-uppercase text-dark">Hangszórók</div>
    </Link>
    <Link id='Dobozok' className="col  border rounded me-3 mb-3" to="/Kábelek" style={{ textDecoration: 'none' }}>
      <img src={Cables} alt="image3" className="img-fluid rounded" />
      <div style={{ marginBottom: '3px', fontSize: '20px' }} className="font-weight-bold text-uppercase text-dark">Kábelek</div>
    </Link>
  </div>
</div>
    </div>
  )
}
