import React from 'react'
import { Link,Route,Routes } from "react-router-dom";
import Paste from '../image/paste.png'
import Speaker from '../image/speaker.png'
import Cables from '../image/cable.png'



export default function Kiegeszitok() {
  return (
    <div>
      <div className='d-flex '>
      <div style={{marginTop:'30px'}} class="container">
        <div  class="row justify-content-center">
        <Link class="col-sm-2 shadow border me-3 mb-3" to="/Paszták" style={{textDecoration:'none'}}>
            <img src={Paste} alt="image1" class="img-fluid rounded" />
            <div style={{marginBottom:'3px',fontSize:'20px'}} class="font-weight-bold text-uppercase text-dark">Paszták</div>
          </Link>
          <Link class="col-sm-2 shadow border me-3 mb-3" to="/Hangszórók" style={{textDecoration:'none'}}>
            <img src={Speaker} alt="image2" class="img-fluid rounded"/>
            <div style={{marginBottom:'3px',fontSize:'20px'}} class="font-weight-bold text-uppercase text-dark">Hangszórók</div>
          </Link>
          <Link class="col-sm-2 shadow border me-3 mb-3" to="/Kábelek" style={{textDecoration:'none'}}>
            <img src={Cables} alt="image3" class="img-fluid rounded"/>
            <div style={{marginBottom:'3px',fontSize:'20px'}} class="font-weight-bold text-uppercase text-dark">Kábelek</div>
          </Link>
          </div>
      </div>

      </div>
    </div>
  )
}
