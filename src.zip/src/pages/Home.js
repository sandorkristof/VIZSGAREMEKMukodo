import React, { useEffect, useState } from 'react';
import { useCookies } from 'react-cookie';
import { Link,Route,Routes } from "react-router-dom";
import cpuImg from '../image/homeIMG/CPUtry.jpg';
import gpuImg from '../image/homeIMG/GPUtry.jpg';
import tvImg from '../image/homeIMG/TVtry.jpg';


import './Homes.css';

export default function Home() {

  const [kereses, setKereses] = useState('');
  const [keresesEredmeny, setKeresesEredmeny] = useState([]);
  const [cart, setCart] = useState([]);
  const [products, setProducts] = useState([]);
  const [keresesAktiv, setKeresesAktiv] = useState(false);
  const [valtozoKepek, setValtozoKepek] = useState(0);

  const images =[cpuImg,gpuImg,tvImg];


  useEffect(() => {
    // Betöltjük a kosarat a localStorage-ból
    const existingCart = JSON.parse(localStorage.getItem('cart')) || [];
    setCart(existingCart);
  }, []);

  const Kereses = async () => {
    if(!kereses.trim()){
      //console.log('Adj meg egy értéket!');
    }else{
      
        try {
          const response = await fetch(`http://localhost:5259/Product/search?search=${kereses}`);
          const data = await response.json();
          setKeresesEredmeny(data);
          //console.log(data);
          //console.log(setKeresesEredmeny);
          setKeresesAktiv(true);
        } catch (error) {
          console.error('Hiba a keresésben', error);
        }
    }

  };

  const KosarbaAdas = (product) => {
    // A termék hozzáadása a kosárhoz
    setCart((prevCart) => {
      // Ellenőrizzük, hogy a termék már szerepel-e a kosárban
      const KosarIndex = prevCart.findIndex((item) => item.id === product.id);
  
      if (KosarIndex !== -1) {
        // Ha a termék már szerepel a kosárban, csak növeljük a mennyiséget
        const FrissitettKosar = [...prevCart];
        FrissitettKosar[KosarIndex].quantity += 1;
        localStorage.setItem('cart', JSON.stringify(FrissitettKosar));
        return FrissitettKosar;
        // A korábbi kosár másolata készül, majd ennek a másolatnak a módosítjuk.
        // A termék mennyiségének növelése után a frissített kosár kerül mentésre a localStorageben,
        // majd visszatérünk a frissített kosárral.
      } else {
        // Ha a termék még nem szerepel a kosárban, hozzáadjuk
        const newCartItem = {
          id: product.id,
          brand: product.brand,
          name: product.name,
          price: product.price,
          quantity: 1,
          photo: product.photo,
        };
        const FrissitettKosar = [...prevCart, newCartItem];
        localStorage.setItem('cart', JSON.stringify(FrissitettKosar));// Kosár frissítése a localStorage-ban
        return FrissitettKosar;
      }
    });
  };
// A KosarbaAdas függvény felelős a termék hozzáadásáért a kosárhoz.
// Ellenőrzi, hogy a termék már szerepel-e a kosárban.
// Ha igen, növeli a termék mennyiségét.
// Ha nem, hozzáadja a terméket a kosárhoz.
// Minden módosítás után frissíti a kosár állapotát a localStorage-ban is.

  
  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      Kereses();
    }
  };
  

 

  useEffect(() => {
    const interval = setInterval(() => {
      setValtozoKepek((prevIndex) => (prevIndex + 1) % images.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [images.length]);

  

  const pageRoutes = {
    0: '/Processzorok',   
    1: '/Videokartya',   
    2: '/Televíziók',    
    
  };




  return (
    <div className="container">
  {/* Képek Eleje */}
  {!keresesAktiv && (
  <div className="rounded-image-slider d-inline-flex" style={{ height: '400px', width: '650px',  marginTop: '15px', position: 'relative', overflow: 'hidden'}}>
    {images.map((imageUrl, index) => (
      <Link to={pageRoutes[index]} key={index}>
        <img
          src={imageUrl}
          className={`d-block rounded-4  w-100  shadow ${index === valtozoKepek ? 'active' : ''}`}
          alt={`Slide ${index + 1}`}
          style={{
            position: 'absolute',
            top: 0,
            left: index === valtozoKepek ? 0 : '100%',
            transition: 'left 1.7s ease-in-out', 
          }}
        />
      </Link>
    ))}
  </div>
)}
  {/* Képek Vége */}

  <div className="input-group search mt-3">
    <input
      type="text"
      className="form-control"
      value={kereses}
      onChange={(e) => setKereses(e.target.value)}
      placeholder="Keresse meg termékeit!"
      style={{ borderColor: "#04c4f4" }}
    />
    <button
      onClick={Kereses}
      className="btn"
      style={{ backgroundColor: '#04c4f4' }}
    >
      <span id="myButton">Keresés</span>
    </button>
  </div>

  <div className="row row-cols-1 row-cols-md-3 g-4 mt-3">
    {keresesEredmeny.map(product => (
      <div className="col" key={product.id}>
        <div className="shadow-sm border rounded">
          <img
            src={product.photo}
            alt=""
            style={{ height: '250px', objectFit: 'fill' }}
            className="img-fluid"
          />
          <h3>{product.brand}</h3>
          <p>{product.name}</p>
          <p>{product.price} Ft</p>
          <button
            className="btn mb-3"
            style={{ backgroundColor: '#04c4f4' }}
            onClick={() => KosarbaAdas(product)}
          >
            Kosár
          </button>
        </div>
      </div>
    ))}
  </div>
</div>

    
  )
  
}
