import React from 'react'

export default function Home() {
  return (
    <div>
      <br />
      <div style={{width:"800px",marginTop:'70px'}} className="mx-auto d-md-none d-lg-block">
            <div  className="input-group search">
              
              <input type="text" className="form-control border-dark" />
              <button className="btn btn-dark text-white">Keresés </button>
            </div>
          </div>
          
          <div style={{marginTop:'100px'}} className="mx-auto d-md-none d-lg-block">
            <span>Gyakori keresések</span>
            <br />
             <div className="container-fluid bg-trasparent my-4 p-3"style={{position:'relative'}}>
              <div className="row row-cols-1 row-cols-xs-2 row-cols-sm-2 row-cols-lg-4 g-3">
              <div className="d-flex  col-md-3">
                  <div className="card rounded-1 custom-card">
                    <img src="https://s13emagst.akamaized.net/products/57170/57169744/images/res_c4bcb9c102c648d13347aa24e117220d.jpg?width=720&height=720&hash=6A33C59FCBB0ADB7B189E50CB7593470" className="card-img-top" alt="Card Image"/>
                    <div className="card-body">
                    <h5 className="card-title">Card 2</h5>
                    <div>
                        <div className='text-start' >
                            <span style={{marginRight:'5px'}}>Értékelés:</span>
                            <span className=' fw-bold'>4.0</span>
                        </div>
                      </div>
                      <div className='text-end'>
                        <p className='badge bg-dark'>Raktáron</p>
                      </div>
                       <div className="container mt-0 w-75">
                          <button className="btn btn-primary">
                              <img  className='' style={{width:'20px'}} src="https://cdn-icons-png.flaticon.com/128/2636/2636890.png" alt="" />
                              <span className='mx-2'>Kosárba</span>
                          </button>
                       </div>  
                    </div>
                  </div>
                </div>
                <div className="d-flex col-md-3">
                  <div className="card rounded-1 custom-card">
                    <img src="https://s13emagst.akamaized.net/products/36726/36725029/images/res_e4f9b4c591d85c8574e97829b7ccb482.jpg?width=720&height=720&hash=B5858D91396E7A5690CACB25C29E2318" className="card-img-top" alt="Card Image"/>
                    <div className="card-body">
                    <h5 className="card-title">Card 2</h5>
                    <div>
                        <div className='text-start' >
                            <span style={{marginRight:'5px'}}>Értékelés:</span>
                            <span className=' fw-bold'>4.0</span>
                        </div>
                      </div>
                      <div className='text-end'>
                        <p className='badge bg-dark'>Raktáron</p>
                      </div>
                       <div className="container mt-0 w-75">
                          <button className="btn btn-primary">
                              <img className='' style={{width:'20px'}} src="https://cdn-icons-png.flaticon.com/128/2636/2636890.png" alt="" />
                              <span className='mx-2'>Kosárba</span>
                          </button>
                       </div>  
                    </div>
                  </div>
                </div>
                <div className="d-flex col-md-3">
                  <div className="card rounded-1 custom-card">
                    <img src="https://s13emagst.akamaized.net/products/32447/32446033/images/res_f43843d7e379e7ac91d67dc412ea082a.jpg?width=720&height=720&hash=361DC19C5BE9A21367C03DEF4DA2C575" className="card-img-top" alt="Card Image"/>
                    <div className="card-body">
                    <h5 className="card-title">Card 2</h5>
                    <div>
                        <div className='text-start' >
                            <span style={{marginRight:'5px'}}>Értékelés:</span>
                            <span className=' fw-bold'>4.0</span>
                        </div>
                      </div>
                      <div className='text-end'>
                        <p className='badge bg-dark'>Raktáron</p>
                      </div>
                       <div className="container mt-0 w-75">
                          <button className="btn btn-primary">
                              <img className='' style={{width:'20px'}} src="https://cdn-icons-png.flaticon.com/128/2636/2636890.png" alt="" />
                              <span className='mx-2'>Kosárba</span>
                          </button>
                       </div>  
                    </div>
                  </div>
                </div>
                <div className="d-flex col-md-3">
                  <div className="card rounded-1 custom-card">
                    <img src="https://s13emagst.akamaized.net/products/52198/52197748/images/res_60ddd957789b027d92ec154edd88a6b1.jpg?width=720&height=720&hash=D5D6801DFD57E974426198BDD3572B03" className="card-img-top" alt="Card Image"/>
                    <div className="card-body">
                    <h5 className="card-title">Card 2</h5>
                    <div>
                        <div className='text-start' >
                            <span style={{marginRight:'5px'}}>Értékelés:</span>
                            <span className=' fw-bold'>4.0</span>
                        </div>
                      </div>
                      <div className='text-end'>
                        <p className='badge bg-dark'>Raktáron</p>
                      </div>
                       <div className="container mt-0 w-75">
                          <button className="btn btn-primary">
                              <img className='' style={{width:'20px'}} src="https://cdn-icons-png.flaticon.com/128/2636/2636890.png" alt="" />
                              <span className='mx-2'>Kosárba</span>
                          </button>
                       </div>  
                    </div>
                  </div>
                </div>
                                                                                             </div>
                                                                                              </div>
          </div>
          <div>
            
          </div>
    </div>

    
  )
}
