import React, { useState } from 'react';
import './Homes.css';

export default function Home() {



  return (
    <div >
      
      <div className="container  d-flex justify-content-center align-items-center" style={{ height: "200px" }}>
      <div className="input-group search" style={{ width: "800px" }}>
        <input
          style={{ borderColor: "#04c4f4" }}
          type="text"
          className="form-control"
        />
        <button style={{backgroundColor:'#04c4f4'}} className="btn"><span id="myButton">Keresés</span></button>
      </div>
    </div>
          
          <div  className="mx-auto d-md-none d-lg-block">
            <span>Gyakori keresések</span>
            <br />
             <div className="container-fluid my-4 p-3"style={{position:'relative'}}>
              <div className="row row-cols-1 row-cols-xs-2 row-cols-sm-2 row-cols-lg-4 g-3">
              <div className="d-flex  col-md-3 ">
                  <div className="card rounded-1 custom-card">
                      <img  src="https://s13emagst.akamaized.net/products/57170/57169744/images/res_c4bcb9c102c648d13347aa24e117220d.jpg?width=720&height=720&hash=6A33C59FCBB0ADB7B189E50CB7593470" className="card-img-top" alt="Card Image"/>
                      <div className="card-body">
                      <h5 className="card-title">Card 2</h5>
                      <div>
                          <div className='text-start' >
                              <span style={{marginRight:'5px'}}>Értékelés:</span>
                              <span className=' fw-bold'>0.0</span>
                          </div>
                        </div>
                        <div className='text-end'>
                          <p style={{backgroundColor:'#32CD32'}} className='badge '>Raktáron</p>
                        </div>
                        <div className="container mt-0 w-75 d-flex justify-content-center">
            <button style={{ backgroundColor: 'silver' }} className="btn btn-rounded">
              <img className='' style={{ width: '20px', height: '20px' }} src="https://cdn-icons-png.flaticon.com/512/263/263142.png" alt="" />
              <span className='ms-1'>Kosárba</span>
            </button>
          </div>  
                      </div>
                    </div>
                </div>
                <div className="d-flex col-md-3">
                    <div className="card rounded-1 custom-card">
                      <img  src="https://s13emagst.akamaized.net/products/57170/57169744/images/res_c4bcb9c102c648d13347aa24e117220d.jpg?width=720&height=720&hash=6A33C59FCBB0ADB7B189E50CB7593470" className="card-img-top" alt="Card Image"/>
                      <div className="card-body">
                      <h5 className="card-title">Card 2</h5>
                      <div>
                          <div className='text-start' >
                              <span style={{marginRight:'5px'}}>Értékelés:</span>
                              <span className=' fw-bold'>0.0</span>
                          </div>
                        </div>
                        <div className='text-end'>
                          <p style={{backgroundColor:'#32CD32'}} className='badge '>Raktáron</p>
                        </div>
                        <div className="container mt-0 w-75 d-flex justify-content-center">
            <button style={{ backgroundColor: 'silver' }} className="btn btn-rounded">
              <img className='' style={{ width: '20px', height: '20px' }} src="https://cdn-icons-png.flaticon.com/512/263/263142.png" alt="" />
              <span className='ms-1'>Kosárba</span>
            </button>
          </div>  
                      </div>
                    </div>
                </div>
                <div className="d-flex col-md-3">
                      <div className="card rounded-1 custom-card">
                        <img  src="https://s13emagst.akamaized.net/products/57170/57169744/images/res_c4bcb9c102c648d13347aa24e117220d.jpg?width=720&height=720&hash=6A33C59FCBB0ADB7B189E50CB7593470" className="card-img-top" alt="Card Image"/>
                        <div className="card-body">
                        <h5 className="card-title">Card 2</h5>
                        <div>
                            <div className='text-start' >
                                <span style={{marginRight:'5px'}}>Értékelés:</span>
                                <span className=' fw-bold'>0.0</span>
                            </div>
                          </div>
                          <div className='text-end'>
                            <p style={{backgroundColor:'#32CD32'}} className='badge '>Raktáron</p>
                          </div>
                          <div className="container mt-0 w-75 d-flex justify-content-center">
                            <button style={{ backgroundColor: 'silver' }} className="btn btn-rounded">
                              <img className='' style={{ width: '20px', height: '20px' }} src="https://cdn-icons-png.flaticon.com/512/263/263142.png" alt="" />
                              <span className='ms-1'>Kosárba</span>
                            </button>
                          </div>  
                        </div>
                      </div>
                </div>
                <div className="d-flex col-md-3">
                    <div className="card rounded-1 custom-card">
                      <img  src="https://s13emagst.akamaized.net/products/57170/57169744/images/res_c4bcb9c102c648d13347aa24e117220d.jpg?width=720&height=720&hash=6A33C59FCBB0ADB7B189E50CB7593470" className="card-img-top" alt="Card Image"/>
                      <div className="card-body">
                      <h5 className="card-title">Card 2</h5>
                      <div>
                          <div className='text-start' >
                              <span style={{marginRight:'5px'}}>Értékelés:</span>
                              <span className=' fw-bold'>0.0</span>
                          </div>
                        </div>
                        <div className='text-end'>
                          <p style={{backgroundColor:'#32CD32'}} className='badge '>Raktáron</p>
                        </div>
                        <div className="container mt-0 w-75 d-flex justify-content-center">
            <button style={{ backgroundColor: 'silver' }} className="btn btn-rounded">
              <img className='' style={{ width: '20px', height: '20px' }} src="https://cdn-icons-png.flaticon.com/512/263/263142.png" alt="" />
              <span className='ms-1'>Kosárba</span>
            </button>
          </div>  
                      </div>
                    </div>
                </div>
              </div>
            </div>
          </div>
          
    </div>

    
  )
  
}
