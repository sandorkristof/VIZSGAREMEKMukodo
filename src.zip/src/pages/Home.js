import React, { useState } from 'react';
import './Homes.css';

export default function Home() {

  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState([]);

  const handleSearch = async () => {
    try {
      const response = await fetch(`http://localhost:5259/Product/search?search=${searchTerm}`);
      const data = await response.json();
      setSearchResults(data);
      console.log(data);
      console.log(setSearchResults);
    } catch (error) {
      console.error('Hiba a keresésben', error);
    }
  };

  return (
    <div >
      
      <div className="container  d-flex justify-content-center align-items-center" style={{ height: "200px" }}>
      <div className="input-group search" style={{ width: "800px" }}>
        <input style={{ borderColor: "#04c4f4" }}type="text" className="form-control" value={searchTerm}onChange={(e) => setSearchTerm(e.target.value)}placeholder="Enter search term..."/>
        <button onClick={handleSearch} style={{backgroundColor:'#04c4f4'}} className="btn"><span id="myButton">Keresés</span></button>
      </div>
      <div>
        {searchResults.map(product => (
          <div key={product.photo}>
            <h3>{product.brand}</h3>
            <p>{product.name}</p>
          </div>
        ))}
      </div>
    </div>
          
          <div  className="mx-auto d-md-none d-lg-block">
            <span>Gyakori keresések</span>
            <br />
            
          </div>
          
    </div>

    
  )
  
}
