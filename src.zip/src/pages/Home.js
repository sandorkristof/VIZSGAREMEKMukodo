import React from 'react'

export default function Home() {
  return (
    <div >
      <br />
      <div style={{width:"800px",marginTop:'70px'}} className="mx-auto d-md-none d-lg-block">
            <div  className="input-group search">
              
              <input style={{borderColor:'#002244'}} type="text" className="form-control" />
              <button style={{backgroundColor:'#002244'}} className="btn  text-white">Keresés </button>
            </div>
          </div>
          
          <div style={{marginTop:'100px'}} className="mx-auto d-md-none d-lg-block">
            <span>Gyakori keresések</span>
            <br />
             <div className="container-fluid my-4 p-3"style={{position:'relative'}}>
              <div className="row row-cols-1 row-cols-xs-2 row-cols-sm-2 row-cols-lg-4 g-3">
              <div className="d-flex  col-md-3 ">
                  <div className="card rounded-0 custom-card w-100 shadow">
                    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAflBMVEX///8AAADPz8/b29thYWG4uLihoaFvb2+IiIj7+/tsbGzt7e3T09POzs52dnZTU1Pj4+Onp6e+vr7GxsYcHBwzMzOAgIA5OTmTk5P19fUuLi7m5uZbW1ulpaWVlZU0NDQ/Pz9EREQODg4iIiJLS0sfHx97e3sXFxewsLBUVFT4yHDIAAAGM0lEQVR4nO2da3uiMBBG661dxRtqrdiudlu3uv//D25L1wAyuU8gPPuej5XKHCEXQjK5uwMAAAAAAAAAAAAAAAAAAAAAAPBfME6ms37kzKaDZOxmN5o/9brCcT6ytZwN2w7amuHUwm/w2na4TiwGhn7ZQ9uhOjM3ulenbYfphcFlTNuO0ZOVTvC+7Qi9uagFR23Hx4DyKt6Uwf38kK7WbbfpStary/38sRq2oiyOy8edRonulo6GbPWnFPlZfmCpmT+Zti2xsFwUwW9lB/WLYw5NBsdEqZKUXZ6iH5o2GhoXRTX5Qh8wEwfsmo2MjeIqLsnPX0QV2nBgfIj+9IT6NBM/wKzpwNgoWjuqgzrq/iUsXUSq2Z9fP7xvPC4+RK+aajA2uqq2CyyvEq/Eh+IWbjgoXhQWwv5X82ExIno2We2jwfWjufS/n0e7+eRhm9oMiDSNqE3qLaIw/EH/a7LbizugN4m2QdnJaxNhSFal2bxX5bEfPFgnUkfDVa+O/G5uk5Gb4Q9C8PMy1gtz+7gZ3t6hV94ifER2MqSv4BfvjQRthYvhWirY6w2bCdsCB8Mx7fYP7ehk0zgYyu/RnECBTt8dy7i9YUaLCcKMd3zFST+mm/ynnaFuDDzIw+T3fePUb7I3PGoMQzxrXQc1Rw7/a22ou0kDPC9nTz7fbW2oaiq+Icd8PFiWv1zyFKDA2lD/rk0xhO7CzU9q/ftZG+56Wjx06tQqtpPlF1gbalrDL9ymetAQPeAnu/593NdwfCJPYNX2WxsavBL21CpIfkvOYNMgBahL2QauFDMkLNp+a8NnraH0XZ0lyvfr5m2/fZ/mrDNce7vlaKo047bf3lBbmfJUpdpJZqZtv73hgD6hgGU8KjOYI/gQyrB4q0jDMVSzVJ/iH4tQhurTc9Qz+vr6m6NJgXAZp1GVxDeGUmg+C2tjcMM4jbUppmIyvMGQDVWS6J/7nQzHe/p0HONQ44Xsu2m07xLcRoTHj/Tp/AWTDf3NcnTndBzVJ2+ls//4hctU1p9hDO/Wb7dnYqhF3SZCqtt+Z8PPp/1Kadw++wsaPJmRKDsZHoafLWM6eTr33vaLHcv7UffVAKq238swh+uJPvNZDvBLHoW/IRNmHTUpZ2nbH4uhaUdNjqztj8Twp7egtDsV0vDDuHq16qhJodv+cIbZ3vhx37KjJoV87RXM8HsCtcnc6eSdSZCe6BvK8Dr4r3/rzbrmiGj7AxlOxDk3msLIvGKlPp87iGF1lEVZGF07alJemzDs35xUURgDLNt8v3mtEcCw3rbJCqNXR01Ote3nN5wQ53wnC6NnR01Ope3nNkwkA51EYfTvqMmovEVlNpRX/bXCyNFRk1AZK+Y1VEV9U49/hBMMaKheEL0vP+BwddRIQhkmkgG4AlEYGTtqFIEMTXpfh5tvDkQYQ7Oh+GHlnKEIYmiak2D/zN9RqxHAMNFOditoIL8Gv+FtR7Rt2A0Dtt1ucBtSHdF24TXMLIpgU7AaxlYEczgNoyuCOYyG8RXBHDZD2bNg63AZRlkEc5gM4yyCOTyGkRbBHA5D/bNgmzAYRp79y98w9uRY3oYxF8EcT8NEOuUrGvwMIy+COX6G23aCtsLP0GDNTOvAEIbxA0MYxg8MYRg/MIRh/MAQhvEDQxjGDwxhGD8whGH8wBCG8QNDGMYPDGEYPzCsGVbWD3fO8HL9q8KwkpalC4aV1XmH61/rhmIBZOUnSV+GsfNSWQkoJo/U00qIjMFd3iro7k7sMEekPRVXvfmwGFFZiHUGMW+yokO5W45Y5tnFffOuiMzOVDYpsQ/JpvG4+BBTfanEB0Vy8ug2PDCm2P6PzLMkJpL+bjowNsQlpHOBFusNuDLnNk2xmlOSLa9YtdXNzeWKBPKyfGelRSP2Ce3bp7QeV5rwsDSl+xjtrlwSpqW8Ih/Soyp7PRxThsyBDfGclhdlqWrKWa/C5rQ9pJdRzFzSw/Z0kyNUmce16zurf6FpzmNfPqJHu7dP16+iQYesC0sspGyM9lDKNEnKI8a4M7aOfykQxR+bzMarMHm5QjKxzdycXCZhE+dwcpyv3JLjZsv+rB85s+kg4dzMBwAAAAAAAAAAAAAAAAAAAAAAQMT8BauOex3Hfqj9AAAAAElFTkSuQmCC" className="card-img-top" alt="Card Image"/>
                    <div className="card-body shadow">
                    <h5 className="card-title">Card 2</h5>
                    <div>
                        <div className='text-start' >
                            <span style={{marginRight:'5px'}}>Értékelés:</span>
                            <span className=' fw-bold'>4.0</span>
                        </div>
                      </div>
                      <div className='text-end'>
                        <p className='badge bg-dark'>Raktáron</p>
                      </div>
                       <div className="container mt-0 w-75">
                          <button className="btn btn-primary">
                              <img  className='' style={{width:'20px'}} src="https://cdn-icons-png.flaticon.com/128/2636/2636890.png" alt="" />
                              <span className='mx-2'>Kosárba</span>
                          </button>
                       </div>  
                    </div>
                  </div>
                </div>
                <div className="d-flex col-md-3">
                  <div className="card rounded-1 custom-card w-100 shadow">
                    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAflBMVEX///8AAADPz8/b29thYWG4uLihoaFvb2+IiIj7+/tsbGzt7e3T09POzs52dnZTU1Pj4+Onp6e+vr7GxsYcHBwzMzOAgIA5OTmTk5P19fUuLi7m5uZbW1ulpaWVlZU0NDQ/Pz9EREQODg4iIiJLS0sfHx97e3sXFxewsLBUVFT4yHDIAAAGM0lEQVR4nO2da3uiMBBG661dxRtqrdiudlu3uv//D25L1wAyuU8gPPuej5XKHCEXQjK5uwMAAAAAAAAAAAAAAAAAAAAAAPBfME6ms37kzKaDZOxmN5o/9brCcT6ytZwN2w7amuHUwm/w2na4TiwGhn7ZQ9uhOjM3ulenbYfphcFlTNuO0ZOVTvC+7Qi9uagFR23Hx4DyKt6Uwf38kK7WbbfpStary/38sRq2oiyOy8edRonulo6GbPWnFPlZfmCpmT+Zti2xsFwUwW9lB/WLYw5NBsdEqZKUXZ6iH5o2GhoXRTX5Qh8wEwfsmo2MjeIqLsnPX0QV2nBgfIj+9IT6NBM/wKzpwNgoWjuqgzrq/iUsXUSq2Z9fP7xvPC4+RK+aajA2uqq2CyyvEq/Eh+IWbjgoXhQWwv5X82ExIno2We2jwfWjufS/n0e7+eRhm9oMiDSNqE3qLaIw/EH/a7LbizugN4m2QdnJaxNhSFal2bxX5bEfPFgnUkfDVa+O/G5uk5Gb4Q9C8PMy1gtz+7gZ3t6hV94ifER2MqSv4BfvjQRthYvhWirY6w2bCdsCB8Mx7fYP7ehk0zgYyu/RnECBTt8dy7i9YUaLCcKMd3zFST+mm/ynnaFuDDzIw+T3fePUb7I3PGoMQzxrXQc1Rw7/a22ou0kDPC9nTz7fbW2oaiq+Icd8PFiWv1zyFKDA2lD/rk0xhO7CzU9q/ftZG+56Wjx06tQqtpPlF1gbalrDL9ymetAQPeAnu/593NdwfCJPYNX2WxsavBL21CpIfkvOYNMgBahL2QauFDMkLNp+a8NnraH0XZ0lyvfr5m2/fZ/mrDNce7vlaKo047bf3lBbmfJUpdpJZqZtv73hgD6hgGU8KjOYI/gQyrB4q0jDMVSzVJ/iH4tQhurTc9Qz+vr6m6NJgXAZp1GVxDeGUmg+C2tjcMM4jbUppmIyvMGQDVWS6J/7nQzHe/p0HONQ44Xsu2m07xLcRoTHj/Tp/AWTDf3NcnTndBzVJ2+ls//4hctU1p9hDO/Wb7dnYqhF3SZCqtt+Z8PPp/1Kadw++wsaPJmRKDsZHoafLWM6eTr33vaLHcv7UffVAKq238swh+uJPvNZDvBLHoW/IRNmHTUpZ2nbH4uhaUdNjqztj8Twp7egtDsV0vDDuHq16qhJodv+cIbZ3vhx37KjJoV87RXM8HsCtcnc6eSdSZCe6BvK8Dr4r3/rzbrmiGj7AxlOxDk3msLIvGKlPp87iGF1lEVZGF07alJemzDs35xUURgDLNt8v3mtEcCw3rbJCqNXR01Ote3nN5wQ53wnC6NnR01Ope3nNkwkA51EYfTvqMmovEVlNpRX/bXCyNFRk1AZK+Y1VEV9U49/hBMMaKheEL0vP+BwddRIQhkmkgG4AlEYGTtqFIEMTXpfh5tvDkQYQ7Oh+GHlnKEIYmiak2D/zN9RqxHAMNFOditoIL8Gv+FtR7Rt2A0Dtt1ucBtSHdF24TXMLIpgU7AaxlYEczgNoyuCOYyG8RXBHDZD2bNg63AZRlkEc5gM4yyCOTyGkRbBHA5D/bNgmzAYRp79y98w9uRY3oYxF8EcT8NEOuUrGvwMIy+COX6G23aCtsLP0GDNTOvAEIbxA0MYxg8MYRg/MIRh/MAQhvEDQxjGDwxhGD8whGH8wBCG8QNDGMYPDGEYPzCsGVbWD3fO8HL9q8KwkpalC4aV1XmH61/rhmIBZOUnSV+GsfNSWQkoJo/U00qIjMFd3iro7k7sMEekPRVXvfmwGFFZiHUGMW+yokO5W45Y5tnFffOuiMzOVDYpsQ/JpvG4+BBTfanEB0Vy8ug2PDCm2P6PzLMkJpL+bjowNsQlpHOBFusNuDLnNk2xmlOSLa9YtdXNzeWKBPKyfGelRSP2Ce3bp7QeV5rwsDSl+xjtrlwSpqW8Ih/Soyp7PRxThsyBDfGclhdlqWrKWa/C5rQ9pJdRzFzSw/Z0kyNUmce16zurf6FpzmNfPqJHu7dP16+iQYesC0sspGyM9lDKNEnKI8a4M7aOfykQxR+bzMarMHm5QjKxzdycXCZhE+dwcpyv3JLjZsv+rB85s+kg4dzMBwAAAAAAAAAAAAAAAAAAAAAAQMT8BauOex3Hfqj9AAAAAElFTkSuQmCC" className="card-img-top" alt="Card Image"/>
                    <div className="card-body shadow">
                    <h5 className="card-title">Card 2</h5>
                    <div>
                        <div className='text-start' >
                            <span style={{marginRight:'5px'}}>Értékelés:</span>
                            <span className=' fw-bold'>4.0</span>
                        </div>
                      </div>
                      <div className='text-end'>
                        <p className='badge bg-dark'>Raktáron</p>
                      </div>
                       <div className="container mt-0 w-75">
                          <button className="btn btn-primary">
                              <img className='' style={{width:'20px'}} src="https://cdn-icons-png.flaticon.com/128/2636/2636890.png" alt="" />
                              <span className='mx-2'>Kosárba</span>
                          </button>
                       </div>  
                    </div>
                  </div>
                </div>
                <div className="d-flex col-md-3">
                  <div className="card rounded-1 custom-card w-100 shadow">
                    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAflBMVEX///8AAADPz8/b29thYWG4uLihoaFvb2+IiIj7+/tsbGzt7e3T09POzs52dnZTU1Pj4+Onp6e+vr7GxsYcHBwzMzOAgIA5OTmTk5P19fUuLi7m5uZbW1ulpaWVlZU0NDQ/Pz9EREQODg4iIiJLS0sfHx97e3sXFxewsLBUVFT4yHDIAAAGM0lEQVR4nO2da3uiMBBG661dxRtqrdiudlu3uv//D25L1wAyuU8gPPuej5XKHCEXQjK5uwMAAAAAAAAAAAAAAAAAAAAAAPBfME6ms37kzKaDZOxmN5o/9brCcT6ytZwN2w7amuHUwm/w2na4TiwGhn7ZQ9uhOjM3ulenbYfphcFlTNuO0ZOVTvC+7Qi9uagFR23Hx4DyKt6Uwf38kK7WbbfpStary/38sRq2oiyOy8edRonulo6GbPWnFPlZfmCpmT+Zti2xsFwUwW9lB/WLYw5NBsdEqZKUXZ6iH5o2GhoXRTX5Qh8wEwfsmo2MjeIqLsnPX0QV2nBgfIj+9IT6NBM/wKzpwNgoWjuqgzrq/iUsXUSq2Z9fP7xvPC4+RK+aajA2uqq2CyyvEq/Eh+IWbjgoXhQWwv5X82ExIno2We2jwfWjufS/n0e7+eRhm9oMiDSNqE3qLaIw/EH/a7LbizugN4m2QdnJaxNhSFal2bxX5bEfPFgnUkfDVa+O/G5uk5Gb4Q9C8PMy1gtz+7gZ3t6hV94ifER2MqSv4BfvjQRthYvhWirY6w2bCdsCB8Mx7fYP7ehk0zgYyu/RnECBTt8dy7i9YUaLCcKMd3zFST+mm/ynnaFuDDzIw+T3fePUb7I3PGoMQzxrXQc1Rw7/a22ou0kDPC9nTz7fbW2oaiq+Icd8PFiWv1zyFKDA2lD/rk0xhO7CzU9q/ftZG+56Wjx06tQqtpPlF1gbalrDL9ymetAQPeAnu/593NdwfCJPYNX2WxsavBL21CpIfkvOYNMgBahL2QauFDMkLNp+a8NnraH0XZ0lyvfr5m2/fZ/mrDNce7vlaKo047bf3lBbmfJUpdpJZqZtv73hgD6hgGU8KjOYI/gQyrB4q0jDMVSzVJ/iH4tQhurTc9Qz+vr6m6NJgXAZp1GVxDeGUmg+C2tjcMM4jbUppmIyvMGQDVWS6J/7nQzHe/p0HONQ44Xsu2m07xLcRoTHj/Tp/AWTDf3NcnTndBzVJ2+ls//4hctU1p9hDO/Wb7dnYqhF3SZCqtt+Z8PPp/1Kadw++wsaPJmRKDsZHoafLWM6eTr33vaLHcv7UffVAKq238swh+uJPvNZDvBLHoW/IRNmHTUpZ2nbH4uhaUdNjqztj8Twp7egtDsV0vDDuHq16qhJodv+cIbZ3vhx37KjJoV87RXM8HsCtcnc6eSdSZCe6BvK8Dr4r3/rzbrmiGj7AxlOxDk3msLIvGKlPp87iGF1lEVZGF07alJemzDs35xUURgDLNt8v3mtEcCw3rbJCqNXR01Ote3nN5wQ53wnC6NnR01Ope3nNkwkA51EYfTvqMmovEVlNpRX/bXCyNFRk1AZK+Y1VEV9U49/hBMMaKheEL0vP+BwddRIQhkmkgG4AlEYGTtqFIEMTXpfh5tvDkQYQ7Oh+GHlnKEIYmiak2D/zN9RqxHAMNFOditoIL8Gv+FtR7Rt2A0Dtt1ucBtSHdF24TXMLIpgU7AaxlYEczgNoyuCOYyG8RXBHDZD2bNg63AZRlkEc5gM4yyCOTyGkRbBHA5D/bNgmzAYRp79y98w9uRY3oYxF8EcT8NEOuUrGvwMIy+COX6G23aCtsLP0GDNTOvAEIbxA0MYxg8MYRg/MIRh/MAQhvEDQxjGDwxhGD8whGH8wBCG8QNDGMYPDGEYPzCsGVbWD3fO8HL9q8KwkpalC4aV1XmH61/rhmIBZOUnSV+GsfNSWQkoJo/U00qIjMFd3iro7k7sMEekPRVXvfmwGFFZiHUGMW+yokO5W45Y5tnFffOuiMzOVDYpsQ/JpvG4+BBTfanEB0Vy8ug2PDCm2P6PzLMkJpL+bjowNsQlpHOBFusNuDLnNk2xmlOSLa9YtdXNzeWKBPKyfGelRSP2Ce3bp7QeV5rwsDSl+xjtrlwSpqW8Ih/Soyp7PRxThsyBDfGclhdlqWrKWa/C5rQ9pJdRzFzSw/Z0kyNUmce16zurf6FpzmNfPqJHu7dP16+iQYesC0sspGyM9lDKNEnKI8a4M7aOfykQxR+bzMarMHm5QjKxzdycXCZhE+dwcpyv3JLjZsv+rB85s+kg4dzMBwAAAAAAAAAAAAAAAAAAAAAAQMT8BauOex3Hfqj9AAAAAElFTkSuQmCC" className="card-img-top" alt="Card Image"/>
                    <div className="card-body shadow">
                    <h5 className="card-title">Card 2</h5>
                    <div>
                        <div className='text-start' >
                            <span style={{marginRight:'5px'}}>Értékelés:</span>
                            <span className=' fw-bold'>4.0</span>
                        </div>
                      </div>
                      <div className='text-end'>
                        <p className='badge bg-dark'>Raktáron</p>
                      </div>
                       <div className="container mt-0 w-75">
                          <button className="btn btn-primary">
                              <img className='' style={{width:'20px'}} src="https://cdn-icons-png.flaticon.com/128/2636/2636890.png" alt="" />
                              <span className='mx-2'>Kosárba</span>
                          </button>
                       </div>  
                    </div>
                  </div>
                </div>
                <div className="d-flex col-md-3">
                  <div className="card rounded-1 custom-card w-100 shadow">
                    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAflBMVEX///8AAADPz8/b29thYWG4uLihoaFvb2+IiIj7+/tsbGzt7e3T09POzs52dnZTU1Pj4+Onp6e+vr7GxsYcHBwzMzOAgIA5OTmTk5P19fUuLi7m5uZbW1ulpaWVlZU0NDQ/Pz9EREQODg4iIiJLS0sfHx97e3sXFxewsLBUVFT4yHDIAAAGM0lEQVR4nO2da3uiMBBG661dxRtqrdiudlu3uv//D25L1wAyuU8gPPuej5XKHCEXQjK5uwMAAAAAAAAAAAAAAAAAAAAAAPBfME6ms37kzKaDZOxmN5o/9brCcT6ytZwN2w7amuHUwm/w2na4TiwGhn7ZQ9uhOjM3ulenbYfphcFlTNuO0ZOVTvC+7Qi9uagFR23Hx4DyKt6Uwf38kK7WbbfpStary/38sRq2oiyOy8edRonulo6GbPWnFPlZfmCpmT+Zti2xsFwUwW9lB/WLYw5NBsdEqZKUXZ6iH5o2GhoXRTX5Qh8wEwfsmo2MjeIqLsnPX0QV2nBgfIj+9IT6NBM/wKzpwNgoWjuqgzrq/iUsXUSq2Z9fP7xvPC4+RK+aajA2uqq2CyyvEq/Eh+IWbjgoXhQWwv5X82ExIno2We2jwfWjufS/n0e7+eRhm9oMiDSNqE3qLaIw/EH/a7LbizugN4m2QdnJaxNhSFal2bxX5bEfPFgnUkfDVa+O/G5uk5Gb4Q9C8PMy1gtz+7gZ3t6hV94ifER2MqSv4BfvjQRthYvhWirY6w2bCdsCB8Mx7fYP7ehk0zgYyu/RnECBTt8dy7i9YUaLCcKMd3zFST+mm/ynnaFuDDzIw+T3fePUb7I3PGoMQzxrXQc1Rw7/a22ou0kDPC9nTz7fbW2oaiq+Icd8PFiWv1zyFKDA2lD/rk0xhO7CzU9q/ftZG+56Wjx06tQqtpPlF1gbalrDL9ymetAQPeAnu/593NdwfCJPYNX2WxsavBL21CpIfkvOYNMgBahL2QauFDMkLNp+a8NnraH0XZ0lyvfr5m2/fZ/mrDNce7vlaKo047bf3lBbmfJUpdpJZqZtv73hgD6hgGU8KjOYI/gQyrB4q0jDMVSzVJ/iH4tQhurTc9Qz+vr6m6NJgXAZp1GVxDeGUmg+C2tjcMM4jbUppmIyvMGQDVWS6J/7nQzHe/p0HONQ44Xsu2m07xLcRoTHj/Tp/AWTDf3NcnTndBzVJ2+ls//4hctU1p9hDO/Wb7dnYqhF3SZCqtt+Z8PPp/1Kadw++wsaPJmRKDsZHoafLWM6eTr33vaLHcv7UffVAKq238swh+uJPvNZDvBLHoW/IRNmHTUpZ2nbH4uhaUdNjqztj8Twp7egtDsV0vDDuHq16qhJodv+cIbZ3vhx37KjJoV87RXM8HsCtcnc6eSdSZCe6BvK8Dr4r3/rzbrmiGj7AxlOxDk3msLIvGKlPp87iGF1lEVZGF07alJemzDs35xUURgDLNt8v3mtEcCw3rbJCqNXR01Ote3nN5wQ53wnC6NnR01Ope3nNkwkA51EYfTvqMmovEVlNpRX/bXCyNFRk1AZK+Y1VEV9U49/hBMMaKheEL0vP+BwddRIQhkmkgG4AlEYGTtqFIEMTXpfh5tvDkQYQ7Oh+GHlnKEIYmiak2D/zN9RqxHAMNFOditoIL8Gv+FtR7Rt2A0Dtt1ucBtSHdF24TXMLIpgU7AaxlYEczgNoyuCOYyG8RXBHDZD2bNg63AZRlkEc5gM4yyCOTyGkRbBHA5D/bNgmzAYRp79y98w9uRY3oYxF8EcT8NEOuUrGvwMIy+COX6G23aCtsLP0GDNTOvAEIbxA0MYxg8MYRg/MIRh/MAQhvEDQxjGDwxhGD8whGH8wBCG8QNDGMYPDGEYPzCsGVbWD3fO8HL9q8KwkpalC4aV1XmH61/rhmIBZOUnSV+GsfNSWQkoJo/U00qIjMFd3iro7k7sMEekPRVXvfmwGFFZiHUGMW+yokO5W45Y5tnFffOuiMzOVDYpsQ/JpvG4+BBTfanEB0Vy8ug2PDCm2P6PzLMkJpL+bjowNsQlpHOBFusNuDLnNk2xmlOSLa9YtdXNzeWKBPKyfGelRSP2Ce3bp7QeV5rwsDSl+xjtrlwSpqW8Ih/Soyp7PRxThsyBDfGclhdlqWrKWa/C5rQ9pJdRzFzSw/Z0kyNUmce16zurf6FpzmNfPqJHu7dP16+iQYesC0sspGyM9lDKNEnKI8a4M7aOfykQxR+bzMarMHm5QjKxzdycXCZhE+dwcpyv3JLjZsv+rB85s+kg4dzMBwAAAAAAAAAAAAAAAAAAAAAAQMT8BauOex3Hfqj9AAAAAElFTkSuQmCC" className="card-img-top" alt="Card Image"/>
                    <div className="card-body shadow">
                    <h5 className="card-title">Card 2</h5>
                    <div>
                        <div className='text-start' >
                            <span style={{marginRight:'5px'}}>Értékelés:</span>
                            <span className=' fw-bold'>4.0</span>
                        </div>
                      </div>
                      <div className='text-end'>
                        <p className='badge bg-dark'>Raktáron</p>
                      </div>
                       <div className="container mt-0 w-75">
                          <button className="btn btn-primary">
                              <img className='' style={{width:'20px'}} src="https://cdn-icons-png.flaticon.com/128/2636/2636890.png" alt="" />
                              <span className='mx-2'>Kosárba</span>
                          </button>
                       </div>  
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div>
            
          </div>
    </div>

    
  )
}
