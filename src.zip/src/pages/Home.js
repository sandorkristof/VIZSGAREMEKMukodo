import React, { useState } from 'react';
import './Homes.css';

export default function Home() {



  return (
    <div >
      
      <div className="container  d-flex justify-content-center align-items-center" style={{ height: "200px" }}>
      <div className="input-group search" style={{ width: "800px" }}>
        <input
          style={{ borderColor: "#04c4f4" }}
          type="text"
          className="form-control"
        />
        <button style={{backgroundColor:'#04c4f4'}} className="btn"><span id="myButton">Keresés</span></button>
      </div>
    </div>
          
          <div  className="mx-auto d-md-none d-lg-block">
            <span>Gyakori keresések</span>
            <br />
            
          </div>
          
    </div>

    
  )
  
}
