import React, { useState } from 'react';
import './Homes.css';

export default function Home() {

  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState([]);

  const handleSearch = async () => {
    try {
      const response = await fetch(`http://localhost:5259/Product/search?search=${searchTerm}`);
      const data = await response.json();
      setSearchResults(data);
      console.log(data);
      console.log(setSearchResults);
    } catch (error) {
      console.error('Hiba a keresésben', error);
    }
  };

  const handleSave = (product) => {
    // Itt lehet implementálni az adatok mentésére szolgáló logikát
    console.log('Termék mentve:', product);
    // Példa: Az adatok localStorage-ben történő mentése
    const savedProducts = JSON.parse(localStorage.getItem('savedProducts')) || [];
    savedProducts.push(product);
    localStorage.setItem('savedProducts', JSON.stringify(savedProducts));
  };
  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <div >
      
      <div className="container  d-flex justify-content-center align-items-center" style={{ height: "200px" }}>
      <div className="input-group search" style={{ width: "800px" }}>
        <input style={{ borderColor: "#04c4f4" }}type="text" className="form-control" value={searchTerm}onChange={(e) => setSearchTerm(e.target.value)}
        onKeyDown={handleKeyPress}placeholder="Keresd meg a megfelelő terméket számodra!"/>
        <button onClick={handleSearch}  style={{backgroundColor:'#04c4f4'}} className="btn"><span id="myButton">Keresés</span></button>
      </div>
      <div>
      
      </div>
    </div>
          
    <div className="container">
  <div className="row row-cols-1 row-cols-md-3 g-4">
    {searchResults.map(product => (
      <div className="col" key={product.id}>
        <div className="shadow-sm border rounded me-1">
          <img className='mt-2' src={product.photo} alt="" style={{ height: '250px', objectFit: 'fill' }}/>
          <h3>{product.brand}</h3>
          <p>{product.name}</p>
          <button className='btn btn-danger mb-3' onClick={() => handleSave(product)}>Mentés</button>
        </div>
      </div>
    ))}
  </div>
</div>



          
    </div>

    
  )
  
}
