import React, { useEffect, useState } from 'react';
import { useCookies } from 'react-cookie';
import { Link,Route,Routes } from "react-router-dom";
import cpuImg from '../image/homeIMG/CPUtry.jpg';
import gpuImg from '../image/homeIMG/GPUtry.jpg';
import tvImg from '../image/homeIMG/TVtry.jpg';


import './Homes.css';

export default function Home() {

  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [cart, setCart] = useState([]);
  const [products, setProducts] = useState([]);
  const history = useCookies();
  const [searchActive, setSearchActive] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const images =[cpuImg,gpuImg,tvImg];


  useEffect(() => {
    // Betöltjük a kosarat a localStorage-ból
    const existingCart = JSON.parse(localStorage.getItem('cart')) || [];
    setCart(existingCart);
  }, []);

  const handleSearch = async () => {
    if(!searchTerm.trim()){
      console.log('Adj meg egy értéket!');
    }else{
      
        try {
          const response = await fetch(`http://localhost:5259/Product/search?search=${searchTerm}`);
          const data = await response.json();
          setSearchResults(data);
          console.log(data);
          console.log(setSearchResults);
          setSearchActive(true);
        } catch (error) {
          console.error('Hiba a keresésben', error);
        }
    }

  };

  const handleAddToCart = (product) => {
    setCart((prevCart) => {
      const existingCartItemIndex = prevCart.findIndex((item) => item.id === product.id);
  
      if (existingCartItemIndex !== -1) {
        // Ha a termék már szerepel a kosárban, csak növeljük a mennyiséget
        const updatedCart = [...prevCart];
        updatedCart[existingCartItemIndex].quantity += 1;
        localStorage.setItem('cart', JSON.stringify(updatedCart));
        return updatedCart;
      } else {
        // Ha a termék még nem szerepel a kosárban, hozzáadjuk
        const newCartItem = {
          id: product.id,
          brand: product.brand,
          name: product.name,
          price: product.price,
          quantity: 1,
          photo: product.photo,
        };
        const updatedCart = [...prevCart, newCartItem];
        localStorage.setItem('cart', JSON.stringify(updatedCart));
        return updatedCart;
      }
    });
  };
  
  
  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      handleSearch();
    }
  };
  

 

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [images.length]);

  

  const pageRoutes = {
    0: '/Processzorok',   
    1: '/Videokartya',   
    2: '/Televíziók',    
    
  };




  return (
    <div >
    {/*Eleje*/}
  
   {!searchActive && (
  <div className="rounded-image-slider d-inline-flex" style={{ height: '400px', width: '650px',  marginTop: '15px', position: 'relative', overflow: 'hidden'}}>
    {images.map((imageUrl, index) => (
      <Link to={pageRoutes[index]} key={index}>
        <img
          src={imageUrl}
          className={`d-block rounded-4  w-100  shadow ${index === currentImageIndex ? 'active' : ''}`}
          alt={`Slide ${index + 1}`}
          style={{
            position: 'absolute',
            top: 0,
            left: index === currentImageIndex ? 0 : '100%',
            transition: 'left 1.7s ease-in-out', 
          }}
        />
      </Link>
    ))}
  </div>
)}
    {/*Vége*/}
      <div className="container  d-flex justify-content-center align-items-center" style={{ height: "100px" }}>
      <div className="input-group search" style={{ width: "900px" }}>
      <input style={{ borderColor: "#04c4f4" }} type="text" className="form-control" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}  placeholder='Keresse meg termékeit!'/>
        <button  onClick={handleSearch}  style={{backgroundColor:'#04c4f4'}} className="btn"><span id="myButton">Keresés</span></button>
      </div>
      <div>
      
      </div>
    </div>
          
    <div className="container">
  <div className="row row-cols-1 row-cols-md-3 g-4">
    {searchResults.map(product => (
      <div className="col" key={product.id}>
        <div className="shadow-sm border rounded me-1">
          <img className='mt-2' src={product.photo} alt="" style={{ height: '250px', objectFit: 'fill' }}/>
          <h3>{product.brand}</h3>
          <p>{product.name}</p>
          <p>{product.price} Ft</p>
          <button className='btn mb-3' style={{backgroundColor: '#04c4f4'}} onClick={() => handleAddToCart(product)}>Kosár</button>
        </div>
      </div>
    ))}
  </div>
</div>



          
    </div>

    
  )
  
}
