import React, { useState } from 'react';
import { Link,Route,Routes } from "react-router-dom";
export default function Rendeles() {
 

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    zipcode: '',
    city: '',
    address: ''
  });

  // Adatok mentése a localStorage-ba
  const AdatMentesLocalStorage = () => {
    localStorage.setItem('szallitasiAdatok', JSON.stringify(formData));
    localStorage.setItem('telefonszam', formData.phone);
  };

  // Adatok visszaállítása a localStorage-ból
  const AdatBetoltesLocalStorage = () => {
    const mentettAdat = localStorage.getItem('szallitasiAdatok');
    if (mentettAdat) {
      setFormData(JSON.parse(mentettAdat));
    }
  };

  // Az input mezők változásának kezelése és az adatok mentése
  const ValtozasKezeles = (e) => {
    const { id, value } = e.target;
    setFormData((adatEloz) => ({
      ...adatEloz,
      [id]: value
    }));
    AdatMentesLocalStorage();
  };
 




  return (
    <div className="container-xl" >
    <div className="row d-flex justify-content-center mt-5" >
      <div className="col-lg-8 d-flex justify-content-center" >
        <div className="card d-block" style={{width:'1000px'}}>
          <div className="card-body ">
            <h5 className="card-title mb-4">Rendelés</h5>
            <form>
              <div className="row">
                <div className="col-md-6 mb-3">
                  <label htmlFor="name" className="form-label">Szállítási név</label>
                  <input type="text" className="form-control" id="name" value={formData.name} onChange={ValtozasKezeles} placeholder="Név" />
                </div>
                <div className="col-md-6 mb-3">
                  <label htmlFor="email" className="form-label">Email cím</label>
                  <input type="email" className="form-control" id="email" value={formData.email} onChange={ValtozasKezeles} placeholder="Email cím" />
                </div>
                <div className="col-md-6 mb-3">
                  <label htmlFor="phone" className="form-label">Telefonszám</label>
                  <input type="tel" className="form-control" id="phone" value={formData.phone} onChange={ValtozasKezeles} placeholder="Telefonszám" />
                </div>
              </div>
              <div className="row">
                <div className="col-md-6 mb-3">
                  <label htmlFor="zipcode" className="form-label">Irányítószám</label>
                  <input type="text" className="form-control" id="zipcode" value={formData.zipcode} onChange={ValtozasKezeles} placeholder="Irányítószám" />
                </div>
                <div className="col-md-6 mb-3">
                  <label htmlFor="city" className="form-label">Város</label>
                  <input type="text" className="form-control" id="city" value={formData.city} onChange={ValtozasKezeles} placeholder="Város" />
                </div>
              </div>
              <div className="mb-3">
                <label htmlFor="address" className="form-label">Utca/Házszám/Ajtó</label>
                <input type="text" className="form-control" id="address" value={formData.address} onChange={ValtozasKezeles} placeholder="Utca/Házszám/Ajtó" />
              </div>
              <Link to="/RendelesReszletei">
                <button type="button" className="btn btn-primary" onClick={AdatBetoltesLocalStorage}>Tovább</button>
              </Link>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  

  )
}
