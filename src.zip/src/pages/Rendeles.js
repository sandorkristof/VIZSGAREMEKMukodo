import React from 'react'

export default function Rendeles() {
  return (
    <div className="container">
      <div className="row d-flex justify-content-center  mt-5">
        <div className="col-md-6 d-flex justify-content-center" >
          <div className="card">
            <div className="card-body">
              <h5 className="card-title mb-4">Bejelentkezés</h5>
              <form>
              <div className="mb-3">
                  <label htmlFor="text" className="form-label">Teljes név</label>
                  <input type="text" className="form-control" id="Name" value={name} onChange={(e) => setName(e.target.value)} placeholder='Név'/>
                </div>
                <div className="mb-3">
                  <label htmlFor="email" className="form-label">Email cím</label>
                  <input type="email" className="form-control" id="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder='Email cím'/>
                </div>
                <div className="mb-3">
                  <label htmlFor="password" className="form-label">Jelszó</label>
                  <input type="password" className="form-control" id="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder='***'/>
                </div>
                <button type="button" className="btn btn-primary" onClick={handleSubmit}>Bejelentkezés</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
