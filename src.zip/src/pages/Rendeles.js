import React from 'react'

export default function Rendeles() {
  return (
    <div>
      
    </div>
  )
}
