import React, { useState } from 'react';
import { Link,Route,Routes } from "react-router-dom";
export default function Rendeles() {
 

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    zipcode: '',
    city: '',
    address: ''
  });

  // Adatok mentése a localStorage-ba
  const saveDataToLocalStorage = () => {
    localStorage.setItem('szallitasiAdatok', JSON.stringify(formData));
  };

  // Adatok visszaállítása a localStorage-ból
  const loadDataFromLocalStorage = () => {
    const savedData = localStorage.getItem('szallitasiAdatok');
    if (savedData) {
      setFormData(JSON.parse(savedData));
    }
  };

  // Az input mezők változásának kezelése és az adatok mentése
  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [id]: value
    }));
    saveDataToLocalStorage();
  };
 




  return (
    <div className="container-xl" >
    <div className="row d-flex justify-content-center mt-5" >
      <div className="col-lg-8 d-flex justify-content-center" >
        <div className="card d-block" style={{width:'1000px'}}>
          <div className="card-body ">
            <h5 className="card-title mb-4">Rendelés</h5>
            <form>
              <div className="row">
                <div className="col-md-6 mb-3">
                  <label htmlFor="name" className="form-label">Szállítási név</label>
                  <input type="text" className="form-control" id="name" value={formData.name} onChange={handleChange} placeholder="Név" />
                </div>
                <div className="col-md-6 mb-3">
                  <label htmlFor="email" className="form-label">Email cím</label>
                  <input type="email" className="form-control" id="email" value={formData.email} onChange={handleChange} placeholder="Email cím" />
                </div>
                <div className="col-md-6 mb-3">
                  <label htmlFor="phone" className="form-label">Telefonszám</label>
                  <input type="phone" className="form-control" id="phone" value={formData.phone} onChange={handleChange} placeholder="Telefonszám" />
                </div>
              </div>
              <div className="row">
                <div className="col-md-6 mb-3">
                  <label htmlFor="zipcode" className="form-label">Irányítószám</label>
                  <input type="text" className="form-control" id="zipcode" value={formData.zipcode} onChange={handleChange} placeholder="Irányítószám" />
                </div>
                <div className="col-md-6 mb-3">
                  <label htmlFor="city" className="form-label">Város</label>
                  <input type="text" className="form-control" id="city" value={formData.city} onChange={handleChange} placeholder="Város" />
                </div>
              </div>
              <div className="mb-3">
                <label htmlFor="address" className="form-label">Utca/Házszám/Ajtó</label>
                <input type="text" className="form-control" id="address" value={formData.address} onChange={handleChange} placeholder="Utca/Házszám/Ajtó" />
              </div>
              <Link to="/RendelesReszletei">
                <button type="button" className="btn btn-primary" onClick={loadDataFromLocalStorage}>Tovább</button>
              </Link>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  

  )
}
