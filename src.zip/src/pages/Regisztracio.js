import React, { useState } from 'react';

const Regisztracio = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:5259/User/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, email, password }),
      });

      const data = await response;
      if (response.ok) {
        alert("Sikeres volt a regisztráció!");
        console.log('Registration successful');
      window.location.href='/Bejelentkezes';
    } else {
      console.error('Registration failed:', response.statusText);
    }
  } catch (error) {
    console.error('Registration failed:', error);
  }
  };

  return (
    <div className="container">
      <div className="row d-flex justify-content-center  mt-5">
        <div className="col-md-6 d-flex justify-content-center" >
          <div className="card">
            <div className="card-body">
              <h5 className="card-title mb-4">Regisztráció</h5>
              <form>
              <div className="mb-3">
                  <label htmlFor="text" className="form-label">Teljes név</label>
                  <input type="text" className="form-control" id="Name" value={name} onChange={(e) => setName(e.target.value)} placeholder='Név'/>
                </div>
                <div className="mb-3">
                  <label htmlFor="email" className="form-label">Email cím</label>
                  <input type="email" className="form-control" id="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder='Email cím'/>
                </div>
                <div className="mb-3">
                  <label htmlFor="password" className="form-label">Jelszó</label>
                  <input type="password" className="form-control" id="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder='***'/>
                </div>
                <button type="button" className="btn btn-primary" onClick={handleSubmit}>Bejelentkezés</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Regisztracio;
