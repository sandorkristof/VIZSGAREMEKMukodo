import React, { useState } from 'react';
import { Link,Route,Routes } from "react-router-dom";

const Regisztracio = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [nameError, setNameError] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
const [confirmPasswordError, setConfirmPasswordError] = useState('');


const handleConfirmPasswordChange = (e) => {
  const { value } = e.target;
  setConfirmPassword(value);
};

const handleSubmit = async (e) => {
  e.preventDefault();

  // Ellenőrzés, hogy minden mező ki legyen töltve és a jelszavak egyezzenek
  let formIsValid = true;
  if (!name) {
    setNameError('A név megadása kötelező');
    formIsValid = false;
  } else {
    setNameError('');
  }

  if (!email) {
    setEmailError('Az email cím megadása kötelező');
    formIsValid = false;
  } else {
    setEmailError('');
  }

  if (!password) {
    setPasswordError('A jelszó megadása kötelező');
    formIsValid = false;
  } else {
    setPasswordError('');
  }

  if (!confirmPassword) {
    setConfirmPasswordError('A jelszó megerősítése kötelező');
    formIsValid = false;
  } else {
    setConfirmPasswordError('');
  }

  if (password !== confirmPassword) {
    setConfirmPasswordError('A jelszavak nem egyeznek');
    return; // Ne folytassuk a további feldolgozást
  } else {
    setConfirmPasswordError(''); // Ha egyezik, töröljük az előző hibaüzenetet
  }

  if (formIsValid) {
    try {
      const response = await fetch('http://localhost:5259/User/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, email, password }),
      });

      if (response.ok) {
        alert("Sikeres volt a regisztráció!");
        //console.log('Registration successful');
        window.location.href = '/RegisztracioMegerosites';
      } else {
        console.error('Regisztráció failed:', response.statusText);
      }
    } catch (error) {
      console.error('Registration failed:', error);
    }
  }
};

return (
  <div className="container">
    <div className="row d-flex justify-content-center mt-5">
      <div className="col-md-6 d-flex justify-content-center">
        <div className="card">
          <div className="card-body">
            <h5 className="card-title mb-4">Regisztráció</h5>
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label htmlFor="text" className="form-label">Név</label>
                <input
                  type="text"
                  className={`form-control ${nameError ? 'border border-danger' : ''}`}
                  id="Name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder='Név'
                />
                {nameError && <div className="text-danger">{nameError}</div>}
              </div>
              <div className="mb-3">
                <label htmlFor="email" className="form-label">Email cím</label>
                <input
                  type="email"
                  className={`form-control ${emailError ? 'border border-danger' : ''}`}
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder='Email cím'
                />
                {emailError && <div className="text-danger">{emailError}</div>}
              </div>
              <div className="mb-3">
                <label htmlFor="password" className="form-label">Jelszó</label>
                <input
                  type="password"
                  className={`form-control ${passwordError ? 'border border-danger' : ''}`}
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder='***'
                />
                {passwordError && <div className="text-danger">{passwordError}</div>}
              </div>
              <div className="mb-3">
                <label htmlFor="confirmPassword" className="form-label">Jelszó megerősítése</label>
                <input
                  type="password"
                  className={`form-control ${confirmPasswordError ? 'border border-danger' : ''}`}
                  id="confirmPassword"
                  value={confirmPassword}
                  onChange={handleConfirmPasswordChange}
                  placeholder='***'
                />
                {confirmPasswordError && <div className="text-danger">{confirmPasswordError}</div>}
              </div>
              <button type="submit" className="btn btn-primary ">Regisztráció</button>
              <Link to="/RegisztracioMegerosites" className="btn text-decoration-none">Fiók megerősítése</Link>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  );
};

export default Regisztracio;
