import React from 'react'
import { Link,Route,Routes } from "react-router-dom";



export default function Regisztracio() {
  return (
    <div className='d-flex justify-content-center align-items-center bg-white vh-100'>
      <div className='bg-white p-3 rounded w-25 border shadow'>
      <h2>Regisztráció</h2>
        <form action="" >
          <div className='mb-3'>
            <label htmlFor="email"><strong>Email </strong></label>
            <input type="email" placeholder='Írj ide e-mail címet' className='form-control rounded-2 shadow'  name='email'/>
          </div>
          <div className='mb-3'>
            <label htmlFor="password"><strong>Jelszó</strong></label>
            <input type="password" placeholder='Írj ide jelszót' className='form-control rounded-2 shadow' name='password'/>

          </div>
          <div className='mb-3'>
            <label htmlFor="password"><strong>Jelszó újra</strong></label>
            <input type="password" placeholder='Írj ide jelszót' className='form-control rounded-2 shadow' name='password'/>

          </div>
          <button type='submit' className='btn btn-primary w-100 rounded-2 shadow'><strong>Regisztráció</strong></button>
          <div class="form-check mt-2 mb-3">
                <input class="form-check-input shadow" type="checkbox" value="" id="checkbox1"/>
                <label class="form-check-label" for="checkbox1">Elfogadom a felhasználási feltételeket</label>
          </div>
          <Link to='/Bejelentkezes' className='btn btn-default border w-100 bg-success rounded-2 text-decoration-none text-white'>Jelentkezz be!</Link>
        </form>
      </div>
    </div>
  )
}
