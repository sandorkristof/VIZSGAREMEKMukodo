import React, { useState } from 'react'
import ReactDOM from 'react-dom';
import axios from 'axios';
import { Link,Route,Routes } from "react-router-dom";



export default function Regisztracio() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [Repassword, setRePassword] = useState('');


  
 
  const register = async () => {
    try {
      const response = await axios.post('http://localhost:3000/register', {
        email,
        password,
        Repassword,
      });
      console.log(response.data);
    } catch (error) {
      console.error(error);
    }
  };




  return (
    <div className="container mt-5">
  <div className="row justify-content-center">
    <div className="col-12 col-md-6 col-lg-4">
      <div className="bg-white p-3 rounded border shadow">
        <h2 className="text-center">Regisztráció</h2>
        <form action="">
          <div className="mb-3">
            <label htmlFor="email"><strong>Email</strong></label>
            <input type="email" placeholder="Írj ide e-mail címet" onChange={(e) => setEmail(e.target.value)} value={email} className="form-control rounded-2 shadow" name="email" />
          </div>
          <div className="mb-3">
            <label htmlFor="password"><strong>Jelszó</strong></label>
            <input type="password" placeholder="Írj ide jelszót" onChange={(e) => setPassword(e.target.value)} value={password} className="form-control rounded-2 shadow" name="password" />
          </div>
          <div className="mb-3">
            <label htmlFor="rePassword"><strong>Jelszó újra</strong></label>
            <input type="password" placeholder="Írj ide jelszót" onChange={(e) => setRePassword(e.target.value)} value={Repassword} className="form-control rounded-2 shadow" name="rePassword" />
          </div>
          <button type="submit" style={{ backgroundColor: '#04c4f4' }} onClick={register} className="btn w-100 rounded-2 shadow text-light"><strong>Regisztráció</strong></button>
          <div className="form-check mt-2 mb-3">
            <input className="form-check-input shadow" type="checkbox" value="" id="checkbox1" />
            <label className="form-check-label" htmlFor="checkbox1">Elfogadom a felhasználási feltételeket</label>
          </div>
          <Link to="/Bejelentkezes" className="btn btn-default border w-100 bg-success rounded-2 text-decoration-none text-white">Jelentkezz be!</Link>
        </form>
      </div>
    </div>
  </div>
</div>
  )
}
