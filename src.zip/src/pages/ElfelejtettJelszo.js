import React, { useState } from 'react';

export default function ElfelejtettJelszo() {
  const [email, setEmail] = useState('');
  const [resetResult, setResetResult] = useState('');

  const handleResetPassword = async (e) => {
    e.preventDefault(); // Megakadályozza az oldal újratöltését a form submit után

    try {
      const response = await fetch('http://localhost:5259/User/resetPassword', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });

      if (response.ok) {
        setResetResult('Jelszó visszaállítás kérése elküldve.');
      } else {
        setResetResult('Sikertelen jelszó visszaállítás kérés.');
      }
    } catch (error) {
      console.error('Hiba történt a jelszó visszaállítása során:', error);
      setResetResult('Hiba történt a jelszó visszaállítása során.');
    }
  };

    
      
      return (
        <div className="container">
    <div className="row d-flex justify-content-center mt-5">
      <div className="col-md-6 d-flex justify-content-center">
        <div className="card">
          <div className="card-body">
            <h5 className="card-title mb-4">Elfelejtett jelszó</h5>
            <form >
              <div className="mb-3">
                <label htmlFor="email" className="form-label">E-mail cím</label>
                <input className="form-control" type="email"  placeholder="E-mail"/>
              </div>
              <button type="submit" className="btn btn-primary">Jelszó visszaállítása</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  )
}
