import React, { useState } from 'react';

export default function ElfelejtettJelszo() {
    const [recipientEmail, setRecipientEmail] = useState('');
    const[transporter,setTransporter]=useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
          const mailOptions = {
            from: 'mesawebshop@gmail.com', // Küldő e-mail cím
            to: recipientEmail, // Címzett e-mail cím
            subject: 'Elfelejtett jelszó', // E-mail tárgya
            text: 'Itt a visszaállítási link: ...', // E-mail szövege
          };
      
          const response = await fetch('http://localhost:5259/User/reset-password', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email: recipientEmail }),
          });
      
          if (response.ok) {
            alert("Sikeres email küldés!");
            console.log('A visszaállítási e-mail sikeresen elküldve');
            // E-mail küldése Nodemailer-rel
            transporter.sendMail(mailOptions, (error, info) => {
              if (error) {
                console.error('Hiba történt az e-mail küldésekor:', error);
              } else {
                console.log('Az e-mail sikeresen elküldve:', info.response);
              }
            });
          } else {
            console.error('Sikertelen visszaállítás:', response.statusText);
          }
        } catch (error) {
          console.error('Hiba történt az e-mail küldésekor:', error);
        }
      };
      
      return (
        <div className="container">
    <div className="row d-flex justify-content-center mt-5">
      <div className="col-md-6 d-flex justify-content-center">
        <div className="card">
          <div className="card-body">
            <h5 className="card-title mb-4">Elfelejtett jelszó</h5>
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label htmlFor="email" className="form-label">E-mail cím</label>
                <input className="form-control" type="email" value={recipientEmail} onChange={(e) => setRecipientEmail(e.target.value)} placeholder="E-mail"/>
              </div>
              <button type="submit" className="btn btn-primary">Jelszó visszaállítása</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  )
}
