import React, { useEffect, useState } from 'react';
import './style.css';

export default function Televizio() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const apiUrl = 'http://localhost:5259/Product/getAll';
      try {
        const response = await fetch(apiUrl);
        const data = await response.json();
        setProducts(data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    
    fetchData();
  }, []);

  return (
    <div className='container mt-5'>
      <div className='row row-cols-1 row-cols-md-3 g-4'>
        {products.map(product => (
          <div key={product.id} className='col'>
            <div className='card shadow-sm' style={{ height: '500px' }}>
              <img src={product.photo} alt={product.name} className='card-img-top' style={{ height: '200px', objectFit: 'contain' }} />
              <div className='card-body'>
                <h5 className='card-title'>{product.name}</h5>
                <p className='card-text'>{product.description}</p>
                <p className='card-text'>
                  <strong>Ár:</strong> {product.Ar} HUF
                </p>
                {/* Add more fields as needed */}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
