import React from 'react'

export default function Szamitogep() {
  return (
    <div>
            <span>Szia ez a számítógép weboldal része </span>  
    </div>
  )
}
