import React from 'react'
import { Link,Route,Routes } from "react-router-dom";
import ImgAlaplap from '../image/alaplap.png';
import Imgcpu from '../image/cpu.png';
import Imggephaz from '../image/gephaz.png';
import Imggpu from '../image/gpu.png';
import Imgtapegyseg from '../image/tapegyseg.png';
import ImgRam from '../image/ram.png';

export default function Szamitogep() {
  return (
    <div>
    <div className=''>
      <div style={{marginTop:'30px'}} class="container">
        <div  class="row justify-content-center">
        <Link class="col-sm-2 shadow border me-3 mb-3" to="/Alaplapok" style={{textDecoration:'none'}}>
            <img src={ImgAlaplap} alt="image1" class="img-fluid rounded" />
            <div style={{marginBottom:'3px',fontSize:'20px'}} class="font-weight-bold text-uppercase text-dark">Alaplapok</div>
          </Link>
          <Link class="col-sm-2 shadow border me-3 mb-3" to="/Processzorok" style={{textDecoration:'none'}}>
            <img src={Imgcpu} alt="image2" class="img-fluid rounded"/>
            <div style={{marginBottom:'3px',fontSize:'20px'}} class="font-weight-bold text-uppercase text-dark">Processzorok</div>
          </Link>
          <Link class="col-sm-2 shadow border me-3 mb-3" to="/Gépházak" style={{textDecoration:'none'}}>
            <img src={Imggephaz} alt="image3" class="img-fluid rounded"/>
            <div style={{marginBottom:'3px',fontSize:'20px'}} class="font-weight-bold text-uppercase text-dark">Számítógépházak</div>
          </Link>
          </div>
          <div class="row justify-content-center">
          <Link class="col-sm-2 shadow border me-3 mb-3" to="/Videokartya" style={{textDecoration:'none'}}>
              <img src={Imggpu} alt="image4" class="img-fluid rounded"/>
              <div style={{marginBottom:'3px',fontSize:'20px'}} class="font-weight-bold text-uppercase text-dark">Videókártyák</div>
          </Link>
          <Link class="col-sm-2 shadow border me-3 mb-3" to="/Tápegységek" style={{textDecoration:'none'}}>
              <img src={Imgtapegyseg} alt="image5" class="img-fluid rounded"/>
              <div style={{marginBottom:'3px',fontSize:'20px'}} class="font-weight-bold text-uppercase text-dark">Tápegységek</div>
          </Link>
          <Link class="col-sm-2 shadow border me-3 mb-3" to="/Memóriák" style={{textDecoration:'none'}}>
              <img src={ImgRam} alt="image6" class="img-fluid rounded"/>
              <div style={{marginBottom:'3px',fontSize:'20px'}} class="font-weight-bold text-uppercase text-dark">Memóriák</div>
          </Link>
        </div>
      </div>

    </div>



  </div>
  )
}
