import React from 'react';
import './CardPageSelect.css';
import { Link } from "react-router-dom";
import ImgAlaplap from '../image/alaplap.png';
import Imgcpu from '../image/cpu.png';
import Imggephaz from '../image/gephaz.png';
import Imggpu from '../image/gpu.png';
import Imgtapegyseg from '../image/tapegyseg.png';
import ImgRam from '../image/ram.png';

export default function Szamitogep() {
  return (
    <div>
    <div className="container mt-4 w-50">
  <div className="row row-cols-2 row-cols-md-4 g-3 justify-content-center">
    <Link id='Dobozok' className="col  border rounded me-3 mb-3" to="/Alaplapok" style={{ textDecoration: 'none' }}>
      <img src={ImgAlaplap} alt="image1" className="img-fluid rounded" />
      <div style={{ marginBottom: '3px', fontSize: '20px' }} className="font-weight-bold text-uppercase text-dark">Alaplapok</div>
    </Link>
    <Link id='Dobozok' className="col  border rounded me-3 mb-3" to="/Processzorok" style={{ textDecoration: 'none' }}>
      <img src={Imgcpu} alt="image2" className="img-fluid rounded" />
      <div style={{ marginBottom: '3px', fontSize: '20px' }} className="font-weight-bold text-uppercase text-dark">Processzorok</div>
    </Link>
    <Link id='Dobozok' className="col  border rounded me-3 mb-3" to="/Gépházak" style={{ textDecoration: 'none' }}>
      <img src={Imggephaz} alt="image3" className="img-fluid rounded" />
      <div style={{ marginBottom: '3px', fontSize: '20px' }} className="font-weight-bold text-uppercase text-dark">Gépházak</div>
    </Link>
    <Link id='Dobozok' className="col  border rounded me-3 mb-3" to="/Videokartya" style={{ textDecoration: 'none' }}>
      <img src={Imggpu} alt="image4" className="img-fluid rounded" />
      <div style={{ marginBottom: '3px', fontSize: '20px' }} className="font-weight-bold text-uppercase text-dark">Videokártyák</div>
    </Link>
    <Link id='Dobozok' className="col  border rounded me-3 mb-3" to="/Tápegységek" style={{ textDecoration: 'none' }}>
      <img src={Imgtapegyseg} alt="image5" className="img-fluid rounded" />
      <div style={{ marginBottom: '3px', fontSize: '20px' }} className="font-weight-bold text-uppercase text-dark">Tápegységek</div>
    </Link>
    <Link id='Dobozok' className="col  border rounded me-3 mb-3" to="/Memóriák" style={{ textDecoration: 'none' }}>
      <img src={ImgRam} alt="image6" className="img-fluid rounded" />
      <div style={{ marginBottom: '3px', fontSize: '20px' }} className="font-weight-bold text-uppercase text-dark">Memóriák</div>
    </Link>
  </div>
</div>



  </div>
  )
}
