import React from 'react'
import Sablon from '../image/placeholder.png';



export default function Kosar() {
  let kosar=[
    {TermekId:123,TermekNev:"LG",Darab:2},
    {TermekId:200,TermekNev:"Asus",Darab:10},
  ];
  localStorage.setItem("kosarTartalma",JSON.stringify(kosar));
  console.log(JSON.parse(localStorage.getItem("kosarTartalma")));
  return (
    <div>

      <div className="container">
        <h1>Kosár</h1>
        <div className="container mt-4">
  <div className="row">
    <div className="col-md-8 left-column">
    <div className="card mb-3 shadow">
        <div className="card-body shadow">
          <div>
            <div className='img float-start'><img src={Sablon} alt="" /></div>
          </div>
           <div style={{marginTop:'91px',marginLeft:'10px',fontSize:'25px'}} className='float-start'><strong>Kosár tartalma</strong></div> 
           <div className="card-text float-end" style={{marginTop:'100px'}}>Összege: <strong>10500</strong></div> 
        </div>
      </div>
      <div className="card mb-3 shadow">
        <div className="card-body shadow">
          <h5 className="card-title">Kártya 2</h5>
          <p className="card-text">Tartalom ide...</p>
        </div>
      </div>
    </div>

  
    <div className="col-md-4 ">
      <div className="card shadow">
        <h5 className="card-title">Rendelés összegzése</h5>
        <ul className="list-group">
          <li className="list-group-item">Összeg: <strong>505.274 Ft</strong></li>
          <li className="list-group-item">Szállítási költség: <strong>4.670 Ft</strong></li>
          <li className="list-group-item">Végösszeg: <strong>509.944 Ft</strong></li>
        </ul>
        
      </div>
      <button className="btn btn-primary mt-3 shadow" style={{width:'410px'}}>Vásárlás</button>
    </div>
  </div>
</div>

        
      </div>
     




    </div>
  )
}
