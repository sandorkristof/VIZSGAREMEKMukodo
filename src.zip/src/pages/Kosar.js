import React from 'react'
import Sablon from '../image/placeholder.png';



export default function Kosar() {
  let kosar=[
    {TermekId:123,TermekNev:"LG",Darab:2},
    {TermekId:200,TermekNev:"Asus",Darab:10},
  ];
  localStorage.setItem("kosarTartalma",JSON.stringify(kosar));
  console.log(JSON.parse(localStorage.getItem("kosarTartalma")));
  return (
    <div>

      <div className="container">
        <h1>Kosár</h1>
        <div className="container mt-4">
  <div className="row">
    <div className="col-md-8 left-column">
    <div className="card mb-3 shadow">
        <div className="card-body shadow">
          <div>
            <div className='img float-start'><img src={Sablon} alt="" /></div>
          </div>
           <div style={{marginTop:'91px',marginLeft:'10px',fontSize:'25px'}} className='float-start'><strong>Kosár tartalma</strong></div> 
           <div className="card-text float-end" style={{marginTop:'100px'}}>Összege: <strong>10500</strong></div> 
        </div>
      </div>
      <div className="card mb-3 shadow">
        <div className="card-body shadow">
          <div>
            <div className='img float-start'><img src={Sablon} alt="" /></div>
          </div>
           <div style={{marginTop:'91px',marginLeft:'10px',fontSize:'25px'}} className='float-start'><strong>Kosár tartalma</strong></div> 
           <div className="card-text float-end" style={{marginTop:'100px'}}>Összege: <strong>10500</strong></div> 
        </div>
      </div>
    </div>

  
    <div className="col-md-4">
      <div style={{height:'200px'}} className="card shadow">
        <h5 className="card-title mt-3">Rendelés összege</h5>
        <div className="">
          <div className="mt-1 ms-2" style={{textAlign:'left'}}>Összeg: <span className='fw-bold' style={{float:'right'}}>505.274 <span className='fw-normal'> Ft</span></span></div>
          <div className="mt-2 ms-2" style={{textAlign:'left'}}>Szállítási összeg: <span className='fw-bold' style={{float:'right'}}>444 <span className='fw-normal'> Ft</span></span></div>
          <div className="mt-5" style={{marginLeft:'230px'}}>Végösszeg: <strong>509.944 </strong>Ft</div>
        </div>
        
      </div>
      <button className="btn btn-primary mt-3 shadow" style={{width:'410px'}}>Vásárlás</button>
    </div>
  </div>
</div>

        
      </div>
     




    </div>
  )
}
