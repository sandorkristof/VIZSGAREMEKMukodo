import React, {  useEffect, useState } from 'react'
import { CookiesProvider, useCookies } from 'react-cookie';

export default function Kosar() {

  const [cart, setCart] = useState([]);

  useEffect(() => {
    // Betöltjük a kosarat a localStorage-ból
    const existingCart = JSON.parse(localStorage.getItem('cart')) || [];
    setCart(existingCart);
  }, []);


  
 // const [cards, setCards] = useState([]);

 // useEffect(() => {
 //   fetch('http://localhost:3000/kosar')
 //     .then(response => response.json())
 //     .then(data => {
 //       setCards(data);
 //       console.log('Adatok sikeresen lekérve az adatbázisból:', data);
  //    })
 //     .catch(error => console.error('Hiba történt a adatlekérés során:', error));
 // }, []);
//  const handleDeleteCard = (id) => {
 //   const updatedCards = cards.filter(card => card.id !== id);
 //   setCards(updatedCards);
 // };
//<div className="container mt-3">
 //       <h1>Kosár</h1>
  //      <div>
   //   {cards.map(card => (
   //     <div key={card.id} className="card">
   //       <p>{card.content}</p>
   //       <button style={{width:'100px'}} className="delete-button" onClick={() => handleDeleteCard(card.id)}>Törlés</button>
   //     </div>
   //   ))}
   // </div>

        
   //   </div>


 // let kosar=[
  //  {TermekId:123,TermekNev:"LG",Darab:2},
  //  {TermekId:200,TermekNev:"Asus",Darab:10},
 // ];
 // localStorage.setItem("kosarTartalma",JSON.stringify(kosar));
 // console.log(JSON.parse(localStorage.getItem("kosarTartalma")));





  return (
    <div>
    <h1>Kosár</h1>
    <div>
      {/* Kosárban lévő termékek megjelenítése */}
      {cart.map((item, index) => (
        <div key={index}>
          {/* Termék adatai */}
          <p>{item.brand}</p>
          <p>{item.name}</p>
          <p>{item.price} Ft</p>
        </div>
      ))}
    </div>
  </div>
  )
}
