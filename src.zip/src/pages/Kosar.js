import React from 'react'

export default function Kosar() {
  return (
    <div>

      <div class="container">
        <h1>Kosár</h1>
        <ul id="product-list" class="list-group">
        </ul>

        <button id="purchase-btn" class="btn btn-success mt-3">Vásárlás</button>
      </div>





    </div>
  )
}
