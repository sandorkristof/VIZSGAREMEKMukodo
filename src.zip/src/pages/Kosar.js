import React, {  useEffect, useState } from 'react'
import { Link,Route,Routes } from "react-router-dom";


export default function Kosar() {
  const [cart, setCart] = useState([]);
  const [shippingCost, setShippingCost] = useState(0);
  const [totalPrice, setTotalPrice] = useState(0);

  useEffect(() => {
    // Betöltjük a kosarat a localStorage-ból
    const existingCart = JSON.parse(localStorage.getItem('cart')) || [];
    setCart(existingCart);

    let totalPriceFromLocalStorage = 0;
    existingCart.forEach((item) => {
      totalPriceFromLocalStorage += item.price * item.quantity;
    });

    if (existingCart.length > 0) {
      setShippingCost(2700);
    }
    setTotalPrice(totalPriceFromLocalStorage + shippingCost);
    localStorage.setItem('totalPrice', totalPriceFromLocalStorage + shippingCost);
    //console.log('Teljes összeg fizetni:', localStorage.getItem('totalPrice'));
  }, []);

  const handleRemoveFromCart = (productId) => {
    setCart((prevCart) => {
      const updatedCart = prevCart.filter((item) => item.id !== productId);
      if (cart.length === 1) {
        setShippingCost(0);
      }
      localStorage.setItem('cart', JSON.stringify(updatedCart));
      return updatedCart;
    });
  };
  
  const handleQuantityChange = (productId, change) => {
    setCart((prevCart) => {
      const updatedCart = prevCart.map((item) =>
        item.id === productId
          ? { ...item, quantity: Math.min(Math.max(1, item.quantity + change), 5) } // Mennyiség minimum 1, maximum 20
          : item
      );
  
      localStorage.setItem('cart', JSON.stringify(updatedCart));
      return updatedCart;
    });
  };
  const calculateTotalPrice = () => {
    let totalPrice = 0;
    cart.forEach((item) => {
      totalPrice += item.price * item.quantity;
    });
    return totalPrice;
  };
 
 
  const handleOrder = () => {
if (cart.length === 0) {
      alert("A kosár üres");
    }
    else {
    // Számítsuk ki az összes termék árát a kosárban
    const totalProductPrice = cart.reduce((total, product) => total + (product.price * product.quantity), 0);
    // Számítsuk ki az összes árat a kosárban és adjuk hozzá a szállítási költséget
    const totalPrice = totalProductPrice + shippingCost;
    // Itt további lépések következnének, például az adatok küldése vagy a fizetési folyamat kezdeményezése
    //console.log('Rendelés végrehajtva! Összesen:', totalPrice);
    }
  };
  
   
 // const [cards, setCards] = useState([]);

 // useEffect(() => {
 //   fetch('http://localhost:3000/kosar')
 //     .then(response => response.json())
 //     .then(data => {
 //       setCards(data);
 //       console.log('Adatok sikeresen lekérve az adatbázisból:', data);
  //    })
 //     .catch(error => console.error('Hiba történt a adatlekérés során:', error));
 // }, []);
//  const handleDeleteCard = (id) => {
 //   const updatedCards = cards.filter(card => card.id !== id);
 //   setCards(updatedCards);
 // };
//<div className="container mt-3">
 //       <h1>Kosár</h1>
  //      <div>
   //   {cards.map(card => (
   //     <div key={card.id} className="card">
   //       <p>{card.content}</p>
   //       <button style={{width:'100px'}} className="delete-button" onClick={() => handleDeleteCard(card.id)}>Törlés</button>
   //     </div>
   //   ))}
   // </div>

        
   //   </div>


 // let kosar=[
  //  {TermekId:123,TermekNev:"LG",Darab:2},
  //  {TermekId:200,TermekNev:"Asus",Darab:10},
 // ];
 // localStorage.setItem("kosarTartalma",JSON.stringify(kosar));
 // console.log(JSON.parse(localStorage.getItem("kosarTartalma")));
 const handleAllDelete = () => {
  localStorage.removeItem('cart');
  window.location.reload();
}


 return (
<div className="container mt-5">
  <div className="row">
    <div className="col-md-8">
      <div className="row">
        {cart.map((item, index) => (
          <div key={item.id} className="col-md-6 mb-3">
            <div className="card" style={{ width: '400px',height:'400px' }}>
              <img style={{ width: '200px',marginLeft:'90px',height:'180px' }} src={item.photo} className="card-img-top" alt={`${item.brand} ${item.name}`} />
              <div className="card-body text-center">
                <h5 className="card-title">{item.brand} {item.name}</h5>
                <p className="card-text">Ár: {item.price} Ft</p>
                <div className="input-group mb-3">
                  <button onClick={() => handleQuantityChange(item.id, -1)} className="btn btn-secondary">-</button>
                  <input type="text" className="form-control text-center" value={item.quantity} readOnly />
                  <button onClick={() => handleQuantityChange(item.id, 1)} className="btn btn-secondary">+</button>
                </div>
                <button onClick={() => handleRemoveFromCart(item.id)} className="btn btn-danger">Törlés</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
    <div className="col-md-4">
      <div className="card">
        <div className="card-body text-center">
          <h5 className="card-title">Rendelés összesítése</h5>
          <p className="card-text border-3 border-bottom">Termékek összesített ára: {calculateTotalPrice()} Ft</p>
          <p className="card-text border-3 border-bottom">Szállítási díj: {shippingCost} Ft</p>
          <p className="card-tex-t border-3 border-bottom">Összesen fizetendő: {calculateTotalPrice() + shippingCost} Ft</p>

          <div>
            
            <div>
      {cart.length === 0 ? (
        <p style={{ color: 'red' }}>A kosár üres</p>
      ) : (
        <Link to="/Rendeles">
        <button onClick={handleOrder} className="btn btn-primary">
          Rendelés
        </button>
        </Link>
      )}
    </div>
            
          </div>
          
        </div>
      </div>
    </div>
    <div>
      <button onClick={handleAllDelete} className='btn position-absolute bottom-0 end-0' style={{backgroundColor: '#ff1000',marginBottom:'10px',marginRight:'10px'}}>Rendelés teljes törlése</button>
    </div>
  </div>
</div>





);
}
