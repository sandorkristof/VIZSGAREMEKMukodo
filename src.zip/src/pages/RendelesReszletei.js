import React, { useState, useEffect } from 'react';

export default function RendelesReszletei() {
  const szallitas = 2700;
  const [teljesOsszeg, setTeljesOsszeg] = useState('');
  const [gombertek, setGombErtek] = useState(true);
  const [telefonszam, setTelefonszam] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    zipcode: '',
    city: '',
    address: '',
  });

  useEffect(() => {
    // Ellenőrizzük, hogy vannak-e mentett szállítási adatok a localStorage-ban
    const mentettAdat = localStorage.getItem('szallitasiAdatok');
    if (mentettAdat) {
      // Ha vannak mentett adatok, beállítjuk az űrlap adatait a mentett adatok alapján
      setFormData(JSON.parse(mentettAdat));
    } else {
      setGombErtek(false);
    }
  }, []);

  useEffect(() => {
    // Kiolvassuk a teljesOszseg értékét a localStorage-ból és kiírjuk
    const teljesOsszeg = localStorage.getItem('teljesOsszeg');
    const parsedTeljesOsszeg = parseFloat(teljesOsszeg);
    const teljesOsszegWithShipping = parsedTeljesOsszeg + szallitas;
    setTeljesOsszeg(teljesOsszegWithShipping);
  }, []);

  useEffect(() => {
    // Ellenőrizzük, hogy minden adat elérhető-e a formData-ban
    const formDataKeys = Object.keys(formData);
    const allDataProvided = formDataKeys.every(key => formData[key]);
    setGombErtek(allDataProvided);
  }, [formData]);

  const Vasarlas = async () => {
    // Vásárlás folyamatának kezelése
  };

  const TorlesLocalStoragebol = () => {
    // Töröljük a mentett szállítási adatokat a localStorage-ból
    localStorage.removeItem('szallitasiAdatok');
    // Töröljük a telefonszámot is a localStorage-ból
    localStorage.removeItem('telefonszam');
    // Alaphelyzetbe állítjuk az űrlap adatait
    setFormData({
      name: '',
      email: '',
      zipcode: '',
      city: '',
      address: ''
    });
  };

  const VisszaGomb = () => {
    window.history.back();
  };
  useEffect(() => {
    // Betöltjük a telefonszámot a localStorage-ból
    const mentettTelefonszam = localStorage.getItem('telefonszam');
    if (mentettTelefonszam) {
      setTelefonszam(mentettTelefonszam);
    }
  }, []);

  return (
    <div className="container">
      <h1>Rendelés részletei</h1>
      <table className="table">
        <tbody>
          <tr>
            <td>Szállítási név:</td>
            <td>{formData.name ? formData.name : <span style={{ color: 'red' }}>Nincs adat</span>}</td>
          </tr>
          <tr>
            <td>Email cím:</td>
            <td>{formData.email ? formData.email : <span style={{ color: 'red' }}>Nincs adat</span>}</td>
          </tr>
          <tr>
            <td>Telefonszám:</td>
            <td>{telefonszam ? telefonszam : <span style={{ color: 'red' }}>Nincs adat</span>}</td>
          </tr>
          <tr>
            <td>Irányítószám:</td>
            <td>{formData.zipcode ? formData.zipcode : <span style={{ color: 'red' }}>Nincs adat</span>}</td>
          </tr>
          <tr>
            <td>Város:</td>
            <td>{formData.city ? formData.city : <span style={{ color: 'red' }}>Nincs adat</span>}</td>
          </tr>
          <tr>
            <td>Utca/Házszám/Ajtó:</td>
            <td>{formData.address ? formData.address : <span style={{ color: 'red' }}>Nincs adat</span>}</td>
          </tr>
          <tr>
            <td>Ára:</td>
            <td>{teljesOsszeg} Ft</td>
          </tr>
        </tbody>
      </table>
      <div>
        <button className='btn btn-danger float-start' onClick={VisszaGomb}>Vissza</button>
        {gombertek && (
          <button className='btn btn-primary' onClick={Vasarlas}>Vásárlás</button>
        )}
        <div className='position-relative'>
          <button className="btn btn-danger position-absolute top-0 end-0" onClick={TorlesLocalStoragebol}>Adatok törlése</button>
        </div>
      </div>
    </div>
  );
}
