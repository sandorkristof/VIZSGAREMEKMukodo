import React, { useState, useEffect,useHistory } from 'react';

export default function RendelesReszletei() {
  const szallitas = 2700;
  const felhasznalo = localStorage.getItem('felhasznalo');
  
  const [teljesOsszeg, setTeljesOsszeg] = useState('');
  const [gombertek, setGombErtek] = useState(true);
  const [telefonszam, setTelefonszam] = useState();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    zipcode: '',
    city: '',
    address: '',
  });

  useEffect(() => {
        // Ellenőrizzük, hogy vannak-e mentett szállítási adatok a localStorage-ban
    const mentettAdat = localStorage.getItem('szallitasiAdatok');
    if (mentettAdat) {
       // Ha vannak mentett adatok, beállítjuk az űrlap adatait a mentett adatok alapján
      setFormData(JSON.parse(mentettAdat));
      console.log(mentettAdat);
    }
    else{
      setGombErtek(false);
    }
  }, []);
  const TorlesLocalStoragebol = () => {
    // Töröljük a mentett szállítási adatokat a localStorage-ból
    localStorage.removeItem('szallitasiAdatok');
     // Alaphelyzetbe állítjuk az űrlap adatait
    setFormData({
      name: '',
      email: '',
      phone: '',
      zipcode: '',
      city: '',
      address: ''
    });
  };
  // A useEffect hook arra szolgál, hogy az oldal betöltésekor ellenőrizze, hogy vannak-e
// mentett szállítási adatok a localStorage-ban. Ha vannak, akkor ezeket betölti az űrlapba.

// A TorlesLocalStoragebol függvény felelős a localStorage-ban tárolt szállítási adatok törléséért,
// valamint az űrlap alaphelyzetbe állításáért, hogy a felhasználó törölhesse az adatokat.

  useEffect(() => {
    // Kiolvassuk a teljesOszseg értékét a localStorage-ból és kiírjuk
    const teljesOsszeg = localStorage.getItem('teljesOsszeg');
    const parsedteljesOszseg = parseFloat(teljesOsszeg);
    const teljesOszseg = parsedteljesOszseg + szallitas;
    setTeljesOsszeg(teljesOszseg);
    //console.log('Total price from localStorage in another component:', teljesOszseg);
  }, []);
  const Vasarlas = async () => {
    try {
      // localStoragebe az adatok betöltése
      const felhasznalo = localStorage.getItem('felhasznalo');
      const addressId = localStorage.getItem('addressId');
      const orderedItems = JSON.parse(localStorage.getItem('orderedItems'));
  
      if (!felhasznalo || !addressId || !orderedItems) {
        console.error('Nincsenek elmentett adatok a localStorage-ban');
        return;
      }
  
      // Az API végpont
      const endpoint = 'http://localhost:5259/Order/postRendeles';
  
      // Request testreszabása a megfelelő formátumnak
      const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          felhasznalo: felhasznalo,
          addressId: addressId,
          orderedItems: orderedItems
        })
      };
  
      // POST kérés elküldése
      const response = await fetch(endpoint, requestOptions);
      
      // Válasz feldolgozása és az alkalmazás állapotának frissítése
      if (!response.ok) {
        throw new Error('Hiba történt a kérés során');
      }
  
      const newOrder = await response.json(); // Válaszban visszakapott új vásárlás adatai
      // Itt kellene az állapotot frissíteni a newOrder segítségével, pl. egy useEffect hook segítségével
      console.log('Vásárlás sikeresen létrehozva:', newOrder);
    } catch (error) {
      console.error('Hiba történt a vásárlás létrehozása során:', error);
    }
  };
  
  // Függvény meghívása
  Vasarlas();
  useEffect(() => {
    // Ellenőrizzük, hogy vannak-e mentett szállítási adatok a localStorage-ban
    const Tel = localStorage.getItem('telefonszam');
      if (Tel) {
        // Ha vannak mentett adatok, beállítjuk az űrlap adatait a mentett adatok alapján
        setTelefonszam(JSON.parse(Tel));
        console.log(Tel);
      }
      
      }, []);
 
  const VisszaGomb = () => {
    window.history.back();
  };
  return (
    <div className="container">
      <h1>Rendelés részletei</h1>
      
      <table className="table">
        <tbody>
          <tr>
            <td>Szállítási név:</td>
            <td>{formData.name ? formData.name : <span style={{ color: 'red' }}>Nincs adat</span>}</td>
          </tr>
          <tr>
            <td>Email cím:</td>
            <td>{formData.email ? formData.email : <span style={{ color: 'red' }}>Nincs adat</span>}</td>
          </tr>
          <tr>
            <td>Telefonszám:</td>
            <td>{formData.phone ? formData.phone : <span style={{ color: 'red' }}>Nincs adat</span>}</td>
          </tr>
          <tr>
            <td>Irányítószám:</td>
            <td>{formData.zipcode ? formData.zipcode : <span style={{ color: 'red' }}>Nincs adat</span>}</td>
          </tr>
          <tr>
            <td>Város:</td>
            <td>{formData.city ? formData.city : <span style={{ color: 'red' }}>Nincs adat</span>}</td>
          </tr>
          <tr>
            <td>Utca/Házszám/Ajtó:</td>
            <td>{formData.address ? formData.address : <span style={{ color: 'red' }}>Nincs adat</span>}</td>
          </tr>
          <tr>
            <td>Ára:</td>
            <td>{teljesOsszeg} Ft</td>
          </tr>
        </tbody>
      </table>
      <div>
      <button className='btn btn-danger float-start' onClick={VisszaGomb}>Vissza</button>
      {gombertek && (
        <button className='btn btn-primary' onClick={Vasarlas}>Vásárlás</button>
      )}
        <div className='position-relative'>
          <button className="btn btn-danger position-absolute top-0 end-0" onClick={TorlesLocalStoragebol}>Adatok törlése</button>
        </div>
      </div>
    </div>
  );
}
