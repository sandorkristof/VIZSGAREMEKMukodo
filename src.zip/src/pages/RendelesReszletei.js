import React, { useState, useEffect } from 'react';

export default function RendelesReszletei() {
  const szallitas = 2700;
  const [OsszesArLocalStorage, setOsszesArLocalStorage] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    zipcode: '',
    city: '',
    address: '',
  });

  useEffect(() => {
        // Ellenőrizzük, hogy vannak-e mentett szállítási adatok a localStorage-ban
    const mentettAdat = localStorage.getItem('szallitasiAdatok');
    if (mentettAdat) {
       // Ha vannak mentett adatok, beállítjuk az űrlap adatait a mentett adatok alapján
      setFormData(JSON.parse(mentettAdat));
    }
  }, []);
  const TorlesLocalStoragebol = () => {
    // Töröljük a mentett szállítási adatokat a localStorage-ból
    localStorage.removeItem('szallitasiAdatok');
     // Alaphelyzetbe állítjuk az űrlap adatait
    setFormData({
      name: '',
      email: '',
      phone: '',
      zipcode: '',
      city: '',
      address: ''
    });
  };
  // A useEffect hook arra szolgál, hogy az oldal betöltésekor ellenőrizze, hogy vannak-e
// mentett szállítási adatok a localStorage-ban. Ha vannak, akkor ezeket betölti az űrlapba.

// A TorlesLocalStoragebol függvény felelős a localStorage-ban tárolt szállítási adatok törléséért,
// valamint az űrlap alaphelyzetbe állításáért, hogy a felhasználó törölhesse az adatokat.

  useEffect(() => {
    // Kiolvassuk a teljesOszseg értékét a localStorage-ból és kiírjuk
    const teljesOsszeg = localStorage.getItem('teljesOszseg');
    const parsedteljesOszseg = parseFloat(teljesOsszeg);
    const teljesOszseg = parsedteljesOszseg + szallitas;
    setOsszesArLocalStorage(teljesOszseg);
    //console.log('Total price from localStorage in another component:', teljesOszseg);
  }, []);


  return (
    <div className="container">
      <h1>Rendelés részletei</h1>
      <table className="table">
        <tbody>
          <tr>
            <td>Szállítási név:</td>
            <td>{formData.name}</td>
          </tr>
          <tr>
            <td>Email cím:</td>
            <td>{formData.email}</td>
          </tr>
          <tr>
            <td>Telefonszám:</td>
            <td>{formData.phone}</td>
          </tr>
          <tr>
            <td>Irányítószám:</td>
            <td>{formData.zipcode}</td>
          </tr>
          <tr>
            <td>Város:</td>
            <td>{formData.city}</td>
          </tr>
          <tr>
            <td>Utca/Házszám/Ajtó:</td>
            <td>{formData.address}</td>
          </tr>
          <tr>
            <td>Ára:</td>
            <td>{OsszesArLocalStorage} Ft</td>
          </tr>
        </tbody>
      </table>
      <div>
        <button className='btn btn-primary'>Vásárlás</button>
        <div className='position-relative'>
          <button className="btn btn-danger position-absolute top-0 end-0" onClick={TorlesLocalStoragebol}>Adatok törlése</button>
        </div>
      </div>
    </div>
  );
}
