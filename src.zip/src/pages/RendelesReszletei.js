import React, { useState, useEffect } from 'react';

export default function RendelesReszletei() {
  const szallitas = 2700;
  const [totalPriceFromLocalStorage, setTotalPriceFromLocalStorage] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    zipcode: '',
    city: '',
    address: '',
  });

  useEffect(() => {
    const savedData = localStorage.getItem('szallitasiAdatok');
    if (savedData) {
      setFormData(JSON.parse(savedData));
    }
  }, []);
  const handleClearLocalStorage = () => {
    localStorage.removeItem('szallitasiAdatok');
    setFormData({
      name: '',
      email: '',
      phone: '',
      zipcode: '',
      city: '',
      address: ''
    });
  };
  useEffect(() => {
    // Kiolvassuk a totalPrice értékét a localStorage-ból és kiírjuk
    const teljesOsszeg = localStorage.getItem('totalPrice');
    const parsedTotalPrice = parseFloat(teljesOsszeg);
    const totalPrice = parsedTotalPrice + szallitas;
    setTotalPriceFromLocalStorage(totalPrice);
    //console.log('Total price from localStorage in another component:', totalPrice);
  }, []);


  return (
    <div className="container">
      <h1>Rendelés részletei</h1>
      <table className="table">
        <tbody>
          <tr>
            <td>Szállítási név:</td>
            <td>{formData.name}</td>
          </tr>
          <tr>
            <td>Email cím:</td>
            <td>{formData.email}</td>
          </tr>
          <tr>
            <td>Telefonszám:</td>
            <td>{formData.phone}</td>
          </tr>
          <tr>
            <td>Irányítószám:</td>
            <td>{formData.zipcode}</td>
          </tr>
          <tr>
            <td>Város:</td>
            <td>{formData.city}</td>
          </tr>
          <tr>
            <td>Utca/Házszám/Ajtó:</td>
            <td>{formData.address}</td>
          </tr>
          <tr>
            <td>Ára:</td>
            <td>{totalPriceFromLocalStorage} Ft</td>
          </tr>
        </tbody>
      </table>
      <div>
        <button className='btn btn-primary'>Vásárlás</button>
        <div className='position-relative'>
          <button className="btn btn-danger position-absolute top-0 end-0" onClick={handleClearLocalStorage}>Adatok törlése</button>
        </div>
      </div>
    </div>
  );
}
