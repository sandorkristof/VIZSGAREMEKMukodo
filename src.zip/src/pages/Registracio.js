import React from 'react'
import { Link,Route,Routes } from "react-router-dom";


export default function Registracio() {
  return (
    <div className='d-flex justify-content-center align-items-center bg-danger vh-100'>
      <div className='bg-white p-3 rounded w-25'>
        <h2>Regisztráció</h2>
        <form action="">
          <div className='mb-3'>
            <label htmlFor="name"><strong>Név</strong></label>
            <input type="text" placeholder='Írd ide a teljes neved' />
          </div>
          <div className='mb-3'>
            <label htmlFor="email"><strong>Email</strong></label>
            <input type="email" placeholder='Enter Email' />
          </div>
          <div className='mb-3'>
            <label htmlFor="password"><strong>Password</strong></label>
            <input type="password" placeholder='Enter password' />
          </div>
          <button className='btn btn-success w-100 rounded-0'><strong>Regisztráció</strong></button>
          <p>Elfogadom a felhasználási feltételeket és az adatvédelmi nyilatkozatot.</p>
          <Link to='/Bejelentkezes' className='btn btn-default border w-100 bg-light rounded-0 text-decoration-none'>Bejelentkezés</Link>
        </form>
      </div>
    </div>
  )
}
