import React from 'react'

export default function Registracio() {
  return (
    <div>
      Registracio
    </div>
  )
}
