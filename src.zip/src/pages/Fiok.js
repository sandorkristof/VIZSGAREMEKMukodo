import React, { useEffect,useState } from 'react'

export default function Fiok() {
  const user = JSON.parse(localStorage.getItem('user'));
  const [pastOrders, setPastOrders] = useState([]);

  const handleLogout = () => {
    localStorage.removeItem('user');


    // Oldal frissítése
    window.location.reload();
  };  


  return (
    <div>
      

<div class="grey-bg container-fluid">
  <section id="minimal-statistics">
    <div class="row">
      <div class="col-12 mt-3 mb-1">
      <h4 className='text-uppercase'>{user}</h4>
      </div>
    </div>
    <div >
      <p style={{float:'left'}} className='fs-2 '>Eddigi rendelések</p>
      <div className="container mt-5">
      <div className="row row-cols-3">
        {pastOrders.map(product => (
          <div key={product.id} className='col mb-3'>
            <div className="card">
              <div className="image-container">
                <img src={product.photo} alt={product.name} className='card-img-top' style={{ height: '200px', objectFit: 'cover' }} />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
    </div>
  </section>
  
  
</div>



<div> {user && (
  <button onClick={handleLogout} className='btn position-absolute bottom-0 end-0' style={{backgroundColor: '#ff1000',marginBottom:'10px',marginRight:'10px'}}>Kijelentkezés</button>
  )}
</div>

    </div>
  )
}
