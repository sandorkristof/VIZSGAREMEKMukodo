function validation(values){
    let error={}
    const email_pattern='';
    const password_pattern='';

    if(values.email === ""){
        error.email="Név rész nem lehet üres"
    }
    else if(!email_pattern.test(values.email)){
        error.email="Email cím ilyen nincs"
    }else{
        error.email=""
    }
    if(values.password === ""){
        error.password="Jelszó rész nem lehet üres"
    }else if(!password_pattern.test(values.password)){
        error.password="Jelszó nem található"
    }else{
        error.password=""
    }
    return error;
}
export default validation;