import React from 'react'

export default function Bejelentkezes() {
  return (
    <div>
      Login
    </div>
  )
}
