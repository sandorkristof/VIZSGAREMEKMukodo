import React, { useState } from 'react';

const Login = () => {
  const [email, setEmail] = useState('');
  const [user, setUserName] = useState('');

  const handleLogin = async () => {
    try {
      const response = await fetch('http://localhost:5259/User/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, username }),
      });

      if (response.ok) {
        console.log('Sikeres bejelentkezés');
        // Ide lehetne navigálni vissza a főoldalra: history.push('/')
      } else {
        console.log('Sikertelen bejelentkezés');
      }
    } catch (error) {
      console.error('Hiba történt a bejelentkezés során:', error);
    }
  };


  return (
    <div>
      <h2>Bejelentkezés</h2>
      <div>
        <label>Email:</label>
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      </div>
      <div>
        <label>User:</label>
        <input type="username" value={username} onChange={(e) => setUserName(e.target.value)} />
      </div>
      <button onClick={handleLogin}>Bejelentkezés</button>
    </div>
  );
};

export default Login;
