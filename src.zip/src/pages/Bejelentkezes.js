import React, { useState,useEffect } from 'react';
import { Link,Route,Routes } from "react-router-dom";


const Bejelentkezes = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [userLoggedIn, setUserLoggedIn] = useState(false); 



  useEffect(() => {
    // Ellenőrizze, hogy van-e felhasználói adat a localStorage-ban
    const loggedInUser = localStorage.getItem('user');
    if (loggedInUser) {
      // Ha van felhasználói adat, akkor beállítjuk a userLoggedIn állapotot true-ra
      setUserLoggedIn(true);
    }
  }, []);



  const handleLogin = async () => {
    // Ellenőrzés, hogy minden mező ki legyen töltve
    let formIsValid = true;
  
    if (!email) {
      setEmailError('Az email cím megadása kötelező');
      formIsValid = false;
    } else {
      setEmailError('');
    }
  
    if (!password) {
      setPasswordError('A jelszó megadása kötelező');
      formIsValid = false;
    } else {
      setPasswordError('');
    }
  
    if (formIsValid) {
      try {
        //console.log('Bejelentkezés...');
  
        const response = await fetch('http://localhost:5259/User/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ email, password }),
        });
  
        if (response.ok) {
          const userData = await response.json();
          localStorage.setItem('user',userData.nev);
          alert('Sikeres bejelentkezés');
          //console.log('Sikeres bejelentkezés');
          //console.log(); 
          setUserLoggedIn(true);
          window.location.href='/Fiok';
        } else {
          //console.log('Sikertelen bejelentkezés');
          setPasswordError('Hibás jelszó vagy email');
        }
      } catch (error) {
        console.error('Hiba történt a bejelentkezés során:', error);
      }
    }
  };


  return (
    <div className="container">
      <div className="row d-flex justify-content-center  mt-5">
        <div className="col-md-6 d-flex justify-content-center">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title mb-4">Bejelentkezés</h5>
              <form>
                <div className="mb-3">
                  <label htmlFor="email" className="form-label">Email cím</label>
                  <input 
                    type="email" 
                    className={`form-control ${emailError ? 'border border-danger' : ''}`} 
                    id="email" 
                    value={email} 
                    onChange={(e) => setEmail(e.target.value)} 
                  />
                  {emailError && <div className="text-danger">{emailError}</div>}
                </div>
                <div className="mb-3">
                  <label htmlFor="password" className="form-label">Jelszó</label>
                  <input 
                    type="password" 
                    className={`form-control ${passwordError ? 'border border-danger' : ''}`} 
                    id="password" 
                    value={password} 
                    onChange={(e) => setPassword(e.target.value)} 
                    
                  />
                  {passwordError && <div className="text-danger">{passwordError}</div>}
                </div>
                <Link to="/ElfelejtettJelszo" className='d-flex justify-content-end w-25'>
                  <div style={{ fontSize: '13px' }}>Elfelejtett jelszó</div>
                </Link>
                <button type="button" className="btn btn-primary" onClick={handleLogin} >Bejelentkezés</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Bejelentkezes;
