import React, { useEffect, useState } from 'react'
import ReactDOM from 'react-dom';
import axios from 'axios';
import { Link,Route,Routes } from "react-router-dom";
import './Bejelentkezesellenorzes'


export default function Bejelentkezes() {
  const [products, setProducts] = useState([]);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
 
  useEffect(() => {
    const fetchData = async () => {
      const apiUrl = 'http://localhost:5259/User/login';
      try {
        const response = await fetch(apiUrl);
        const data = await response.json();
  
          
        setProducts(data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
  
    fetchData();
  }, []);

  const login = async () => {
    try {
      const response = await axios.post('http://localhost:3000/login', {
        email,
        password
      });
      console.log(response.data);
    } catch (error) {
      console.error(error);
    }
  }

  return (
        <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-12 col-md-6 col-lg-4">
          <div className="bg-white p-3 rounded border shadow">
            <h2 className="text-center">Bejelentkezés</h2>
            <form action="">
              <div className="mb-3">
                <label htmlFor="email" className="fw-bold">Email</label>
                <input type="email" placeholder="Írj ide e-mail címet" value={email} onChange={(e) => setEmail(e.target.value)} className="form-control rounded-2 shadow" name="email" />
              </div>
              <div className="mb-3">
                <label htmlFor="password" className="fw-bold">Password</label>
                <input type="password" placeholder="Írj ide jelszót" className="form-control rounded-2 shadow" value={password} onChange={(e) => setPassword(e.target.value)} name="password" />
              </div>
              <button style={{ marginBottom: '20px', backgroundColor: '#04c4f4' }} onClick={login} type="submit" className="shadow btn w-100 rounded-2 text-light fw-bold">Bejelentkezés</button>
              <Link to="/Regisztracio" className="btn btn-default border w-100 bg-success rounded-2 text-decoration-none text-white">Csinálj fiókot</Link>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
