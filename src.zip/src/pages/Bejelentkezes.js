import React, { useState } from 'react';
import { Link,Route,Routes } from "react-router-dom";


const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    try {
      const response = await fetch('http://localhost:5259/User/login', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });
      if (response.ok) {
        alert('Sikeres bejelentkezés');
        console.log('Sikeres bejelentkezés');
        window.location.href='/Fiok';
      } else {
        console.log('Sikertelen bejelentkezés');
      }
    } catch (error) {
      console.error('Hiba történt a bejelentkezés során:', error);
    }
  };


  return (
    <div className="container">
      <div className="row d-flex justify-content-center  mt-5">
        <div className="col-md-6 d-flex justify-content-center" >
          <div className="card">
            <div className="card-body">
              <h5 className="card-title mb-4">Bejelentkezés</h5>
              <form>
                <div className="mb-3">
                  <label htmlFor="email" className="form-label">Email cím</label>
                  <input type="email" className="form-control" id="email" value={email} onChange={(e) => setEmail(e.target.value)} />
                </div>
                <div className="mb-3">
                  <label htmlFor="password" className="form-label">Jelszó</label>
                  <input type="password" className="form-control" id="password" value={password} onChange={(e) => setPassword(e.target.value)} />
                </div>
                <Link to="/ElfelejtettJelszo" className='d-flex justify-content-end w-25'>
                  <div style={{ fontSize: '13px' }}>Elfelejtett jelszó</div>
                </Link>

                <button type="button" className="btn btn-primary" onClick={handleLogin}>Bejelentkezés</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
