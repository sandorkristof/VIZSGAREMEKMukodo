import React, { useState } from 'react'
import { Link,Route,Routes } from "react-router-dom";
import './Bejelentkezesellenorzes'


export default function Bejelentkezes() {
 
  return (
    <div className='d-flex justify-content-center align-items-center bg-white mt-5'>
      <div className='bg-white p-3 rounded w-25 border shadow'>
      <h2>Bejelentkezés</h2>
        <form action="" >
          <div className='mb-3'>
            <label htmlFor="email"><strong>Email </strong></label>
            <input type="email" placeholder='Írj ide e-mail címet' className='form-control rounded-2 shadow'  name='email'/>
          </div>
          <div className='mb-3'>
            <label htmlFor="password"><strong>Password</strong></label>
            <input type="password" placeholder='Írj ide jelszót' className='form-control rounded-2 shadow' name='password'/>

          </div>
          <button style={{marginBottom:'30px'}} type='submit' className='shadow btn btn-primary w-100 rounded-2'><strong>Bejelentkezés</strong></button>

        
          <Link to='/Regisztracio'  className='btn btn-default border w-100 bg-success rounded-2 text-decoration-none text-white'>Csinálj fiókot</Link>
        </form>
      </div>
    </div>
  )
}
