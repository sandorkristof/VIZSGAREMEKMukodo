import React from 'react'

export default function MSIOptixG241() {
  return (
    <div>
      
    </div>
  )
}
