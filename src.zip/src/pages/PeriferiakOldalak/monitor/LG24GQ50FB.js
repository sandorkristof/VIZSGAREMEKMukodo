import React from 'react'

export default function LG24GQ50FB() {
  return (
    <div>
      
    </div>
  )
}
