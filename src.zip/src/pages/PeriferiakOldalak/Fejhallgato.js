import React, { useEffect, useState } from 'react';
import { Link,Route,Routes } from "react-router-dom";
import './style.css';
import { useCookies } from 'react-cookie';

export default function Fejhallgato() {
  const [price, setPrice] = useState(0);
  const [manufacturerFilters, setManufacturerFilters] = useState([]);
  const [memoryTypeFilter, setMemoryTypeFilter] = useState('');
  const [memoryCapacityFilter, setMemoryCapacityFilter] = useState('');
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);

  const [filteredProducts, setFilteredProducts] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const apiUrl = 'http://localhost:5259/Product/getAll';
      try {
        const response = await fetch(apiUrl);
        const data = await response.json();
  
        // Szűrés a Kategoria_Id alapján (1-es Kategoria_Id)
        const filteredProducts = data.filter(product => product.categoryId === 8);
  
        // Beállítjuk mindkét állapotot a lefetchelt és szűrt adatokkal
        setProducts(data);
        console.log(data);
        setFilteredProducts(filteredProducts);
        console.log(filteredProducts);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
  
    fetchData();
  }, []);
   // üres dependencies array, így csak egyszer fut le a komponens betöltésekor

  useEffect(() => {
    // Szűrés a megváltozott értékek alapján
    filterProducts();
  }, [price, manufacturerFilters, memoryTypeFilter, memoryCapacityFilter]);

  const handlePriceChange = (event) => {
    const newPrice = parseInt(event.target.value, 10);
    setPrice(newPrice);
  };

  const handleManufacturerChange = (event) => {
    const manufacturer = event.target.value;
    setManufacturerFilters(toggleFilter(manufacturerFilters, manufacturer));
  };

  const handleMemoryTypeChange = (event) => {
    const memoryType = event.target.value;
    setMemoryTypeFilter(memoryType);
  };

  const handleMemoryCapacityChange = (event) => {
    const memoryCapacity = event.target.value;
    setMemoryCapacityFilter(memoryCapacity);
  };

  const toggleFilter = (filters, value) => {
    if (filters.includes(value)) {
      return filters.filter(filter => filter !== value);
    } else {
      return [...filters, value];
    }
  };

  const filterProducts = () => {
    const filtered = products.filter(
      product =>
        product.categoryId === 1 && // Szűrés a Kategoria_Id alapján (1-es Kategoria_Id)
        product.price >= price &&
        (manufacturerFilters.length === 0 || manufacturerFilters.includes(product.manufacturer)) &&
        (memoryTypeFilter === '' || memoryTypeFilter === product.memoryType) &&
        (memoryCapacityFilter === '' || memoryCapacityFilter === product.memoryCapacity)
    );
    setFilteredProducts(filtered);
  };

  const history = useCookies();

  useEffect(() => {
    // Betöltjük a kosarat a localStorage-ból
    const existingCart = JSON.parse(localStorage.getItem('cart')) || [];
    setCart(existingCart);
  }, []);

  const handleAddToCart = (product) => {
    setCart((prevCart) => {
      let updatedCart;
  
      // Ellenőrizzük, hogy a termék már szerepel-e a kosárban
      let isExisting = false;
  
      prevCart.forEach((item) => {
        if (item.id === product.id) {
          // Ha a termék már szerepel a kosárban, csak növeljük a mennyiséget
          item.quantity += 1;
          isExisting = true;
        }
      });
  
      // Ha a termék még nem szerepel a kosárban, hozzáadjuk
      if (!isExisting) {
        const newCartItem = {
          id: product.id,
          brand: product.brand,
          name: product.name,
          price: product.price,
          quantity: 1, // Kezdeti mennyiség 1
          photo: product.photo, // Fotó hozzáadása
        };
  
        updatedCart = [...prevCart, newCartItem];
      } else {
        updatedCart = [...prevCart];
      }
  
      localStorage.setItem('cart', JSON.stringify(updatedCart));
      return updatedCart;
    });
  };
  
  



  return (
    <div>
      <div className='d-flex'>
      <div style={{ width: '400px' }} className='float-start mx-3'>
  <div className="menu-container mt-5">
    <div className="row mb-3">
      <div className="col-md-12 mb-3">
        <div className="card custom-card shadow">
          <div className="card-body">
            <h5 className="card-title">Gyártók</h5>
            {['Samsung', 'LG', 'Philips', 'Sony'].map(manufacturer => (
              <div key={manufacturer} className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  value={manufacturer}
                  id={`checkbox-${manufacturer}`}
                  onChange={handleManufacturerChange}
                  checked={manufacturerFilters.includes(manufacturer)}
                />
                <label className="form-check-label" htmlFor={`checkbox-${manufacturer}`}>
                  {manufacturer}
                </label>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="col-md-12 mb-3">
        <div className="card custom-card shadow">
          <div className="card-body">
            <div>
              <label htmlFor="priceSlider">Ár :</label>
              <br />
              <input style={{ width: '230px' }} type="range" id="priceSlider" name="price" min={100} max={1000000} value={price} onChange={handlePriceChange} />
              <p>{price}Ft</p>
            </div>
          </div>
        </div>
      </div>
      <div className="col-md-12 mb-3">
        <div className="card custom-card shadow">
          <div className="card-body">
            <h5 className="card-title">Kapacitás</h5>
            <select className="form-control" value={memoryCapacityFilter} onChange={handleMemoryCapacityChange}>
              <option value=""></option>
              <option value="4GB">4 GB</option>
              <option value="6GB">6 GB</option>
              <option value="8GB">8 GB</option>
              <option value="12GB">12 GB</option>
              <option value="16GB">16 GB</option>
            </select>
          </div>
        </div>
      </div>
      <div className="col-md-12 mb-3">
        <div className="card custom-card shadow">
          <div className="card-body">
            <h5 className="card-title">Memória típus</h5>
            <select className="form-control" value={memoryTypeFilter} onChange={handleMemoryTypeChange}>
              <option value=""></option>
              <option value="DDR3">DDR3</option>
              <option value="DDR4">DDR4</option>
              <option value="DDR5">DDR5</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

                              
<div className="row mb-3 ">
  <div className='float-end'>
    <div className="container mt-5">
      <div className="row row-cols-3">
        {filteredProducts.map(product => (
          <div key={product.id} className='col-md-4 mb-4 justify-content-between'>
            <div className='card ' style={{ height: '400px'}}>
              <Link to={`/product/${product.id}`}>
                <img src={product.photo} alt={product.name} className='card-img-top ' style={{ height: '200px', objectFit: 'cover' }} />
              </Link>
              <div className='card-body'>
                <p className='card-title'>{product.brand}</p>
                <strong className='card-text'>{product.name}</strong>
                <div></div>
                <p className='card-text float-end'>Értékelés 10/{product.review}</p>
                <p className='card-text d-flex justify-content-start mb-0'>
                  <strong>Ár:</strong> {product.price} Ft
                </p>
                <div className="d-flex">
                  <button onClick={() => handleAddToCart(product)} style={{ backgroundColor: '#04c4f4',width:'100px'}} className='btn mt-3 '>Kosárba</button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  </div>
</div>





    </div>
    </div>
  )
}
