import React from 'react'

export default function gamebird25x35() {
  return (
    <div>
      
    </div>
  )
}
