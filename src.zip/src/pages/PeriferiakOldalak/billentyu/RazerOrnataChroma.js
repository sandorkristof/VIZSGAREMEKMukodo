import React from 'react'

export default function RazerOrnataChroma() {
  return (
    <div>
      
    </div>
  )
}
