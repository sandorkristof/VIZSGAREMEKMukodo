import React from 'react'

export default function LogitechG305LightSpeedHero() {
  return (
    <div>
      
    </div>
  )
}
