import React from 'react'

export default function LogitechG502XPlus() {
  return (
    <div>
      
    </div>
  )
}
