import React from 'react'

export default function AsusTUFGamingM3GenII() {
  return (
    <div>
      
    </div>
  )
}
