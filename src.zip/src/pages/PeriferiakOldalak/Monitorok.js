import React, { useEffect, useState } from 'react';
import './style.css';

export default function Monitorok() {

  






  const [price, setPrice] = useState(0);
  const [manufacturerFilters, setManufacturerFilters] = useState([]);
  const [memoryTypeFilter, setMemoryTypeFilter] = useState('');
  const [memoryCapacityFilter, setMemoryCapacityFilter] = useState('');
  const [products, setProducts] = useState([
    { id: 1, name: 'TV 1', price: 400000, rating: 4, inStock: true, manufacturer: 'Samsung', memoryType: 'DDR4', memoryCapacity: '8GB', image: data.photo},
    { id: 2, name: 'TV 2', price: 600000, rating: 5, inStock: false, manufacturer: 'LG', memoryType: 'DDR5', memoryCapacity: '16GB', image: 'https://s13emagst.akamaized.net/products/43490/43489382/images/res_f2a64219d2ad768d433b0cf9269f9771.jpg?width=720&height=720&hash=8AEE6C0A1E68A2D3D48A0AB7E8638CF1' },
    { id: 3, name: 'TV 3', price: 800000, rating: 4.5, inStock: true, manufacturer: 'Sony', memoryType: 'DDR4', memoryCapacity: '32GB', image: 'https://s13emagst.akamaized.net/products/59739/59738923/images/res_88b9444f236de01ac18f098320dfad51.jpg?width=720&height=720&hash=EB46EE4EDEC5307C3A963EAB2C12CD89' },
    { id: 4, name: 'TV 4', price: 400000, rating: 4, inStock: true, manufacturer: 'Samsung', memoryType: 'DDR4', memoryCapacity: '8GB', image: 'https://s13emagst.akamaized.net/products/9119/9118440/images/res_d5661670ea300154e49a6d774938b62b.jpg?width=720&height=720&hash=30E3A92C121FA16B3103892BF16D21EB' },
    { id: 5, name: 'TV 5', price: 600000, rating: 5, inStock: false, manufacturer: 'LG', memoryType: 'DDR5', memoryCapacity: '16GB', image: 'https://s13emagst.akamaized.net/products/43490/43489382/images/res_f2a64219d2ad768d433b0cf9269f9771.jpg?width=720&height=720&hash=8AEE6C0A1E68A2D3D48A0AB7E8638CF1' },
    { id: 6, name: 'TV 6', price: 800000, rating: 4.5, inStock: true, manufacturer: 'Sony', memoryType: 'DDR4', memoryCapacity: '32GB', image: 'https://s13emagst.akamaized.net/products/59739/59738923/images/res_88b9444f236de01ac18f098320dfad51.jpg?width=720&height=720&hash=EB46EE4EDEC5307C3A963EAB2C12CD89' },    
    { id: 7, name: 'TV 7', price: 600000, rating: 5, inStock: false, manufacturer: 'LG', memoryType: 'DDR5', memoryCapacity: '16GB', image: 'https://s13emagst.akamaized.net/products/43490/43489382/images/res_f2a64219d2ad768d433b0cf9269f9771.jpg?width=720&height=720&hash=8AEE6C0A1E68A2D3D48A0AB7E8638CF1' },
    { id: 8, name: 'TV 8', price: 800000, rating: 4.5, inStock: true, manufacturer: 'Sony', memoryType: 'DDR4', memoryCapacity: '32GB', image: 'https://s13emagst.akamaized.net/products/59739/59738923/images/res_88b9444f236de01ac18f098320dfad51.jpg?width=720&height=720&hash=EB46EE4EDEC5307C3A963EAB2C12CD89' },    
    { id: 9, name: 'TV 9', price: 600000, rating: 5, inStock: false, manufacturer: 'LG', memoryType: 'DDR5', memoryCapacity: '16GB', image: 'https://s13emagst.akamaized.net/products/43490/43489382/images/res_f2a64219d2ad768d433b0cf9269f9771.jpg?width=720&height=720&hash=8AEE6C0A1E68A2D3D48A0AB7E8638CF1' },
    { id: 10, name: 'TV 10', price: 800000, rating: 4.5, inStock: true, manufacturer: 'Sony', memoryType: 'DDR4', memoryCapacity: '32GB', image: 'https://s13emagst.akamaized.net/products/59739/59738923/images/res_88b9444f236de01ac18f098320dfad51.jpg?width=720&height=720&hash=EB46EE4EDEC5307C3A963EAB2C12CD89' },
    { id: 11, name: 'TV 11', price: 600000, rating: 5, inStock: false, manufacturer: 'LG', memoryType: 'DDR5', memoryCapacity: '16GB', image: 'https://s13emagst.akamaized.net/products/43490/43489382/images/res_f2a64219d2ad768d433b0cf9269f9771.jpg?width=720&height=720&hash=8AEE6C0A1E68A2D3D48A0AB7E8638CF1' },
    { id: 12, name: 'TV 12', price: 800000, rating: 4.5, inStock: true, manufacturer: 'Sony', memoryType: 'DDR4', memoryCapacity: '32GB', image: 'https://s13emagst.akamaized.net/products/59739/59738923/images/res_88b9444f236de01ac18f098320dfad51.jpg?width=720&height=720&hash=EB46EE4EDEC5307C3A963EAB2C12CD89' },
  ]);

  // Szűrt termékek állapota
  const [filteredProducts, setFilteredProducts] = useState([]);

  // Alapértelmezett kártyák betöltése
  useEffect(() => {
    setFilteredProducts(products);
  }, [products]);

  const handlePriceChange = (event) => {
    const newPrice = parseInt(event.target.value, 10);
    setPrice(newPrice);
    filterProducts(newPrice, manufacturerFilters, memoryTypeFilter, memoryCapacityFilter);
  };

  const handleManufacturerChange = (event) => {
    const manufacturer = event.target.value;
    const updatedFilters = toggleFilter(manufacturerFilters, manufacturer);
    setManufacturerFilters(updatedFilters);
    filterProducts(price, updatedFilters, memoryTypeFilter, memoryCapacityFilter);
  };

  const handleMemoryTypeChange = (event) => {
    const memoryType = event.target.value;
    setMemoryTypeFilter(memoryType);
    filterProducts(price, manufacturerFilters, memoryType, memoryCapacityFilter);
  };

  const handleMemoryCapacityChange = (event) => {
    const memoryCapacity = event.target.value;
    setMemoryCapacityFilter(memoryCapacity);
    filterProducts(price, manufacturerFilters, memoryTypeFilter, memoryCapacity);
  };

  const toggleFilter = (filters, value) => {
    if (filters.includes(value)) {
      return filters.filter(filter => filter !== value);
    } else {
      return [...filters, value];
    }
  };

  const filterProducts = (newPrice, manufacturers, memoryType, memoryCapacity) => {
    const filtered = products.filter(product => 
      product.price >= newPrice &&
      (manufacturers.length === 0 || manufacturers.includes(product.manufacturer)) &&
      (memoryType === '' || memoryType === product.memoryType) &&
      (memoryCapacity === '' || memoryCapacity === product.memoryCapacity)
    );
    setFilteredProducts(filtered);
  };
  return (
    <div>
      <div className='d-flex'>
        
        <div style={{width:'400px'}} className='float-start mx-3'>
          <div className="menu-container mt-5 ">
              <div class="row mb-3">
                <div  class="col-md-12 mb-3">
                  <div class="card custom-card shadow">
                    <div class="card-body ">
                      <h5 class="card-title">Gyártók</h5>
                      <div class="form-check ">
                        <input class="form-check-input" type="checkbox" value="Samsung" id="checkbox1" onChange={handleManufacturerChange} checked={manufacturerFilters.includes('Samsung')}/>
                        <label class="form-check-label" for="checkbox1">Samsung</label>
                      </div>
                      <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="LG" id="checkbox2"onChange={handleManufacturerChange} checked={manufacturerFilters.includes('LG')}/>
                        <label class="form-check-label" for="checkbox2">LG</label>
                      </div>
                      <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="Philips" id="checkbox3"onChange={handleManufacturerChange} checked={manufacturerFilters.includes('Philips')}/>
                        <label class="form-check-label" for="checkbox3">Philips</label>
                      </div>
                      <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="Sony" id="checkbox3"onChange={handleManufacturerChange} checked={manufacturerFilters.includes('Sony')}/>
                        <label class="form-check-label" for="checkbox3">Sony</label>
                      </div>
                    </div>
                  </div>
                </div>
                <div  className="col-md-12 mb-3">
                    <div className="card custom-card shadow">
                      <div className="card-body">
                      <div>
                        <label htmlFor="priceSlider">Ár :</label>
                        <br />
                        <input style={{width:'230px'}} type="range"id="priceSlider" name="price" min={0} max={1000000} value={price} onChange={handlePriceChange} />
                        <p> {price} Ft</p>
                      </div>
                      </div>
                    </div>
                  </div>
                <div class="col-md-12 mb-3">
                  <div class="card custom-card shadow">
                    <div class="card-body">
                      <h5 class="card-title">Kapacitás</h5>
                      <select class="form-control"value={memoryCapacityFilter} onChange={handleMemoryCapacityChange}>
                        <option value=""></option>
                        <option value="4GB">4 GB</option>
                        <option value="6GB">6 GB</option>
                        <option value="8GB">8 GB</option>
                        <option value="12GB">12 GB</option>
                        <option value="16GB">16 GB</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-12 mb-3">
                  <div class="card custom-card shadow">
                    <div class="card-body">
                      <h5 class="card-title">Memória típus</h5>
                      <select class="form-control"value={memoryTypeFilter} onChange={handleMemoryTypeChange}>
                      <option value=""></option>
                        <option value="DDR3">DDR3</option>
                        <option value="DDR4">DDR4</option>
                        <option value="DDR5">DDR5</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
          </div>
        </div>
        <div class="row mb-3">
        <div className='float-end'>
          <div className="container mt-5">
      <div className="card-container">
        {filteredProducts.map(product => (
          <div key={product.id} className="card">
            <img src={product.image} alt={product.name} style={{ width: '100%', height: 'auto' }} />
            <div className="card-info">
              <div>
                <strong>Értékelés:</strong> {product.rating}
              </div>
              <div>
                <strong>Raktáron:</strong> {product.inStock ? 'Igen' : 'Nem'}
              </div>
              <div>
                <strong>Ára:</strong> {product.price} HUF
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
        </div>
        </div>
    </div>
    </div>
  )
}
