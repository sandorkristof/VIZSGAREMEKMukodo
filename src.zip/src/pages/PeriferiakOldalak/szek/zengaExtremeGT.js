import React from 'react'

export default function zengaExtremeGT() {
  return (
    <div>
      
    </div>
  )
}
