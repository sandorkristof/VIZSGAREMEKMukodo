import React from 'react'

export default function kringbokai() {
  return (
    <div>
      
    </div>
  )
}
