import React from 'react'

export default function genesisNitro550() {
  return (
    <div>
      
    </div>
  )
}
