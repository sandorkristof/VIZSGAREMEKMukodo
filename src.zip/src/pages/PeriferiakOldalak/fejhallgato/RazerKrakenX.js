import React from 'react'

export default function RazerKrakenX() {
  return (
    <div>
      
    </div>
  )
}
