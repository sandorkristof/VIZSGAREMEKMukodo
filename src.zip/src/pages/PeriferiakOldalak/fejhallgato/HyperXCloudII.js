import React from 'react'

export default function HyperXCloudII() {
  return (
    <div>
      
    </div>
  )
}
