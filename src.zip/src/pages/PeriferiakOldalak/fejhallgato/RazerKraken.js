import React from 'react'

export default function RazerKraken() {
  return (
    <div>
      
    </div>
  )
}
