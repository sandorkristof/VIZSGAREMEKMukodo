import React from 'react'
import { Link,Route,Routes } from "react-router-dom";
import './CardPageSelect.css';
import Apple from '../image/apple.png'
import Samsung from '../image/samsung.png'
import Xiaomi from '../image/xiaomi.png'


export default function Mobiltelefonok() {
  return (
    <div>
      

<div className="container mt-4">
  <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-3 justify-content-center">
    <Link id='Dobozok' className="col border rounded mb-3" to="/Apple" style={{ textDecoration: 'none' }}>
      <img src={Apple} alt="image1" className="img-fluid rounded" style={{ maxWidth: '100%', maxHeight: '150px' }} />
      <div style={{ marginBottom: '3px', fontSize: '14px' }} className="font-weight-bold text-uppercase text-dark">Apple</div>
    </Link>
    <Link id='Dobozok' className="col border rounded mb-3" to="/Samsung" style={{ textDecoration: 'none' }}>
      <img src={Samsung} alt="image2" className="img-fluid rounded" style={{ maxWidth: '100%', maxHeight: '150px' }} />
      <div style={{ marginBottom: '3px', fontSize: '14px' }} className="font-weight-bold text-uppercase text-dark">Samsung</div>
    </Link>
    <Link id='Dobozok' className="col border rounded mb-3" to="/Xiaomi" style={{ textDecoration: 'none' }}>
      <img src={Xiaomi} alt="image3" className="img-fluid rounded" style={{ maxWidth: '100%', maxHeight: '150px' }} />
      <div style={{ marginBottom: '3px', fontSize: '14px' }} className="font-weight-bold text-uppercase text-dark">Xiaomi</div>
    </Link>
  </div>
</div>
    </div>
  )
}
