import React from 'react'

export default function Mobiltelefonok() {
  return (
    <div>
      Mobiltelefon
    </div>
  )
}
