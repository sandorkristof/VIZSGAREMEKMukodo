import React from 'react'

export default function Periferiak() {
  return (
    <div>
      Periferia
    </div>
  )
}
