import React from 'react'
import './CardPageSelect.css';
import { Link,Route,Routes } from "react-router-dom";
import Monitor from '../image/monitor.png'
import Fejhallgato from '../image/headset.png'
import Eger from '../image/mouse.png'
import Bill from '../image/keyboard.png'
import Szek from '../image/gaming-chair.png'
import Mousepad from '../image/mousepad.png'


export default function Periferiak() {
  return (
   <div>
            <div className="container mt-4 w-50">
  <div className="row row-cols-2 row-cols-md-4 g-3 justify-content-center">
    <Link id='Dobozok'  className="col  border rounded me-3 mb-3" to="/Monitorok" style={{ textDecoration: 'none' }}>
      <img src={Monitor} alt="image1" className="img-fluid rounded" />
      <div style={{ marginBottom: '3px', fontSize: '20px' }} className="font-weight-bold text-uppercase text-dark">Monitorok</div>
    </Link>
    <Link id='Dobozok' className="col  border rounded me-3 mb-3" to="/Fejhallgatók" style={{ textDecoration: 'none' }}>
      <img src={Fejhallgato} alt="image2" className="img-fluid rounded" />
      <div style={{ marginBottom: '3px', fontSize: '20px' }} className="font-weight-bold text-uppercase text-dark">Fejhallgatók</div>
    </Link>
    <Link id='Dobozok' className="col  border rounded me-3 mb-3" to="/Egerek" style={{ textDecoration: 'none' }}>
      <img src={Eger} alt="image3" className="img-fluid rounded" />
      <div style={{ marginBottom: '3px', fontSize: '20px' }} className="font-weight-bold text-uppercase text-dark">Egerek</div>
    </Link>
    <Link id='Dobozok' className="col  border rounded me-3 mb-3" to="/Billentyűzetek" style={{ textDecoration: 'none' }}>
      <img src={Bill} alt="image4" className="img-fluid rounded" />
      <div style={{ marginBottom: '3px', fontSize: '20px' }} className="font-weight-bold text-uppercase text-dark">Billentyűzetek</div>
    </Link>
    <Link id='Dobozok' className="col  border rounded me-3 mb-3" to="/Székek" style={{ textDecoration: 'none' }}>
      <img src={Szek} alt="image5" className="img-fluid rounded" />
      <div style={{ marginBottom: '3px', fontSize: '20px' }} className="font-weight-bold text-uppercase text-dark">Laptopok</div>
    </Link>
    <Link id='Dobozok' className="col  border rounded me-3 mb-3" to="/Egérpadok" style={{ textDecoration: 'none' }}>
      <img src={Mousepad} alt="image6" className="img-fluid rounded" />
      <div style={{ marginBottom: '3px', fontSize: '20px' }} className="font-weight-bold text-uppercase text-dark">Egérpadok</div>
    </Link>
  </div>
</div>
    </div>
  )
}
