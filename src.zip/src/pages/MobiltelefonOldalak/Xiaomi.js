import React from 'react'
import './style.css';


export default function Xiaomi() {
  return (
    <div>
      <div className='d-flex justify-content-center'>
        
        <div style={{width:'500px'}} className='float-start mx-3'>
          <div className="menu-container mt-5 ">
              <div class="row mb-3">
                <div style={{width:'330px',marginLeft:'50px'}} class="col-md-12 mb-3 ">
                  <div class="card custom-card shadow">
                    <div class="card-body shadow ">
                      <h5 class="card-title">Gyártók</h5>
                      <div class="form-check ">
                        <input class="form-check-input" type="checkbox" value="" id="checkbox1"/>
                        <label class="form-check-label" for="checkbox1">Option 1</label>
                      </div>
                      <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="checkbox2"/>
                        <label class="form-check-label" for="checkbox2">Option 2</label>
                      </div>
                      <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="checkbox3"/>
                        <label class="form-check-label" for="checkbox3">Option 3</label>
                      </div>
                    </div>
                  </div>
                </div>
                <div style={{width:'330px',marginLeft:'50px'}} class="col-md-12 mb-3">
                  <div class="card custom-card shadow">
                    <div class="card-body shadow">
                    <div class="container mt-4">
                      <input style={{width:'240px'}} type="range" id="priceRange" name="priceRange" min="0" max="100" step="2" />
                      <p>Aktuális Ár: $<span id="priceValue">0</span></p>
                    </div>
                    </div>
                  </div>
                </div>
                <div style={{width:'330px',marginLeft:'50px'}} class="col-md-12 mb-3">
                  <div class="card custom-card shadow">
                    <div class="card-body shadow">
                      <h5 class="card-title">Kapacitás</h5>
                      <select class="form-control">
                        <option value="price1">4 GB</option>
                        <option value="price2">6 GB</option>
                        <option value="price3">8 GB</option>
                        <option value="price3">12 GB</option>
                        <option value="price3">16 GB</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div style={{width:'330px',marginLeft:'50px'}} class="col-md-12 mb-3">
                  <div class="card custom-card shadow">
                    <div class="card-body shadow">
                      <h5 class="card-title">Memória típus</h5>
                      <select class="form-control">
                        <option value="price1">DDR3</option>
                        <option value="price2">GDDR4</option>
                        <option value="price3">GDDR5</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
          </div>
        </div>
        <div className='float-end'>
          <div className="container mt-5">
            <div className="row mb-3">
              <div className="d-flex  col-md-3">
                <div className="card rounded-1 custom-card shadow">
                  <img  src="https://s13emagst.akamaized.net/products/57170/57169744/images/res_c4bcb9c102c648d13347aa24e117220d.jpg?width=720&height=720&hash=6A33C59FCBB0ADB7B189E50CB7593470" className="card-img-top" alt="Card Image"/>
                  <div className="card-body shadow">
                  <h5 className="card-title">Card 2</h5>
                  <div>
                      <div className='text-start' >
                          <span style={{marginRight:'5px'}}>Értékelés:</span>
                          <span className=' fw-bold'>0.0</span>
                      </div>
                    </div>
                    <div className='text-end'>
                      <p style={{backgroundColor:'#32CD32'}} className='badge'>Raktáron</p>
                    </div>
                     <div className="container mt-0 w-75 d-flex justify-content-center">
                      <button id='arnyekolasGomb' style={{ backgroundColor: 'silver' }} className="btn btn-rounded">
                        <img className='' style={{ width: '20px', height: '20px' }} src="https://cdn-icons-png.flaticon.com/512/263/263142.png" alt="" />
                        <span className='ms-1'>Kosárba</span>
                      </button>
                    </div> 
                  </div>
                </div>
              </div>
              <div className="d-flex col-md-3">
                <div className="card rounded-1 custom-card shadow">
                  <img src="https://s13emagst.akamaized.net/products/36726/36725029/images/res_e4f9b4c591d85c8574e97829b7ccb482.jpg?width=720&height=720&hash=B5858D91396E7A5690CACB25C29E2318" className="card-img-top" alt="Card Image"/>
                  <div className="card-body shadow">
                  <h5 className="card-title">Card 2</h5>
                  <div>
                      <div className='text-start' >
                          <span style={{marginRight:'5px'}}>Értékelés:</span>
                          <span className=' fw-bold'>0.0</span>
                      </div>
                    </div>
                    <div className='text-end'>
                      <p style={{backgroundColor:'#32CD32'}} className='badge'>Raktáron</p>
                    </div>
                     <div className="container mt-0 w-75 d-flex justify-content-center">
                      <button id='arnyekolasGomb' style={{ backgroundColor: 'silver' }} className="btn btn-rounded">
                        <img className='' style={{ width: '20px', height: '20px' }} src="https://cdn-icons-png.flaticon.com/512/263/263142.png" alt="" />
                        <span className='ms-1'>Kosárba</span>
                      </button>
                    </div> 
                  </div>
                </div>
              </div>
              <div className="d-flex col-md-3">
                <div className="card rounded-1 custom-card shadow">
                  <img src="https://s13emagst.akamaized.net/products/32447/32446033/images/res_f43843d7e379e7ac91d67dc412ea082a.jpg?width=720&height=720&hash=361DC19C5BE9A21367C03DEF4DA2C575" className="card-img-top" alt="Card Image"/>
                  <div className="card-body shadow">
                  <h5 className="card-title">Card 2</h5>
                  <div>
                      <div className='text-start' >
                          <span style={{marginRight:'5px'}}>Értékelés:</span>
                          <span className=' fw-bold'>0.0</span>
                      </div>
                    </div>
                    <div className='text-end'>
                      <p style={{backgroundColor:'#32CD32'}} className='badge'>Raktáron</p>
                    </div>
                     <div className="container mt-0 w-75 d-flex justify-content-center">
                      <button id='arnyekolasGomb' style={{ backgroundColor: 'silver' }} className="btn btn-rounded">
                        <img className='' style={{ width: '20px', height: '20px' }} src="https://cdn-icons-png.flaticon.com/512/263/263142.png" alt="" />
                        <span className='ms-1'>Kosárba</span>
                      </button>
                    </div> 
                  </div>
                </div>
              </div>
              <div className="d-flex col-md-3">
                <div className="card rounded-1 custom-card shadow">
                  <img src="https://s13emagst.akamaized.net/products/52198/52197748/images/res_60ddd957789b027d92ec154edd88a6b1.jpg?width=720&height=720&hash=D5D6801DFD57E974426198BDD3572B03" className="card-img-top" alt="Card Image"/>
                  <div className="card-body shadow">
                  <h5 className="card-title">Card 2</h5>
                  <div>
                      <div className='text-start' >
                          <span style={{marginRight:'5px'}}>Értékelés:</span>
                          <span className=' fw-bold'>0.0</span>
                      </div>
                    </div>
                    <div className='text-end'>
                      <p style={{backgroundColor:'#32CD32'}} className='badge'>Raktáron</p>
                    </div>
                     <div className="container mt-0 w-75 d-flex justify-content-center">
                      <button id='arnyekolasGomb' style={{ backgroundColor: 'silver' }} className="btn btn-rounded">
                        <img className='' style={{ width: '20px', height: '20px' }} src="https://cdn-icons-png.flaticon.com/512/263/263142.png" alt="" />
                        <span className='ms-1'>Kosárba</span>
                      </button>
                    </div> 
                  </div>
                </div>
              </div>
            </div>
            <div className="row mb-3">
              <div className="d-flex col-md-3">
                <div className="card rounded-1 custom-card shadow">
                  <img src="https://s13emagst.akamaized.net/products/57170/57169744/images/res_c4bcb9c102c648d13347aa24e117220d.jpg?width=720&height=720&hash=6A33C59FCBB0ADB7B189E50CB7593470" className="card-img-top" alt="Card Image"/>
                  <div className="card-body shadow">
                  <h5 className="card-title">Card 2</h5>
                  <div>
                      <div className='text-start' >
                          <span style={{marginRight:'5px'}}>Értékelés:</span>
                          <span className=' fw-bold'>0.0</span>
                      </div>
                    </div>
                    <div className='text-end'>
                      <p style={{backgroundColor:'#32CD32'}} className='badge'>Raktáron</p>
                    </div>
                     <div className="container mt-0 w-75 d-flex justify-content-center">
                      <button id='arnyekolasGomb' style={{ backgroundColor: 'silver' }} className="btn btn-rounded">
                        <img className='' style={{ width: '20px', height: '20px' }} src="https://cdn-icons-png.flaticon.com/512/263/263142.png" alt="" />
                        <span className='ms-1'>Kosárba</span>
                      </button>
                    </div> 
                  </div>
                </div>
              </div>
              <div className="d-flex col-md-3">
                <div className="card rounded-1 custom-card shadow">
                  <img src="https://s13emagst.akamaized.net/products/36726/36725029/images/res_e4f9b4c591d85c8574e97829b7ccb482.jpg?width=720&height=720&hash=B5858D91396E7A5690CACB25C29E2318" className="card-img-top" alt="Card Image"/>
                  <div className="card-body shadow">
                  <h5 className="card-title">Card 2</h5>
                  <div>
                      <div className='text-start' >
                          <span style={{marginRight:'5px'}}>Értékelés:</span>
                          <span className=' fw-bold'>0.0</span>
                      </div>
                    </div>
                    <div className='text-end'>
                      <p style={{backgroundColor:'#32CD32'}} className='badge'>Raktáron</p>
                    </div>
                     <div className="container mt-0 w-75 d-flex justify-content-center">
                      <button id='arnyekolasGomb' style={{ backgroundColor: 'silver' }} className="btn btn-rounded">
                        <img className='' style={{ width: '20px', height: '20px' }} src="https://cdn-icons-png.flaticon.com/512/263/263142.png" alt="" />
                        <span className='ms-1'>Kosárba</span>
                      </button>
                    </div> 
                  </div>
                </div>
              </div>
              <div className="d-flex col-md-3">
                <div className="card rounded-1 custom-card shadow">
                  <img src="https://s13emagst.akamaized.net/products/32447/32446033/images/res_f43843d7e379e7ac91d67dc412ea082a.jpg?width=720&height=720&hash=361DC19C5BE9A21367C03DEF4DA2C575" className="card-img-top" alt="Card Image"/>
                  <div className="card-body shadow">
                  <h5 className="card-title">Card 2</h5>
                  <div>
                      <div className='text-start' >
                          <span style={{marginRight:'5px'}}>Értékelés:</span>
                          <span className=' fw-bold'>0.0</span>
                      </div>
                    </div>
                    <div className='text-end'>
                      <p style={{backgroundColor:'#32CD32'}} className='badge'>Raktáron</p>
                    </div>
                     <div className="container mt-0 w-75 d-flex justify-content-center">
                      <button id='arnyekolasGomb' style={{ backgroundColor: 'silver' }} className="btn btn-rounded">
                        <img className='' style={{ width: '20px', height: '20px' }} src="https://cdn-icons-png.flaticon.com/512/263/263142.png" alt="" />
                        <span className='ms-1'>Kosárba</span>
                      </button>
                    </div> 
                  </div>
                </div>
              </div>
              <div className="d-flex col-md-3">
                <div className="card rounded-1 custom-card shadow">
                  <img src="https://s13emagst.akamaized.net/products/52198/52197748/images/res_60ddd957789b027d92ec154edd88a6b1.jpg?width=720&height=720&hash=D5D6801DFD57E974426198BDD3572B03" className="card-img-top" alt="Card Image"/>
                  <div className="card-body shadow">
                  <h5 className="card-title">Card 2</h5>
                  <div>
                      <div className='text-start' >
                          <span style={{marginRight:'5px'}}>Értékelés:</span>
                          <span className=' fw-bold'>0.0</span>
                      </div>
                    </div>
                    <div className='text-end'>
                      <p style={{backgroundColor:'#32CD32'}} className='badge'>Raktáron</p>
                    </div>
                     <div className="container mt-0 w-75 d-flex justify-content-center">
                      <button id='arnyekolasGomb' style={{ backgroundColor: 'silver' }} className="btn btn-rounded">
                        <img className='' style={{ width: '20px', height: '20px' }} src="https://cdn-icons-png.flaticon.com/512/263/263142.png" alt="" />
                        <span className='ms-1'>Kosárba</span>
                      </button>
                    </div> 
                  </div>
                </div>
              </div>
            </div>
            <div className="row mb-3">
              <div className="d-flex col-md-3">
                <div className="card rounded-1 custom-card shadow">
                  <img src="https://s13emagst.akamaized.net/products/57170/57169744/images/res_c4bcb9c102c648d13347aa24e117220d.jpg?width=720&height=720&hash=6A33C59FCBB0ADB7B189E50CB7593470" className="card-img-top" alt="Card Image"/>
                  <div className="card-body shadow">
                  <h5 className="card-title">Card 2</h5>
                  <div>
                      <div className='text-start' >
                          <span style={{marginRight:'5px'}}>Értékelés:</span>
                          <span className=' fw-bold'>0.0</span>
                      </div>
                    </div>
                    <div className='text-end'>
                      <p style={{backgroundColor:'#32CD32'}} className='badge'>Raktáron</p>
                    </div>
                     <div className="container mt-0 w-75 d-flex justify-content-center">
                      <button id='arnyekolasGomb' style={{ backgroundColor: 'silver' }} className="btn btn-rounded">
                        <img className='' style={{ width: '20px', height: '20px' }} src="https://cdn-icons-png.flaticon.com/512/263/263142.png" alt="" />
                        <span className='ms-1'>Kosárba</span>
                      </button>
                    </div> 
                  </div>
                </div>
              </div>
              <div className="d-flex col-md-3">
                <div className="card rounded-1 custom-card shadow">
                  <img src="https://s13emagst.akamaized.net/products/36726/36725029/images/res_e4f9b4c591d85c8574e97829b7ccb482.jpg?width=720&height=720&hash=B5858D91396E7A5690CACB25C29E2318" className="card-img-top" alt="Card Image"/>
                  <div className="card-body shadow">
                  <h5 className="card-title">Card 2</h5>
                  <div>
                      <div className='text-start' >
                          <span style={{marginRight:'5px'}}>Értékelés:</span>
                          <span className=' fw-bold'>0.0</span>
                      </div>
                    </div>
                    <div className='text-end'>
                      <p style={{backgroundColor:'#32CD32'}} className='badge'>Raktáron</p>
                    </div>
                     <div className="container mt-0 w-75 d-flex justify-content-center">
                      <button id='arnyekolasGomb' style={{ backgroundColor: 'silver' }} className="btn btn-rounded">
                        <img className='' style={{ width: '20px', height: '20px' }} src="https://cdn-icons-png.flaticon.com/512/263/263142.png" alt="" />
                        <span className='ms-1'>Kosárba</span>
                      </button>
                    </div> 
                  </div>
                </div>
              </div>
              <div className="d-flex col-md-3">
                <div className="card rounded-1 custom-card shadow">
                  <img src="https://s13emagst.akamaized.net/products/32447/32446033/images/res_f43843d7e379e7ac91d67dc412ea082a.jpg?width=720&height=720&hash=361DC19C5BE9A21367C03DEF4DA2C575" className="card-img-top" alt="Card Image"/>
                  <div className="card-body shadow">
                  <h5 className="card-title">Card 2</h5>
                  <div>
                      <div className='text-start' >
                          <span style={{marginRight:'5px'}}>Értékelés:</span>
                          <span className=' fw-bold'>0.0</span>
                      </div>
                    </div>
                    <div className='text-end'>
                      <p style={{backgroundColor:'#32CD32'}} className='badge'>Raktáron</p>
                    </div>
                     <div className="container mt-0 w-75 d-flex justify-content-center">
                      <button id='arnyekolasGomb' style={{ backgroundColor: 'silver' }} className="btn btn-rounded">
                        <img className='' style={{ width: '20px', height: '20px' }} src="https://cdn-icons-png.flaticon.com/512/263/263142.png" alt="" />
                        <span className='ms-1'>Kosárba</span>
                      </button>
                    </div> 
                  </div>
                </div>
              </div>
              <div className="d-flex col-md-3">
                <div className="card rounded-1 custom-card shadow">
                  <img src="https://s13emagst.akamaized.net/products/52198/52197748/images/res_60ddd957789b027d92ec154edd88a6b1.jpg?width=720&height=720&hash=D5D6801DFD57E974426198BDD3572B03" className="card-img-top" alt="Card Image"/>
                  <div className="card-body shadow">
                  <h5 className="card-title">Card 2</h5>
                  <div>
                      <div className='text-start' >
                          <span style={{marginRight:'5px'}}>Értékelés:</span>
                          <span className=' fw-bold'>0.0</span>
                      </div>
                    </div>
                    <div className='text-end'>
                      <p style={{backgroundColor:'#32CD32'}} className='badge'>Raktáron</p>
                    </div>
                     <div className="container mt-0 w-75 d-flex justify-content-center">
                      <button id='arnyekolasGomb' style={{ backgroundColor: 'silver' }} className="btn btn-rounded">
                        <img className='' style={{ width: '20px', height: '20px' }} src="https://cdn-icons-png.flaticon.com/512/263/263142.png" alt="" />
                        <span className='ms-1'>Kosárba</span>
                      </button>
                    </div> 
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
  )
}
