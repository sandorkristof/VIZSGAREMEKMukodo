import React, { useEffect, useState } from 'react';
import './style.css';

export default function Laptopok() {
  const [price, setPrice] = useState(0);
  const [manufacturerFilters, setManufacturerFilters] = useState([]);
  const [memoryTypeFilter, setMemoryTypeFilter] = useState('');
  const [memoryCapacityFilter, setMemoryCapacityFilter] = useState('');
  const [products, setProducts] = useState([]);

  const [filteredProducts, setFilteredProducts] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const apiUrl = 'http://localhost:5259/Product/getAll';
      try {
        const response = await fetch(apiUrl);
        const data = await response.json();
  
        // Szűrés a Kategoria_Id alapján (1-es Kategoria_Id)
        const filteredProducts = data.filter(product => product.categoryId === 19);
  
        // Beállítjuk mindkét állapotot a lefetchelt és szűrt adatokkal
        setProducts(data);
        setFilteredProducts(filteredProducts);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
  
    fetchData();
  }, []);
   // üres dependencies array, így csak egyszer fut le a komponens betöltésekor

  useEffect(() => {
    // Szűrés a megváltozott értékek alapján
    filterProducts();
  }, [price, manufacturerFilters, memoryTypeFilter, memoryCapacityFilter]);

  const handlePriceChange = (event) => {
    const newPrice = parseInt(event.target.value, 10);
    setPrice(newPrice);
  };

  const handleManufacturerChange = (event) => {
    const manufacturer = event.target.value;
    setManufacturerFilters(toggleFilter(manufacturerFilters, manufacturer));
  };

  const handleMemoryTypeChange = (event) => {
    const memoryType = event.target.value;
    setMemoryTypeFilter(memoryType);
  };

  const handleMemoryCapacityChange = (event) => {
    const memoryCapacity = event.target.value;
    setMemoryCapacityFilter(memoryCapacity);
  };

  const toggleFilter = (filters, value) => {
    if (filters.includes(value)) {
      return filters.filter(filter => filter !== value);
    } else {
      return [...filters, value];
    }
  };

  const filterProducts = () => {
    const filtered = products.filter(
      product =>
        product.categoryId === 19 && // Szűrés a Kategoria_Id alapján (1-es Kategoria_Id)
        product.price >= price &&
        (manufacturerFilters.length === 0 || manufacturerFilters.includes(product.manufacturer)) &&
        (memoryTypeFilter === '' || memoryTypeFilter === product.memoryType) &&
        (memoryCapacityFilter === '' || memoryCapacityFilter === product.memoryCapacity)
    );
    setFilteredProducts(filtered);
  };
  return (
    <div>
      <div className='d-flex'>
        
        <div style={{width:'400px'}} className='float-start mx-3'>
          <div className="menu-container mt-5 ">
              <div class="row mb-3">
                <div  class="col-md-12 mb-3">
                  <div class="card custom-card shadow">
                          <div className="card-body">
                    <h5 className="card-title">Gyártók</h5>
                    {['Samsung', 'LG', 'Philips', 'Sony'].map(manufacturer => (
                      <div key={manufacturer} className="form-check">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          value={manufacturer}
                          id={`checkbox-${manufacturer}`}
                          onChange={handleManufacturerChange}
                          checked={manufacturerFilters.includes(manufacturer)}
                        />
                        <label className="form-check-label" htmlFor={`checkbox-${manufacturer}`}>
                          {manufacturer}
                        </label>
                      </div>
                    ))}
                  </div>
                  </div>
                </div>
                <div  className="col-md-12 mb-3">
                    <div className="card custom-card shadow">
                      <div className="card-body">
                      <div>
                        <label htmlFor="priceSlider">Ár :</label>
                        <br />
                        <input style={{width:'230px'}} type="range"id="priceSlider" name="price" min={0} max={1000000} value={price} onChange={handlePriceChange} />
                        <p> {price} Ft</p>
                      </div>
                      </div>
                    </div>
                  </div>
                <div class="col-md-12 mb-3">
                  <div class="card custom-card shadow">
                    <div class="card-body">
                      <h5 class="card-title">Kapacitás</h5>
                      <select class="form-control"value={memoryCapacityFilter} onChange={handleMemoryCapacityChange}>
                        <option value=""></option>
                        <option value="4GB">4 GB</option>
                        <option value="6GB">6 GB</option>
                        <option value="8GB">8 GB</option>
                        <option value="12GB">12 GB</option>
                        <option value="16GB">16 GB</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-12 mb-3">
                  <div class="card custom-card shadow">
                    <div class="card-body">
                      <h5 class="card-title">Memória típus</h5>
                      <select class="form-control"value={memoryTypeFilter} onChange={handleMemoryTypeChange}>
                      <option value=""></option>
                        <option value="DDR3">DDR3</option>
                        <option value="DDR4">DDR4</option>
                        <option value="DDR5">DDR5</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
          </div>
        </div>
        <div class="row mb-3">
        <div className='float-end'>
          <div className="container mt-5">
      <div className="card-container">
      {filteredProducts.map(product => (
          <div key={product.id} className='col mb-3'>
            <div className='card shadow-sm'>
              <img src={product.photo} alt={product.name} className='card-img-top' style={{ height: '300px', objectFit: 'fill' }} />
              <div className='card-body'>
                <h5 className='card-title'>{product.MarkaNev}</h5>
                <p className='card-text'>{product.name}</p>
                <p className='card-text'>{product.description}</p>
                <p className='card-text'>
                  <strong>Ár:</strong> {product.price} Ft
                </p>
                <p className='card-text'>Értékelés 10/{product.review}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
        </div>
        </div>
    </div>
    </div>
  )
}
