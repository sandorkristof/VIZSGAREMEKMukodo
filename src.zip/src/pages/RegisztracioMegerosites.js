import React, { useState } from 'react';
import { Link,Route,Routes } from "react-router-dom";



export default function RegisztracioMegerosites() {
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [verificationResult, setVerificationResult] = useState('');


  const handleVerification = async () => {
    try {
      // Felhasználó által bevitt adatok kinyerése az input mezőkből
      const userEmail = document.getElementById('email').value;
      const userVerificationCode = document.getElementById('code').value;
  
      const requestBody = {
        email: userEmail,
        vfCode: userVerificationCode
      };
  
      const response = await fetch('http://localhost:5259/User/verifyAccount', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'accept': '*/*'
        },
        body: JSON.stringify(requestBody),
      });
  
  
      if (response.ok) {
        setVerificationResult("Sikeres fiók megerősítés"); 
        window.location.href = '/Bejelentkezes';
      } else {
        setVerificationResult('Sikertelen fiók megerősítés');
      }
    } catch (error) {
      console.error('Hiba történt a fiók megerősítésekor:', error);
      setVerificationResult('Hiba történt a fiók megerősítésekor');
    }
  };
   


  return (
    <div className="container">
    <div className="row d-flex justify-content-center mt-5">
      <div className="col-md-6 d-flex justify-content-center">
        <div className="card">
          <div className="card-body">
            <h5 className="card-title mb-4">Regisztráció megerősítése</h5>
            <form >
            <div>
                <label htmlFor="email">Email cím:</label>
                <input type="email" className='form-control' id="email" value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
              <div>
                <label htmlFor="code" className='mt-3'>Megerősítő kód:</label>
                <input type="text" className='form-control' id="code" value={code} onChange={(e) => setCode(e.target.value)} />
              </div>
              <button className='btn btn-primary mt-3' onClick={handleVerification}>Fiók megerősítése</button>
                {verificationResult && <div>{verificationResult}</div>}
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  )
}
