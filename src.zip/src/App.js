import './App.css';
import React, { useEffect, useState } from 'react';
import { Link,Route,Routes } from "react-router-dom";
import Home from './pages/Home';
import Search from './pages/Kereso';
//Navbar Component
import MuszakiCikk from './pages/MuszakiCikk';
import Szamitogep from './pages/Szamitogep';
import Periferiak from './pages/Periferiak';
import Mobiltelefonok from './pages/Mobiltelefonok';
import Kiegeszitok from './pages/Kiegeszitok';
import Regisztracio from './pages/Regisztracio';
import Bejelentkezes from './pages/Bejelentkezes';
import Fiok from './pages/Fiok';
import Kosar from './pages/Kosar';
//Műszaki cikk
import Television from './pages/MuszakicikkOldalak/Televizio';
import Konzol from './pages/MuszakicikkOldalak/Konzol';
import Routerek from './pages/MuszakicikkOldalak/Routerek';
import Kamera from './pages/MuszakicikkOldalak/Kamerak';
import Laptop from './pages/MuszakicikkOldalak/Laptopok';
import Earbuds from './pages/MuszakicikkOldalak/Earbuds';
//Periferiak
import Monitor from './pages/PeriferiakOldalak/Monitorok';
import Fejhallgato from './pages/PeriferiakOldalak/Fejhallgato';
import Eger from './pages/PeriferiakOldalak/Egerek';
import Bill from './pages/PeriferiakOldalak/Bill';
import Szek from './pages/PeriferiakOldalak/Szekek';
import Egerpad from './pages/PeriferiakOldalak/Egerpad';
//Számítógép alkatrészek
import Alaplapok from './pages/PCalkatreszek/Alaplap';
import Processor from './pages/PCalkatreszek/Cpu';
import Gephaz from './pages/PCalkatreszek/Gephaz';
import Videokartya from './pages/PCalkatreszek/Videokartya';
import Tapegyseg from './pages/PCalkatreszek/Tapegyseg';
import Memoria from './pages/PCalkatreszek/Memoria';
//Mobiltelefonok
import Apple from './pages/MobiltelefonOldalak/Apple';
import Samsung from './pages/MobiltelefonOldalak/Samsung';
import Xiaomi from './pages/MobiltelefonOldalak/Xiaomi';
//Kiegészítők
import Paste from './pages/KiegeszitoOldalak/Paste';
import Speaker from './pages/KiegeszitoOldalak/Speaker';
import Cables from './pages/KiegeszitoOldalak/Cables';



function App() {
  
 
  
  return (
    <div className="App">
      	
        
        <div className="superNav border-bottom py-2">
      <div className="container">
        <div className="row">
          <div className="col-lg-6 col-md-6 col-sm-12 col-12 centerOnMobile">
            <span className="navbar-brand" href="#">info@gmail.com</span>
          </div>
          <div className="col-lg-6 col-md-6 col-sm-12 col-12 d-flex justify-content-end">
            <Link style={{ textDecoration: "none", color: "black" }} to="/Regisztracio">
              <span className="navbar-brand" id='SupernavColor'>Regisztráció</span>
            </Link>
            <Link style={{ textDecoration: "none", color: "black", marginLeft: "20px" }} to="/Bejelentkezes">
              <span className="navbar-brand" id='SupernavColor'>Bejelentkezés</span>
            </Link>
          </div>
        </div>
      </div>
    </div>

    <nav className="navbar navbar-expand-lg sticky-top navbar-light p-3 shadow-sm" style={{background:'linear-gradient(90deg, rgba(2,0,36,1) 1%, rgba(9,9,121,1) 12%, rgba(0,212,255,1) 100%)'}}>
  <div className="container">
    <Link to="/" className="navbar-brand">
      <span className="nav-link"id='navColor' >MeDoSa</span>
    </Link>
    
    <div className="collapse navbar-collapse" id="navbarNavDropdown">
  <ul className="navbar-nav ms-auto">
    <li className="nav-item">
      <Link to="/MuszakiCikk" id='navColor' className="nav-link fs-6">Műszaki cikk</Link>
    </li>
    <li className="nav-item">
      <Link to="/Perifériák" className="nav-link fs-6" id='navColor'>Perifériák</Link>
    </li>
    <li className="nav-item">
      <Link to="/PCalkatrészek" className="nav-link fs-6" id='navColor'>Számítógép alkatrészek</Link>
    </li>
    <li className="nav-item">
      <Link to="/Mobiltelefonok" className="nav-link fs-6" id='navColor'>Mobiltelefonok</Link>
    </li>
    <li className="nav-item">
      <Link to="/Kiegeszitok" className="nav-link fs-6" id='navColor'>Kiegészítők</Link>
    </li>
  </ul>
  <ul className="navbar-nav ms-auto">
    <div className="d-inline-flex">
      <div className="me-3">
        <Link to="/Kosar" className="nav-link fs-6">
          <span className="position-relative">
            <span className="nav-link" id='navColor'>Kosár</span>
            <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">18+<span className="visually-hidden">unread messages</span></span>
          </span>
        </Link>
      </div>
      <div className="position-relative mt-2">
        <Link to="/Fiok" className="nav-link fs-6" id='navColor'>Fiókom</Link>
      </div>
    </div>
  </ul>
</div>
  </div>
</nav>
    





    
   







    














































      
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/MuszakiCikk' element={<MuszakiCikk/>}/>
        <Route path='/PCalkatrészek' element={<Szamitogep/>}/>
        <Route path='/Perifériák' element={<Periferiak/>}/>
        <Route path='/Mobiltelefonok' element={<Mobiltelefonok/>}/>
        <Route path='/Kiegeszitok' element={<Kiegeszitok/>}/>
        <Route path='/Regisztracio' element={<Regisztracio/>}/>
        <Route path='/Bejelentkezes' element={<Bejelentkezes/>}/>
        <Route path='/Fiok' element={<Fiok/>}/>
        <Route path='/Kosar' element={<Kosar/>}/>
        {/*Műszaki cikk oldalai*/}
        <Route path='/Televíziók' element={<Television/>}/>
        <Route path='/Konzol' element={<Konzol/>}/>
        <Route path='/Routerek' element={<Routerek/>}/>
        <Route path='/Kamerák' element={<Kamera/>}/>
        <Route path='/Laptopok' element={<Laptop/>}/>
        <Route path='/Fülhallgatók' element={<Earbuds/>}/>
        {/*Perifériák oldalai*/}
        <Route path='/Monitorok' element={<Monitor/>}/>
        <Route path='/Fejhallgatók' element={<Fejhallgato/>}/>
        <Route path='/Egerek' element={<Eger/>}/>
        <Route path='/Billentyűzetek' element={<Bill/>}/>
        <Route path='/Székek' element={<Szek/>}/>
        <Route path='/Egérpadok' element={<Egerpad/>}/>
        {/*Számítógép alkatrész oldalai*/}
        <Route path='/Alaplapok'element={<Alaplapok/>}/>
        <Route path='/Processzorok'element={<Processor/>}/>
        <Route path='/Gépházak'element={<Gephaz/>}/>
        <Route path='/Videokartya'element={<Videokartya/>}/>
        <Route path='/Tápegységek'element={<Tapegyseg/>}/>
        <Route path='/Memóriák'element={<Memoria/>}/>
        {/*Mobiltelefonok oldalai*/}
        <Route path='/Apple' element={<Apple/>}/>
        <Route path='/Samsung' element={<Samsung/>}/>
        <Route path='/Xiaomi' element={<Xiaomi/>}/>
        {/*Kiegészítők oldalai*/}
        <Route path='/Paszták' element={<Paste/>}/>
        <Route path='/Hangszórók' element={<Speaker/>}/>
        <Route path='/Kábelek' element={<Cables/>}/>
      </Routes>
    </div>
  );
}

export default App;
