import './App.css';
import React from 'react';
import { Link,Route,Routes } from "react-router-dom";
import Home from './pages/Home';
//Navbar Component
import MuszakiCikk from './pages/MuszakiCikk';
import Szamitogep from './pages/Szamitogep';
import Periferiak from './pages/Periferiak';
import Mobiltelefonok from './pages/Mobiltelefonok';
import Kiegeszitok from './pages/Kiegeszitok';
import Regisztracio from './pages/Regisztracio';
import Bejelentkezes from './pages/Bejelentkezes';
import Fiok from './pages/Fiok';
import Kosar from './pages/Kosar';
//Műszaki cikk
import Television from './pages/MuszakicikkOldalak/tv';
import Konzol from './pages/MuszakicikkOldalak/konzol';
import Routerek from './pages/MuszakicikkOldalak/routerek';
import Kamera from './pages/MuszakicikkOldalak/kamerak';
import Laptop from './pages/MuszakicikkOldalak/laptopok';
import Earbuds from './pages/MuszakicikkOldalak/earbuds';
//Periferiak
import Monitor from './pages/PeriferiakOldalak/monitorok';
import Fejhallgato from './pages/PeriferiakOldalak/fejhallgato';
import Eger from './pages/PeriferiakOldalak/egerek';
import Bill from './pages/PeriferiakOldalak/bill';
import Szek from './pages/PeriferiakOldalak/szekek';
import Egerpad from './pages/PeriferiakOldalak/egerpad';
//Számítógép alkatrészek
import Alaplapok from './pages/PCalkatreszek/alaplap';
import Processor from './pages/PCalkatreszek/cpu';
import Gephaz from './pages/PCalkatreszek/gephaz';
import Videokartya from './pages/PCalkatreszek/videokartya';
import Tapegyseg from './pages/PCalkatreszek/tapegyseg';
import Memoria from './pages/PCalkatreszek/memoria';
//Mobiltelefonok
import Apple from './pages/MobiltelefonOldalak/apple';
import Samsung from './pages/MobiltelefonOldalak/samsung';
import Xiaomi from './pages/MobiltelefonOldalak/xiaomi';
//Kiegészítők
import Paste from './pages/KiegeszitoOldalak/paste';
import Speaker from './pages/KiegeszitoOldalak/speaker';
import Cables from './pages/KiegeszitoOldalak/cables';



function App() {

  
  return (
    <div className="App">
      	
        
        <div className="superNav border-bottom py-2 ">
      <div className="container">
        <div className="row">
          <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12 centerOnMobile">
          <span className="navbar-brand" href="#">info@gmail.com</span>
          </div>
          <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12 d-none d-lg-block d-md-block-d-sm-block d-xs-none text-end">
          <Link style={{textDecoration:"none",color:"black"}} to="/Regisztracio">
        <span className="navbar-brand" href="#">Regisztráció</span>
        </Link>
        <Link style={{textDecoration:"none",color:"black#002244",marginLeft:"20px"}} to="/Bejelentkezes">
        <span className="navbar-brand" href="#">Bejelentkezés</span>
        </Link>
          </div>
        </div>
      </div>
    </div>

    <nav style={{background:'linear-gradient(90deg, rgba(2,0,36,1) 1%, rgba(9,9,121,1) 12%, rgba(0,212,255,1) 100%)'}} className="navbar navbar-expand-lg   sticky-top navbar-light p-3 shadow-sm">
      <div className="container">
        <Link style={{textDecoration:"none",color:"black"}} to="/">
        <span className="navbar-brand text-white" href="#">MeDoSa</span>
        </Link>
        <div className=" collapse navbar-collapse" id="navbarNavDropdown">
          
          <ul className="navbar-nav ms-auto ">
            <li className="nav-item ">
            <Link style={{color:"black",textDecoration:"none"}} to="/MuszakiCikk">
            <span className="nav-link mx-2 text-white" href="#">Műszaki cikk</span>
            </Link>
            </li>
            <li className="nav-item">
            <Link style={{color:"black",textDecoration:"none"}} to="/Perifériák">
            <span className="nav-link mx-2 text-white" href="#">Perifériák</span>
            </Link>
            </li>
            <li className="nav-item">
            <Link style={{color:"black",textDecoration:"none"}} to="/PCalkatrészek">
            <span className="nav-link mx-2 text-white" href="#">Számítógép alkatrészek</span>
            </Link>            </li>
            <li className="nav-item">
            <Link style={{color:"black",textDecoration:"none"}} to="/Mobiltelefonok">
            <span className="nav-link mx-2 text-white" href="#">Mobiltelefonok</span>
            </Link>            </li>
            <li className="nav-item">
            <Link style={{color:"black",textDecoration:"none"}} to="/Kiegeszitok">
            <span className="nav-link mx-2 text-white" href="#">Kiegészítők</span>
            </Link>
                        </li>
          </ul>
          <ul className="navbar-nav ms-auto ">
            <li style={{marginBottom:'0px',marginTop:'7.8px'}} className="nav-item">
            <Link style={{color:"black",textDecoration:"none"}} to="/Kosar">
            <div class="position-relative">
              <span class="text-white">Kosár</span>
              <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">18+<span class="visually-hidden">unread messages</span></span>
            </div>

            </Link>
            </li>
            <li className="nav-item">
            <Link style={{color:"black",textDecoration:"none"}} to="/Fiok">
            <span className="nav-link mx-2 text-white" href="#">Fiókom</span>
            </Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    





    
   







    














































      
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/MuszakiCikk' element={<MuszakiCikk/>}/>
        <Route path='/PCalkatrészek' element={<Szamitogep/>}/>
        <Route path='/Perifériák' element={<Periferiak/>}/>
        <Route path='/Mobiltelefonok' element={<Mobiltelefonok/>}/>
        <Route path='/Kiegeszitok' element={<Kiegeszitok/>}/>
        <Route path='/Regisztracio' element={<Regisztracio/>}/>
        <Route path='/Bejelentkezes' element={<Bejelentkezes/>}/>
        <Route path='/Fiok' element={<Fiok/>}/>
        <Route path='/Kosar' element={<Kosar/>}/>
        {/*Műszaki cikk oldalai*/}
        <Route path='/Televíziók' element={<Television/>}/>
        <Route path='/Konzol' element={<Konzol/>}/>
        <Route path='/Routerek' element={<Routerek/>}/>
        <Route path='/Kamerák' element={<Kamera/>}/>
        <Route path='/Laptopok' element={<Laptop/>}/>
        <Route path='/Fülhallgatók' element={<Earbuds/>}/>
        {/*Perifériák oldalai*/}
        <Route path='/Monitorok' element={<Monitor/>}/>
        <Route path='/Fejhallgatók' element={<Fejhallgato/>}/>
        <Route path='/Egerek' element={<Eger/>}/>
        <Route path='/Billentyűzetek' element={<Bill/>}/>
        <Route path='/Székek' element={<Szek/>}/>
        <Route path='/Egérpadok' element={<Egerpad/>}/>
        {/*Számítógép alkatrész oldalai*/}
        <Route path='/Alaplapok'element={<Alaplapok/>}/>
        <Route path='/Processzorok'element={<Processor/>}/>
        <Route path='/Gépházak'element={<Gephaz/>}/>
        <Route path='/Videokartya'element={<Videokartya/>}/>
        <Route path='/Tápegységek'element={<Tapegyseg/>}/>
        <Route path='/Memóriák'element={<Memoria/>}/>
        {/*Mobiltelefonok oldalai*/}
        <Route path='/Apple' element={<Apple/>}/>
        <Route path='/Samsung' element={<Samsung/>}/>
        <Route path='/Xiaomi' element={<Xiaomi/>}/>
        {/*Kiegészítők oldalai*/}
        <Route path='/Paszták' element={<Paste/>}/>
        <Route path='/Hangszórók' element={<Speaker/>}/>
        <Route path='/Kábelek' element={<Cables/>}/>
      </Routes>
    </div>
  );
}

export default App;
