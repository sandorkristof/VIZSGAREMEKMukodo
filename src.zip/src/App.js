import './App.css';
import Home from './pages/Home';
import MuszakiCikk from './pages/MuszakiCikk';
import Szamitogep from './pages/Szamitogep';
import Periferiak from './pages/Periferiak';
import Mobiltelefonok from './pages/Mobiltelefonok';
import Kiegeszitok from './pages/Kiegeszitok';
import Regisztracio from './pages/Registracio';
import Bejelentkezes from './pages/Bejelentkezes';
import Fiok from './pages/Fiok';
import Kosar from './pages/Kosar';
import { Link,Route,Routes } from "react-router-dom";

function App() {
  return (
    <div className="App">
      	
        
        <div className="superNav border-bottom py-2 bg-light">
      <div className="container">
        <div className="row">
          <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12 centerOnMobile">
            
          
          <span className="navbar-brand" href="#">info@gmail.com</span>
        
          </div>
          <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12 d-none d-lg-block d-md-block-d-sm-block d-xs-none text-end">
          <Link style={{textDecoration:"none",color:"black"}} to="/Registracio">
        <span className="navbar-brand" href="#">Regisztráció</span>
        </Link>
        <Link style={{textDecoration:"none",color:"black",marginLeft:"20px"}} to="/Bejelentkezes">
        <span className="navbar-brand" href="#">Bejelentkezés</span>
        </Link>
          </div>
        </div>
      </div>
    </div>

    <nav className="navbar navbar-expand-lg bg-white sticky-top navbar-light p-3 shadow-sm">
      <div className="container">
        <Link style={{textDecoration:"none",color:"black"}} to="/">
        <span className="navbar-brand" href="#">MeDoSa</span>
        </Link>
        <div className=" collapse navbar-collapse" id="navbarNavDropdown">
          
          <ul className="navbar-nav ms-auto ">
            <li className="nav-item ">
            <Link style={{color:"black",textDecoration:"none"}} to="/MuszakiCikk">
            <span className="nav-link mx-2 " href="#">Műszaki cikk</span>
            </Link>
            </li>
            <li className="nav-item">
            <Link style={{color:"black",textDecoration:"none"}} to="/Szamitogep">
            <span className="nav-link mx-2 " href="#">Számítógép</span>
            </Link>
            </li>
            <li className="nav-item">
            <Link style={{color:"black",textDecoration:"none"}} to="/Periferiak">
            <span className="nav-link mx-2 " href="#">Perifériák</span>
            </Link>            </li>
            <li className="nav-item">
            <Link style={{color:"black",textDecoration:"none"}} to="/Mobiltelefonok">
            <span className="nav-link mx-2 " href="#">Mobiltelefonok</span>
            </Link>            </li>
            <li className="nav-item">
            <Link style={{color:"black",textDecoration:"none"}} to="/Kiegeszitok">
            <span className="nav-link mx-2 " href="#">Kiegészítők</span>
            </Link>
                        </li>
          </ul>
          <ul className="navbar-nav ms-auto ">
            <li className="nav-item">
            <Link style={{color:"black",textDecoration:"none"}} to="/Kosar">
            <span className="nav-link mx-2 " href="#">Kosár</span>
            </Link>
            </li>
            <li className="nav-item">
            <Link style={{color:"black",textDecoration:"none"}} to="/Fiok">
            <span className="nav-link mx-2 " href="#">Fiókom</span>
            </Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <br />
    





    
   







    














































      
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/MuszakiCikk' element={<MuszakiCikk/>}/>
        <Route path='/Szamitogep' element={<Szamitogep/>}/>
        <Route path='/Periferiak' element={<Periferiak/>}/>
        <Route path='/Mobiltelefonok' element={<Mobiltelefonok/>}/>
        <Route path='/Kiegeszitok' element={<Kiegeszitok/>}/>
        <Route path='/Regisztracio' element={<Regisztracio/>}/>
        <Route path='/Bejelentkezes' element={<Bejelentkezes/>}/>
        <Route path='/Fiok' element={<Fiok/>}/>
        <Route path='/Kosar' element={<Kosar/>}/>


       

      </Routes>
    </div>
  );
}

export default App;
