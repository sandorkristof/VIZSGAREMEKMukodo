﻿namespace Webshop_API.Dtos
{
    public record ProductDto(Guid Id, string Photo,string Brand, string Name, int CategoryId, double Review, string Description, int Stock, int Price);

    public record ProductPreviewDto(Guid Id,string Photo, int CategoryId, string Brand, string Name, double Review, int Price);

    public record CreateProductDto(byte[] Photo, int CategoryId, string Brand, string Name, string Description, int Stock, int Price);

}
