﻿ using Webshop_API.Dtos;
using Webshop_API.Models;
using System.Net.Mail;


namespace Webshop_API
{
    public class Extensions
    {
        public static bool IsGuid(string input)
        {
            return Guid.TryParse(input, out _);
        }
        public static string ImageOut(byte[] image)
        {
            string imgBaseData = Convert.ToBase64String(image);
            string imageURL = string.Format("data:image/jpg;base64,{0}", imgBaseData);
            return imageURL;
        }

        public static string StringifyState(int stateNumber)
        {
            string state = "";
            switch (stateNumber)
            {
                case 1:
                    state = "Rendelés felvéve";
                    break;

                case 2:
                    state = "Rendelés előkészitve";
                    break;

                case 3:
                    state = "Atadva futárszolgálatnak";
                    break;

                case 4:
                    state = "Rendelés kézbesítve";
                    break;
            }

            return state;
        }
        public static ProductDto FormateProductToDto(Termek product, List<TermekErtekeles> reviews)
        {
            int count = 0;
            int rev = 0;
            foreach (var review in reviews)
            {
                if (review.TermekId == product.Id)
                {
                    count++;
                    rev += review.Ertekeles;
                }
            }
            if (count == 0)
            {
                var result = new ProductDto(product.Id, ImageOut(product.Foto), product.KategoriaId, product.Markanev, product.Nev, 0, product.Leiras, product.Keszlet, product.Ar);
                return result;
            }
            else
            {
                double finalReview = rev / count;
                var result = new ProductDto(product.Id, ImageOut(product.Foto), product.KategoriaId, product.Markanev, product.Nev, Math.Round(finalReview, 1), product.Leiras, product.Keszlet, product.Ar);
                return result;
            }
        }
        public static List<ProductDto> FormateProductsToDtoList(List<Termek> response, List<TermekErtekeles> reviews)
        {
            var result = new List<ProductDto>();
            foreach (var item in response)
            {
                int count = 0;
                int rev = 0;
                foreach (var review in reviews)
                {
                    if (review.TermekId == item.Id)
                    {
                        count++;
                        rev += review.Ertekeles;
                    }
                }
                if (count == 0)
                {
                    var placeholder = new ProductDto(item.Id, ImageOut(item.Foto), item.KategoriaId, item.Markanev,item.Nev, 0, item.Leiras, item.Keszlet, item.Ar);
                    result.Add(placeholder);
                }
                else
                {
                    double finalReview = rev / count;
                    var placeHolder = new ProductDto(item.Id, ImageOut(item.Foto), item.KategoriaId, item.Markanev, item.Nev, Math.Round(finalReview, 1), item.Leiras, item.Keszlet, item.Ar);
                    result.Add(placeHolder);
                }
            }

            return result;
        }

        public static List<ProductDtoToWpf> FormateProductsToWpfDtoList(List<Termek> response, List<TermekErtekeles> reviews)
        {
            var result = new List<ProductDtoToWpf>();
            foreach (var item in response)
            {
                int count = 0;
                int rev = 0;
                foreach (var review in reviews)
                {
                    if (review.TermekId == item.Id)
                    {
                        count++;
                        rev += review.Ertekeles;
                    }
                }
                if (count == 0)
                {
                    var placeholder = new ProductDtoToWpf(item.Id, item.Foto, item.KategoriaId, item.Markanev, item.Nev, 0, item.Leiras, item.Keszlet, item.Ar);
                    result.Add(placeholder);
                }
                else
                {
                    double finalReview = rev / count;
                    var placeHolder = new ProductDtoToWpf(item.Id, item.Foto, item.KategoriaId, item.Markanev, item.Nev, Math.Round(finalReview, 1), item.Leiras, item.Keszlet, item.Ar);
                    result.Add(placeHolder);
                }
            }

            return result;
        }


        public static List<WaitingToVerify> toVerifies = new List<WaitingToVerify>();
        public static void SendVerificationEMail(string emailAddress, string userName, string method)
        {
            Random rnd = new Random();
            string vfCode = "";
            for (int i = 0; i < 6; i++)
            {
                vfCode += rnd.Next(10).ToString();
            }
            toVerifies.Add(new WaitingToVerify(emailAddress, vfCode));
            
            MailMessage mail = new MailMessage();
            mail.From = new MailAddress("mesawebshop20@gmail.com");
            mail.To.Add(emailAddress);
            if (method == "rg")
            {
                mail.Subject = "Mesa Webshop - Regisztráció megerősítés";
                mail.Body = $"<h1>Köszönjük regisztrációját, {userName}!</h1><br> <h4 style=\"font-style:initial;\">Kérjük erősítse meg fiókját az alábbi kóddal: {vfCode}</h4>";

            }
            else if(method == "rp")
            {
                mail.Subject = "Mesa Webshop - Jelszó visszaállítás";
                mail.Body = $"<h1>Jelszó visszaállítási kérelmét elfogadtuk</h1><br> <h4 style=\"font-style:initial;\">Jelszavát az alábbi megerősítő kóddal tudja helyreállítani: {vfCode}</h4>";
            }
            else
            {
                mail.Subject = "Mesa Webshop - Megerősítő kód";
                mail.Body = $"<h1>Fiókjához tartozó kód: {vfCode}</h1>";
            }
            mail.IsBodyHtml = true;

            SmtpClient smtpServer = new SmtpClient("smtp.gmail.com");
            smtpServer.EnableSsl = true;
            smtpServer.UseDefaultCredentials = false;
            smtpServer.Credentials = new System.Net.NetworkCredential("mesawebshop20@gmail.com", "gvxy wjwy sxjv wdta");
            smtpServer.Port = 587;
            smtpServer.Send(mail);
        }
    }
}
