﻿using Webshop_API.Dtos;
using Webshop_API.Models;

namespace Webshop_API
{
    public class Extensions
    {
        public static bool IsGuid(string input)
        {
            return Guid.TryParse(input, out _);
        }
        public static string ImageOut(byte[] image)
        {
            string imgBaseData = Convert.ToBase64String(image);
            string imageURL = string.Format("data:image/jpg;base64,{0}", imgBaseData);
            return imageURL;
        }

        public static string StringifyState(int stateNumber)
        {
            string state = "";
            switch (stateNumber)
            {
                case 1:
                    state = "Rendelés felvéve";
                    break;

                case 2:
                    state = "Rendelés előkészitve";
                    break;

                case 3:
                    state = "Atadva futárszolgálatnak";
                    break;

                case 4:
                    state = "Rendelés kézbesítve";
                    break;
            }

            return state;
        }
        public static ProductDto FormateProductToDto(Termek product, List<TermekErtekeles> reviews)
        {
            int count = 0;
            int rev = 0;
            foreach (var review in reviews)
            {
                if (review.TermekId == product.Id)
                {
                    count++;
                    rev += review.Ertekeles;
                }
            }
            if (count == 0)
            {
                var result = new ProductDto(product.Id, product.Foto, product.Markanev,product.Nev, 0, product.Leiras, product.Keszlet, product.Ar);
                return result;
            }
            else
            {
                double finalReview = rev / count;
                var result = new ProductDto(product.Id, product.Foto, product.Markanev,product.Nev, Math.Round(finalReview, 1), product.Leiras, product.Keszlet, product.Ar);
                return result;
            }
        }
        public static List<ProductPreviewDto> FormateProductsToDtoList(List<Termek> response, List<TermekErtekeles> reviews)
        {
            var result = new List<ProductPreviewDto>();
            foreach (var item in response)
            {
                int count = 0;
                int rev = 0;
                foreach (var review in reviews)
                {
                    if (review.TermekId == item.Id)
                    {
                        count++;
                        rev += review.Ertekeles;
                    }
                }
                if (count == 0)
                {
                    var placeholder = new ProductPreviewDto(item.Id, item.Foto, item.Markanev,item.Nev, 0, item.Ar);
                    result.Add(placeholder);
                }
                else
                {
                    double finalReview = rev / count;
                    var placeHolder = new ProductPreviewDto(item.Id, item.Foto, item.Markanev, item.Nev, Math.Round(finalReview, 1), item.Ar);
                    result.Add(placeHolder);
                }
            }

            return result;
        }
    }
}
