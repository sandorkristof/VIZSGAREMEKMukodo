﻿using Webshop_API.Dtos;

namespace Webshop_API.Dtos
{
    public record OrderDto(Guid Id, Guid UserId, string OrderDate, string Address, int Cost, string OrderState, List<OrderedItemDto> ordereditems);
    public record OrderedItemDto(string Name, byte[] Photo, int Cost, int Quantity);

    public record AddOrderedItemDto(Guid ProductId, int Quantity);
    public record CreateOrderDto(Guid UserId, Guid AddressId, List<AddOrderedItemDto> orderedItems);

    public record UpdateOrderDto(Guid Id, int OrderState);
}
