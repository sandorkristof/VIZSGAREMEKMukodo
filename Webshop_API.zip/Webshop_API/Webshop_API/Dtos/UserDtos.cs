﻿namespace Webshop_API.Dtos
{
    public record LoginDto(string Email, string Password);
    public record RegisterDto(string Name, string Email, string Password);
    public record UpdateUserDto(Guid Id,string Name, string OldPassword, string NewPassword);
    public record DeleteUserDto(Guid Id, string Password);

    public record ResetPasswordDto(string Email, string Password, string vfCode);
    public record UserDto(Guid Id, string Name, string Email, string Password);

    public record WaitingToVerify(string Email, string vfCode);
    public record RequestVfCode(string Email, string Method);

}
