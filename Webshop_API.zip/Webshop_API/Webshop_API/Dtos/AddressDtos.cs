﻿namespace Webshop_API.Dtos
{
    public record CreateAddressDto(Guid UserId, int PostalCode, string Settlement, string Street, int Number, string Floor_Door);
    public record AddressDto(Guid Id, Guid UserId, int PostalCode, string Settlement, string Street, int Number, string Floor_Door);
    
}
