﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using System.Security.Cryptography;
using Webshop_API.Dtos;
using System.Runtime.InteropServices.Marshalling;
using Webshop_API.Models;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc.Routing;

namespace Webshop_API.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        public static string GenerateSHA256(string input)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] data = sha256.ComputeHash(Encoding.UTF8.GetBytes(input));
                var sBuilder = new StringBuilder();
                for (int i = 0; i < data.Length; i++)
                {
                    sBuilder.Append(data[i].ToString("x2"));
                }
                return sBuilder.ToString();
            }
        }

        [HttpPut("login")]
        public IActionResult Login(LoginDto loginDto) 
        {
            using(var dbContext = new MesaWebshopContext())
            {
                try
                {
                    var user = dbContext.Felhasznalo.FirstOrDefault(x => x.Email == loginDto.Email);
                    if (user == null)
                    {
                        return NotFound("Nincs ilyen emaillel rendelkező felhasználó!");
                    }
                    else
                    {
                        if (GenerateSHA256(loginDto.Password) == user.Jelszo)
                        {
                            return Ok("Sikeres bejelentkezés!" + user.Id);
                        }
                        else
                        {
                            return BadRequest("Hibás jelszó!");
                        }
                    }
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            };
        }
        
        [HttpPost("register")]
        public IActionResult Register(RegisterDto registerDto) 
        {
            using(var dbContext = new MesaWebshopContext())
            {
                try
                {
                    var existingUser = dbContext.Felhasznalo.FirstOrDefault(x => x.Email == registerDto.Email);
                    if (existingUser == null)
                    {
                        var newUser = new Felhasznalo()
                        {
                            Id = Guid.NewGuid(),
                            Nev = registerDto.Name,
                            Email = registerDto.Email,
                            Jelszo = GenerateSHA256(registerDto.Password),                           
                        };

                        dbContext.Felhasznalo.Add(newUser);
                        dbContext.SaveChanges();

                        return Ok("Sikeres regisztráció!");
                    }
                    else
                    {
                        return BadRequest("Már létezik felhasználó ezzel az email címmel!");
                    }
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            };
        }

        [HttpPut("updateUser")]
        public ActionResult UpdateUser(Guid id, UpdateDto updateDto)
        {
            try
            {
                using(var dbContext = new MesaWebshopContext())
                {
                    var existing = dbContext.Felhasznalo.FirstOrDefault(x => x.Id == id);
                    if (existing != null)
                    {
                        if (existing.Jelszo == updateDto.OldPassword && existing.Jelszo != updateDto.NewPassword)
                        {
                            existing.Nev = updateDto.Name;
                            existing.Jelszo = updateDto.NewPassword;

                            dbContext.Update(existing);
                            dbContext.SaveChanges();

                            return Ok("Sikeres módosítás!");
                        }
                        else
                        {
                            return BadRequest("Hibás jelszó!");
                        }
                    }
                    else
                    {
                        return NotFound("Nincs ilyen Id-vel rendelkező felhasználó!");
                    }
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("deleteUser")]
        public ActionResult DeleteUser(Guid id, string password) 
        {
            try
            {
                using (var dbContext = new MesaWebshopContext())
                {
                    var existing = dbContext.Felhasznalo.FirstOrDefault(x => x.Id == id);
                    if (existing != null)
                    {
                        if (existing.Jelszo == GenerateSHA256(password))
                        {
                            dbContext.Felhasznalo.Remove(existing);
                            dbContext.SaveChanges();

                            return Ok("Sikeres törlés!");
                        }
                        else
                        {
                            return BadRequest("Hibás jelszó!");
                        }
                    }
                    else
                    {
                        return NotFound("A felhasználó nem található!");
                    }
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
