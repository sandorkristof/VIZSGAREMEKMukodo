﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using System.Security.Cryptography;
using Webshop_API.Dtos;
using System.Runtime.InteropServices.Marshalling;
using Webshop_API.Models;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc.Routing;

namespace Webshop_API.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        public static string GenerateSHA256(string input)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] data = sha256.ComputeHash(Encoding.UTF8.GetBytes(input));
                var sBuilder = new StringBuilder();
                for (int i = 0; i < data.Length; i++)
                {
                    sBuilder.Append(data[i].ToString("x2"));
                }
                return sBuilder.ToString();
            }
        }

        [HttpGet("getall")]
        public ActionResult Get()
        {
            using (var dbContext = new MesaWebshopContext())
            {
                if (dbContext != null)
                {
                    return Ok(dbContext.Felhasznalo.ToList());
                }
                else
                {
                    return NotFound();
                }
            }
        }
        [HttpGet("getAllForWpf")]
        public ActionResult<IEnumerable<UserDto>> GetAllForWpf()
        {
            try
            {
                using(var dbContext = new MesaWebshopContext())
                {
                    var response = dbContext.Felhasznalo.ToList();

                    List<UserDto> result = new List<UserDto>();
                    foreach (var item in response)
                    {
                        var placeholder = new UserDto(item.Id, item.Nev, item.Email, item.Jelszo);
                        result.Add(placeholder);
                    }

                    return Ok(result);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("login")]
        public ActionResult<Felhasznalo> Login(LoginDto loginDto) 
        {
            using(var dbContext = new MesaWebshopContext())
            {
                try
                {
                    var user = dbContext.Felhasznalo.FirstOrDefault(x => x.Email == loginDto.Email);
                    if (user == null)
                    {
                        return NotFound("Nincs ilyen emaillel rendelkező felhasználó!");
                    }
                    else
                    {
                        if (user.Megerositve == 0)
                        {
                            return BadRequest("Nincs megerősítve a fiók!");
                        }
                        else if (GenerateSHA256(loginDto.Password) == user.Jelszo)
                        {
                            return Ok(user);
                        }
                        else
                        {
                            return BadRequest("Hibás jelszó!");
                        }
                    }
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            };
        }
        
        [HttpPost("register")]
        public ActionResult Register(RegisterDto registerDto) 
        {
            using(var dbContext = new MesaWebshopContext())
            {
                try
                {
                    var existingUser = dbContext.Felhasznalo.FirstOrDefault(x => x.Email == registerDto.Email);
                    if (existingUser == null)
                    {
                        Extensions.SendVerificationEMail(registerDto.Email,registerDto.Name, "rg");
                        var newUser = new Felhasznalo()
                        {
                            Id = Guid.NewGuid(),
                            Nev = registerDto.Name,
                            Email = registerDto.Email,
                            Jelszo = GenerateSHA256(registerDto.Password),
                            Megerositve = 0,
                        };

                        dbContext.Felhasznalo.Add(newUser);
                        dbContext.SaveChanges();

                        
                        return Ok("Sikeres regisztráció!");
                    }
                    else
                    {
                        return BadRequest("Már létezik felhasználó ezzel az email címmel!");
                    }
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            };
        }

        [HttpPost("verifyAccount")]
        public ActionResult Verify(WaitingToVerify toVerify)
        {
            try
            {
                if (Extensions.toVerifies.Contains(toVerify))
                {
                    Extensions.toVerifies.Remove(toVerify);
                    using (var dbContext = new MesaWebshopContext())
                    {
                        var existing = dbContext.Felhasznalo.FirstOrDefault(x => x.Email ==  toVerify.Email);
                        existing.Megerositve = 1;
                        dbContext.Update(existing);
                        dbContext.SaveChanges();

                        return Ok("Sikeres megerősítés!");
                    };
                }
                else
                {
                    return NotFound("Nem létezik az emaillel megerősítésre váró fiók!");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("updateUser")]
        public ActionResult UpdateUser(UpdateUserDto updateDto)
        {
            try
            {
                using(var dbContext = new MesaWebshopContext())
                {
                    var existing = dbContext.Felhasznalo.FirstOrDefault(x => x.Id == updateDto.Id);
                    if (existing != null)
                    {
                        if (existing.Jelszo == GenerateSHA256(updateDto.OldPassword) && existing.Jelszo != GenerateSHA256(updateDto.NewPassword))
                        {
                            existing.Nev = updateDto.Name;
                            existing.Jelszo = GenerateSHA256(updateDto.NewPassword);

                            dbContext.Update(existing);
                            dbContext.SaveChanges();

                            return Ok("Sikeres módosítás!");
                        }
                        else
                        {
                            return BadRequest("Hibás jelszó!");
                        }
                    }
                    else
                    {
                        return NotFound("Nincs ilyen Id-vel rendelkező felhasználó!");
                    }
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpHead("sendVerificationCode")]
        public ActionResult SendVerification(RequestVfCode requestVfCode)
        {
            try
            {
                using(var dbContext = new MesaWebshopContext())
                {
                    var existing = dbContext.Felhasznalo.FirstOrDefault(x => x.Email == requestVfCode.Email);
                    if (existing != null)
                    {
                        Extensions.SendVerificationEMail(requestVfCode.Email, "", requestVfCode.Method);

                        return Ok("Megerősítő kód elküldve az emailre!");
                    }
                    else
                    {
                        return NotFound("Nem található ilyen emaillel rendelekző felhasználó!");
                    }
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPut("resetPassword")]
        public ActionResult ResetPassword(ResetPasswordDto resetPasswordDto)
        {
            try
            {
                using (var dbContext = new MesaWebshopContext())
                {
                    var existing = dbContext.Felhasznalo.FirstOrDefault(x => x.Email == resetPasswordDto.Email);
                    WaitingToVerify waitingToVerify = new WaitingToVerify(resetPasswordDto.Email,resetPasswordDto.vfCode);

                    if (existing != null && Extensions.toVerifies.Contains(waitingToVerify))
                    {
                        Extensions.toVerifies.Remove(waitingToVerify);
                        existing.Jelszo = GenerateSHA256(resetPasswordDto.Password);
                        dbContext.Update(existing);
                        dbContext.SaveChanges();

                        return Ok("Jelszó sikeresen módosítva!");
                    }
                    else
                    {
                        return NotFound("A felhasználó nem található!");
                    }
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("deleteUser")]
        public ActionResult DeleteUser(DeleteUserDto deleteUser) 
        {
            try
            {
                using (var dbContext = new MesaWebshopContext())
                {
                    var existing = dbContext.Felhasznalo.FirstOrDefault(x => x.Id == deleteUser.Id);
                    if (existing != null)
                    {
                        if (existing.Jelszo == GenerateSHA256(deleteUser.Password))
                        {
                            dbContext.Felhasznalo.Remove(existing);
                            dbContext.SaveChanges();

                            return Ok("Sikeres törlés!");
                        }
                        else
                        {
                            return BadRequest("Hibás jelszó!");
                        }
                    }
                    else
                    {
                        return NotFound("A felhasználó nem található!");
                    }
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("deleteFromWpf")]
        public ActionResult DeleteFromWpf(UserDto userDto)
        {
            try
            {
                using(var dbContext = new MesaWebshopContext())
                {
                    var existing = dbContext.Felhasznalo.FirstOrDefault(x => x.Id == userDto.Id); 
                    if (existing != null)
                    {
                        dbContext.Felhasznalo.Remove(existing);
                        dbContext.SaveChanges();

                        return Ok("Sikeres törlés!");
                    }
                    else
                    {
                        return NotFound("Nem található a törölni kívánt felhasználó!");
                    }
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
