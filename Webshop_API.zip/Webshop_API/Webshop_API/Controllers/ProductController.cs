﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MySqlX.XDevAPI.Common;
using Webshop_API.Dtos;
using Webshop_API.Models;

namespace Webshop_API.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        [HttpGet("getAll")]
        public async Task<ActionResult<IEnumerable<ProductDto>>> GetAll() 
        {
            try
            {
                using (var dbContext = new MesaWebshopContext())
                {
                    var response = await dbContext.Termek.ToListAsync();
                    var reviews = await dbContext.TermekErtekeles.ToListAsync();
                    var result = Extensions.FormateProductsToDtoList(response, reviews);
                    return Ok(result);
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("getAllForWpf")]
        public async Task<ActionResult<IEnumerable<ProductDtoToWpf>>> GetAllForWpf()
        {
            try
            {
                using (var dbContext = new MesaWebshopContext())
                {
                    var response = await dbContext.Termek.ToListAsync();
                    var reviews = await dbContext.TermekErtekeles.ToListAsync();
                    var result = Extensions.FormateProductsToWpfDtoList(response, reviews);
                    return Ok(result);
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("getById")]
        public async Task<ActionResult<ProductDto>> GetById(Guid id)
        {
            try
            {
                using(var dbContext = new MesaWebshopContext())
                {
                    var response = await dbContext.Termek.FirstOrDefaultAsync(x => x.Id == id);
                    var reviews = await dbContext.TermekErtekeles.ToListAsync();
                    if (response != null)
                    {
                        var result = Extensions.FormateProductToDto(response, reviews);
                        return Ok(result);
                    }
                    else
                    {
                        return NotFound("Ez a termék nem szerepel az adatbázisunkban!");
                    }
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("getByCategory")]
        public async Task<ActionResult<IEnumerable<ProductDto>>> GetByCategory(int categoryId)
        {
            try
            {
                using(var dbContext = new MesaWebshopContext())
                {
                    var response = await dbContext.Termek.Where(x => x.KategoriaId == categoryId).ToListAsync();
                    var reviews = await dbContext.TermekErtekeles.ToListAsync();
                    if (response != null)
                    {
                        var result = Extensions.FormateProductsToDtoList(response, reviews);
                        return Ok(result);
                    }
                    else
                    {
                        return NotFound("Nincs ilyen kategóriájú termék!");
                    }
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("search")]
        public async Task<ActionResult<IEnumerable<ProductDto>>> GetBySearch(string search)
        {
            try
            {
                using(var dbContext = new MesaWebshopContext())
                {
                    var response = await dbContext.Termek.Where(x => x.Nev.ToLower().StartsWith(search.ToLower()) || x.Markanev.ToLower().StartsWith(search.ToLower())).ToListAsync();
                    var reviews = await dbContext.TermekErtekeles.ToListAsync();
                    if (response.Count == 0 || response == null)
                    {
                        return NotFound("Nem található ilyen termék!");
                    }
                    else
                    {
                        var result = Extensions.FormateProductsToDtoList(response, reviews);
                        return Ok(result);
                    }
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("uploadProduct")]
        public ActionResult CreateProduct(CreateProductDto createProductDto)
        {
            try
            {
                using(var dbContext = new MesaWebshopContext())
                {
                    var newProduct = new Termek()
                    {
                        Id = Guid.NewGuid(),
                        Foto = createProductDto.Photo,
                        KategoriaId = createProductDto.CategoryId,
                        Markanev = createProductDto.Brand,
                        Nev = createProductDto.Name,
                        Keszlet = createProductDto.Stock,
                        Leiras = createProductDto.Description,
                        Ar = createProductDto.Price
                    };

                    dbContext.Termek.Add(newProduct);
                    dbContext.SaveChanges();

                    return Ok("Sikeres hozzáadás!");
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("updateProduct")]
        public ActionResult UpdateProduct(ProductDtoToWpf productDto)
        {
            try
            {
                using (var dbContext = new MesaWebshopContext())
                {
                    var existing = dbContext.Termek.FirstOrDefault(x => x.Id == productDto.Id);
                    if (existing != null)
                    {
                        existing.Foto = productDto.Photo;
                        existing.Markanev = productDto.Brand;
                        existing.KategoriaId = productDto.CategoryId;
                        existing.Nev = productDto.Name;
                        existing.Leiras = productDto.Description;
                        existing.Ar = productDto.Price;
                        existing.Keszlet = productDto.Stock;

                        dbContext.Termek.Update(existing);
                        dbContext.SaveChanges();

                        return Ok("Sikeres módosítás!");
                    }
                    else
                    {
                        return NotFound("A keresett termék nem található!");
                    }
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("deleteProduct")]
        public ActionResult DeleteProduct(Guid id)
        {
            try
            {
                using(var dbContext = new MesaWebshopContext())
                {
                    var existing = dbContext.Termek.FirstOrDefault(x => x.Id == id);
                    if (existing != null)
                    {
                        dbContext.Termek.Remove(existing);
                        dbContext.SaveChanges();

                        return Ok("Sikeres törlés!");
                    }
                    else
                    {
                        return NotFound("A keresett termék nem található!");
                    }
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
