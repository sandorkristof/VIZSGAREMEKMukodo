﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Connections;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Webshop_API.Dtos;
using Webshop_API.Models;

namespace Webshop_API.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        [HttpGet("getRendelesByUser")]
        public async Task<ActionResult<IEnumerable<OrderDto>>> GetOrderByUserId(Guid userId)
        {
            try
            {
                using(var dbContext = new MesaWebshopContext())
                {
                    var existingOrders = dbContext.Rendeles.Where(x => x.FelhaszId == userId).ToList();
                    List<OrderDto> orders = new List<OrderDto>();

                    foreach (var item in existingOrders)
                    {
                        var orderedItems = dbContext.RendeltElem.Where(x => x.RendelesId == item.Id).ToList();
                        int cost = 0;

                        List<OrderedItemDto> products = new List<OrderedItemDto>();
                        foreach (var orderedItem in orderedItems)
                        {
                            var placeholder = dbContext.Termek.FirstOrDefault(x => x.Id == orderedItem.TermekId);
                            
                            cost += (int)placeholder.Ar * orderedItem.TermekDarab;

                            var product = new OrderedItemDto($"{placeholder.Markanev} {placeholder.Nev}", placeholder.Foto, placeholder.Ar,orderedItem.TermekDarab);
                            products.Add(product);
                        }

                        var orderaddress = dbContext.FelhasznaloCim.FirstOrDefault(x => x.Id == item.Cim); 
                        string address = $"{orderaddress.Irsz} {orderaddress.Telepules} {orderaddress.Utca} {orderaddress.Hazszam} {orderaddress.EmeletAjto}";

                        string orderstate = Extensions.StringifyState(item.Allapot);

                        string formatedDate = item.Datum.ToString("yyyy - MM - dd");
                        var order = new OrderDto(item.Id, item.FelhaszId, formatedDate, address, cost, orderstate, products);
                        
                        orders.Add(order);
                    }

                    return Ok(orders);
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("getAllRendeles")]
        public ActionResult<IEnumerable<OrderDto>> GetAllOrder()
        {
            try
            {
                using (var dbContext = new MesaWebshopContext())
                {
                    var existingOrders = dbContext.Rendeles.ToList();
                    List<OrderDto> orders = new List<OrderDto>();

                    foreach (var item in existingOrders)
                    {
                        var orderedItems = dbContext.RendeltElem.Where(x => x.RendelesId == item.Id).ToList();
                        int cost = 0;

                        List<OrderedItemDto> products = new List<OrderedItemDto>();
                        foreach (var orderedItem in orderedItems)
                        {
                            var placeholder = dbContext.Termek.FirstOrDefault(x => x.Id == orderedItem.TermekId);

                            cost += (int)placeholder.Ar * orderedItem.TermekDarab;

                            var product = new OrderedItemDto($"{placeholder.Markanev} {placeholder.Nev}", placeholder.Foto, placeholder.Ar, orderedItem.TermekDarab);
                            products.Add(product);
                        }

                        var orderaddress = dbContext.FelhasznaloCim.FirstOrDefault(x => x.Id == item.Cim);
                        string address = $"{orderaddress.Irsz} {orderaddress.Telepules} {orderaddress.Utca} {orderaddress.Hazszam} {orderaddress.EmeletAjto}";

                        string orderstate = Extensions.StringifyState(item.Allapot);

                        var order = new OrderDto(item.Id, item.FelhaszId, item.Datum.ToString("yyyy. MM. dd."), address, cost, orderstate, products);

                        orders.Add(order);
                    }

                    return Ok(orders);
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("postRendeles")]
        public ActionResult CreateOrder(CreateOrderDto createOrderDto)
        {
            try
            {
                using(var dbContext = new MesaWebshopContext())
                {
                    var orderId = Guid.NewGuid();
                    var newOrder = new Rendeles()
                    {
                        Id = orderId,
                        FelhaszId = createOrderDto.UserId,
                        Datum = DateTime.Now,
                        Cim = createOrderDto.AddressId,
                        Allapot = 1
                        
                    };

                    dbContext.Rendeles.Add(newOrder);

                    foreach (var item in createOrderDto.orderedItems)
                    {
                        var orderedItem = new RendeltElem()
                        {
                            Id = Guid.NewGuid(),
                            RendelesId = orderId,
                            TermekId = item.ProductId,
                            TermekDarab = item.Quantity,
                        };

                        dbContext.RendeltElem.Add(orderedItem);
                        
                    }

                    dbContext.SaveChanges();

                    return Ok("Sikeres rendelés!");
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.InnerException.Message);
            }
        }

        [HttpPut("updateRendeles")]
        public ActionResult UpdateOrder(UpdateOrderDto updateOrderDto)
        {
            try
            {
                using(var dbContext = new MesaWebshopContext())
                {
                    var existing = dbContext.Rendeles.FirstOrDefault(x => x.Id == updateOrderDto.Id);
                    if (existing != null)
                    {
                        existing.Allapot = updateOrderDto.OrderState;
                        dbContext.Rendeles.Update(existing);
                        dbContext.SaveChanges();

                        return Ok("Sikeres módosítás!");
                    }
                    else
                    {
                        return NotFound("Módosítani kívánt rendelés nem található!");
                    }
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
