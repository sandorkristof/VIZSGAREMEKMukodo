﻿using System;
using System.Collections.Generic;

namespace Webshop_API.Models;

public partial class Termek
{
    public Guid Id { get; set; }

    public byte[] Foto { get; set; } = null!;

    public int KategoriaId { get; set; }

    public string Markanev { get; set; } = null!;

    public string Nev { get; set; } = null!;

    public int Keszlet { get; set; }

    public string Leiras { get; set; } = null!;

    public int Ar { get; set; }

    public virtual Kategoriak Kategoria { get; set; } = null!;

    public virtual ICollection<RendeltElem> RendeltElems { get; set; } = new List<RendeltElem>();

    public virtual ICollection<TermekErtekeles> TermekErtekeles { get; set; } = new List<TermekErtekeles>();
}
