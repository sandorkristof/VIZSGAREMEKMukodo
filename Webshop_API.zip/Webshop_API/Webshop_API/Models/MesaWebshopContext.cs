﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Webshop_API.Models;

public partial class MesaWebshopContext : DbContext
{
    public MesaWebshopContext()
    {
    }

    public MesaWebshopContext(DbContextOptions<MesaWebshopContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Felhasznalo> Felhasznalo { get; set; }

    public virtual DbSet<FelhasznaloCim> FelhasznaloCim { get; set; }

    public virtual DbSet<Kategoriak> Kategoriak { get; set; }

    public virtual DbSet<Rendeles> Rendeles { get; set; }

    public virtual DbSet<RendelesAllapot> RendelesAllapot { get; set; }

    public virtual DbSet<RendeltElem> RendeltElem { get; set; }

    public virtual DbSet<Termek> Termek { get; set; }

    public virtual DbSet<TermekErtekeles> TermekErtekeles { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseMySQL("SERVER=localhost;PORT=3306;DATABASE=mesa_webshop;USER=root;PASSWORD=    ;SSL MODE=none;AllowPublicKeyRetrieval=true;");
    //SERVER=sandorkp1mysql.mysql.database.azure.com;PORT=3306;DATABASE=mesa_webshop;USER=sandorkp1;PASSWORD=Adatbazis-2024;
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Felhasznalo>(entity =>
        {     
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("felhasznalo");

            entity.Property(e => e.Email).HasMaxLength(60);
            entity.Property(e => e.Jelszo).HasMaxLength(200);
            entity.Property(e => e.Nev).HasMaxLength(50);
            entity.Property(e => e.Megerositve).HasMaxLength(1);
        });

        modelBuilder.Entity<FelhasznaloCim>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("felhasznalo_cim");

            entity.HasIndex(e => e.FelhaszId, "Felhasz_Id").IsUnique();

            entity.Property(e => e.EmeletAjto)
                .HasMaxLength(5)
                .HasColumnName("Emelet/Ajto");
            entity.Property(e => e.FelhaszId).HasColumnName("Felhasz_Id");
            entity.Property(e => e.Telepules).HasMaxLength(70);
            entity.Property(e => e.Utca).HasMaxLength(70);

            entity.HasOne(d => d.Felhasz).WithOne(p => p.FelhasznaloCim)
                .HasForeignKey<FelhasznaloCim>(d => d.FelhaszId)
                .HasConstraintName("felhasznalo_cim_ibfk_1");
        });

        modelBuilder.Entity<Kategoriak>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("kategoriak");

            entity.Property(e => e.Nev).HasMaxLength(120);
        });


        modelBuilder.Entity<Rendeles>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("rendeles");

            entity.HasIndex(e => e.Allapot, "Allapot");

            entity.HasIndex(e => e.Cim, "Cim").IsUnique();

            entity.HasIndex(e => e.FelhaszId, "Felhasz_Id");

            entity.Property(e => e.Datum).HasColumnType("date");
            entity.Property(e => e.FelhaszId).HasColumnName("Felhasz_Id");

            entity.HasOne(d => d.AllapotNavigation).WithMany(p => p.Rendeles)
                .HasForeignKey(d => d.Allapot)
                .HasConstraintName("rendeles_ibfk_1");

            entity.HasOne(d => d.CimNavigation).WithOne(p => p.Rendeles)
                .HasForeignKey<Rendeles>(d => d.Cim)
                .HasConstraintName("rendeles_ibfk_2");

            entity.HasOne(d => d.FelhasznaloId).WithMany(p => p.Rendeles)
                .HasForeignKey(d => d.FelhaszId)
                .HasConstraintName("rendeles_ibfk_3");
        });

        modelBuilder.Entity<RendelesAllapot>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("rendeles_allapot");

            entity.Property(e => e.Allapot).HasMaxLength(70);
        });

        modelBuilder.Entity<RendeltElem>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("rendelt_elem");

            entity.HasIndex(e => e.RendelesId, "Rendeles_Id");

            entity.HasIndex(e => e.TermekId, "Termek_Id");

            entity.Property(e => e.RendelesId).HasColumnName("Rendeles_Id");
            entity.Property(e => e.TermekId).HasColumnName("Termek_Id");

            entity.HasOne(d => d.Termek).WithMany(p => p.RendeltElems)
                .HasForeignKey(d => d.TermekId)
                .HasConstraintName("rendelt_elem_ibfk_2");
        });

        modelBuilder.Entity<Termek>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("termek");

            entity.HasIndex(e => e.KategoriaId, "Kategoria");

            entity.Property(e => e.Foto).HasColumnType("mediumblob");
            entity.Property(e => e.KategoriaId).HasColumnName("Kategoria_Id");
            entity.Property(e => e.Leiras).HasMaxLength(300);
            entity.Property(e => e.Nev).HasMaxLength(120);
            entity.Property(e => e.Markanev).HasMaxLength(30);

            entity.HasOne(d => d.Kategoria).WithMany(p => p.Termek)
                .HasForeignKey(d => d.KategoriaId)
                .HasConstraintName("termek_ibfk_2");
        });

        modelBuilder.Entity<TermekErtekeles>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("termek_ertekeles");

            entity.HasIndex(e => e.FelhasznaloId, "Felhasznalo_Id");

            entity.HasIndex(e => e.TermekId, "Termek_Id");

            entity.Property(e => e.FelhasznaloId).HasColumnName("Felhasznalo_Id");
            entity.Property(e => e.TermekId).HasColumnName("Termek_Id");

            entity.HasOne(d => d.Felhasznalo).WithMany(p => p.TermekErtekeles)
                .HasForeignKey(d => d.FelhasznaloId)
                .HasConstraintName("termek_ertekeles_ibfk_1");

            entity.HasOne(d => d.Termek).WithMany(p => p.TermekErtekeles)
                .HasForeignKey(d => d.TermekId)
                .HasConstraintName("termek_ertekeles_ibfk_2");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}

//SERVER=sandorkp1mysql.mysql.database.azure.com;PORT=3306;DATABASE=mesa_webshop;USER=sandorkp1;PASSWORD=Adatbazis-2024;SSL MODE=none;"
//"SERVER=192.168.0.80;PORT=3306;DATABASE=mesa_webshop;USER=root;PASSWORD=password;SSL MODE=none;"