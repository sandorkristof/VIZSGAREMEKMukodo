﻿using System;
using System.Collections.Generic;

namespace Webshop_API.Models;

public partial class RendelesAllapot
{
    public int Id { get; set; }

    public string Allapot { get; set; } = null!;

    public virtual ICollection<Rendeles> Rendeles { get; set; } = new List<Rendeles>();
}
