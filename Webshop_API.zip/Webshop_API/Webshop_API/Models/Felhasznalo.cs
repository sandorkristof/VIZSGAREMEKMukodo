﻿using System;
using System.Collections.Generic;

namespace Webshop_API.Models;

public partial class Felhasznalo
{
    public Guid Id { get; set; }

    public string Nev { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string Jelszo { get; set; } = null!;

    public virtual FelhasznaloCim? FelhasznaloCim { get; set; }

    public virtual Kosar? Kosar { get; set; }

    public virtual ICollection<Rendeles> Rendeles { get; set; } = new List<Rendeles>();

    public virtual ICollection<TermekErtekeles> TermekErtekeles { get; set; } = new List<TermekErtekeles>();
}
