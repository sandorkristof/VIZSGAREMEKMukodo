﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Org.BouncyCastle.Crypto;
using Webshop_API.Dtos;
using Webshop_API.Models;

namespace Webshop_API.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class AddressController : ControllerBase
    {
        [HttpGet("getAddress")]
        public ActionResult<IEnumerable<AddressDto>> GetUserAddress(Guid id) 
        {
            try
            {
                using(var dbContext = new MesaWebshopContext())
                {
                    var response = dbContext.FelhasznaloCim.Where(x => x.FelhaszId == id);
                    if (response != null)
                    {
                        var result = new List<AddressDto>();
                        foreach (var item in response)
                        {
                            var placeholder = new AddressDto(item.Id, item.FelhaszId, item.Irsz, item.Telepules, item.Utca, item.Hazszam, item.EmeletAjto);
                            result.Add(placeholder);
                        }
                        return Ok(result);
                    }
                    else
                    {
                        return NotFound("Ehhez a felhasználóhoz nincs hozzáadva cím!");
                    }
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("postAddress")]
        public ActionResult PostAddress(AddressDto addressDto)
        {
            try
            {
                using(var dbContext = new MesaWebshopContext())
                {
                    var newAddress = new FelhasznaloCim()
                    {
                        Id = Guid.NewGuid(),
                        FelhaszId = addressDto.UserId,
                        Irsz = addressDto.PostalCode,
                        Telepules = addressDto.Settlement,
                        Utca = addressDto.Street,
                        Hazszam = addressDto.Number,
                        EmeletAjto = addressDto.Floor_Door
                    };

                    dbContext.FelhasznaloCim.Add(newAddress);
                    dbContext.SaveChanges();

                    return Ok("Cím sikeresen rögzítve");
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("updateAddress")]
        public ActionResult UpdateAddress(Guid id, AddressDto addressDto)
        {
            try
            {
                using(var dbContext = new MesaWebshopContext())
                {
                    var existing = dbContext.FelhasznaloCim.FirstOrDefault(x => x.Id == id);
                    if (existing != null)
                    {
                        existing.FelhaszId = addressDto.UserId;
                        existing.Irsz = addressDto.PostalCode;
                        existing.Telepules = addressDto.Settlement;
                        existing.Utca = addressDto.Street;
                        existing.Hazszam = addressDto.Number;
                        existing.EmeletAjto = addressDto.Floor_Door;

                        dbContext.FelhasznaloCim.Update(existing);
                        dbContext.SaveChanges();

                        return Ok("Sikeres módosítás");
                    }
                    else
                    {
                        return NotFound("Nem található a módosítani kívánt cím!");
                    }
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("deleteAddress")]
        public ActionResult DeleteAddress(Guid id)
        {
            try
            {
                using(var dbContext = new MesaWebshopContext())
                {
                    var existing = dbContext.FelhasznaloCim.FirstOrDefault(x => x.Id == id);
                    if (existing != null)
                    {
                        dbContext.FelhasznaloCim.Remove(existing);
                        dbContext.SaveChanges();

                        return Ok("Sikeres törlés!");
                    }
                    else
                    {
                        return NotFound("Nem található a törölni kívánt cím!");
                    }
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
