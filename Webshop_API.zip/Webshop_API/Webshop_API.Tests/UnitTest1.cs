using Microsoft.AspNetCore.Mvc;
using System;
using Webshop_API.Controllers;
using Webshop_API.Dtos;
using Webshop_API.Models;
using Xunit;

namespace Webshop_API.Tests
{
    public class UnitTest1
    {
        [Fact]
        public void UserControllerTest()
        {
            var controller = new UserController();

            var actionResult = controller.Get();
            var result = actionResult.Result as OkObjectResult;
            var returnUsers = result.Value as IEnumerable<Felhasznalo>;

            Assert.Equal(4, returnUsers.Count());
        }

        [Fact]
        public void UserControllerTest2() 
        {
            var controller = new UserController();
            LoginDto login = new LoginDto("mecseip@kkszki.hu", "string");
            var actionResult = controller.Login(login);

            var result = actionResult.Result as OkObjectResult;

            Assert.NotNull(result);
        }

        [Fact]
        public async void ProductControllerTest()
        {
            var controller = new ProductController();

            var actionResult = await controller.GetAll();
            var result = actionResult.Result as OkObjectResult;

            var returnProducts = result.Value as List<ProductDto>;

            Assert.Equal(8, returnProducts.Count());
        }
    }
}