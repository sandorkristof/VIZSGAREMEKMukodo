import React, { useState } from 'react'
import { Link,Route,Routes } from "react-router-dom";
import './Bejelentkezesellenorzes'


export default function Bejelentkezes() {
 
  return (
    <div className='d-flex justify-content-center align-items-center bg-white vh-100'>
      <div className='bg-white p-3 rounded w-25 border'>
      <h2>Bejelentkezés</h2>
        <form action="" >
          <div className='mb-3'>
            <label htmlFor="email"><strong>Email </strong></label>
            <input type="email" placeholder='Írj ide e-mail címet' className='form-control rounded-2'  name='email'/>
          </div>
          <div className='mb-3'>
            <label htmlFor="password"><strong>Password</strong></label>
            <input type="password" placeholder='Írj ide jelszót' className='form-control rounded-2' name='password'/>

          </div>
          <button style={{marginBottom:'30px'}} type='submit' className='btn btn-success w-100 rounded-2'><strong>Bejelentkezés</strong></button>

        
          <Link to='/Regisztracio'  className='btn btn-default border w-100 bg-primary rounded-2 text-decoration-none text-white'>Csinálj fiókot</Link>
        </form>
      </div>
    </div>
  )
}
