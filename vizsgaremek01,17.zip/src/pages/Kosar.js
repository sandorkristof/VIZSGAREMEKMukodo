import React from 'react'

export default function Kosar() {
  let kosar=[
    {TermekId:123,TermekNev:"LG",Darab:2},
    {TermekId:200,TermekNev:"Asus",Darab:10},
  ];
  localStorage.setItem("kosarTartalma",JSON.stringify(kosar));
  console.log(JSON.parse(localStorage.getItem("kosarTartalma")));
  return (
    <div>

      <div class="container">
        <h1>Kosár</h1>
        <ul id="product-list" class="list-group">
        </ul>

        <button id="purchase-btn" class="btn btn-primary mt-3">Vásárlás</button>
      </div>





    </div>
  )
}
