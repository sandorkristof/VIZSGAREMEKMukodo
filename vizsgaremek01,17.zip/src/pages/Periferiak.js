import React from 'react'
import { Link,Route,Routes } from "react-router-dom";
import Monitor from '../image/monitor.png'
import Fejhallgato from '../image/headset.png'
import Eger from '../image/mouse.png'
import Bill from '../image/keyboard.png'
import Szek from '../image/gaming-chair.png'
import Mousepad from '../image/mousepad.png'


export default function Periferiak() {
  return (
   <div>
            <div className=''>
            <div style={{marginTop:'30px'}} class="container">
        <div  class="row justify-content-center">
        <Link class="col-sm-2 shadow border me-3 mb-3" to="/Monitorok" style={{textDecoration:'none'}}>
            <img src={Monitor} alt="image1" class="img-fluid rounded" />
            <div style={{marginBottom:'3px',fontSize:'20px'}} class="font-weight-bold text-uppercase text-dark">Monitorok</div>
          </Link>
          <Link class="col-sm-2 shadow border me-3 mb-3" to="/Fejhallgatók" style={{textDecoration:'none'}}>
            <img src={Fejhallgato} alt="image2" class="img-fluid rounded"/>
            <div style={{marginBottom:'3px',fontSize:'20px'}} class="font-weight-bold text-uppercase text-dark">Fejhallgatok</div>
          </Link>
          <Link class="col-sm-2 shadow border me-3 mb-3" to="/Egerek" style={{textDecoration:'none'}}>
            <img src={Eger} alt="image3" class="img-fluid rounded"/>
            <div style={{marginBottom:'3px',fontSize:'20px'}} class="font-weight-bold text-uppercase text-dark">Egerek</div>
          </Link>
          </div>
          <div class="row justify-content-center">
          <Link class="col-sm-2 shadow border me-3 mb-3" to="/Billentyűzetek" style={{textDecoration:'none'}}>
              <img src={Bill} alt="image4" class="img-fluid rounded"/>
              <div style={{marginBottom:'3px',fontSize:'20px'}} class="font-weight-bold text-uppercase text-dark">Billentyűzetek</div>
          </Link>
          <Link class="col-sm-2 shadow border me-3 mb-3" to="/Székek" style={{textDecoration:'none'}}>
              <img src={Szek} alt="image5" class="img-fluid rounded"/>
              <div style={{marginBottom:'3px',fontSize:'20px'}} class="font-weight-bold text-uppercase text-dark">Székek</div>
          </Link>
          <Link class="col-sm-2 shadow border me-3 mb-3" to="/Egérpadok" style={{textDecoration:'none'}}>
              <img src={Mousepad} alt="image6" class="img-fluid rounded"/>
              <div style={{marginBottom:'3px',fontSize:'20px'}} class="font-weight-bold text-uppercase text-dark">Egérpadok</div>
          </Link>
        </div>
      </div>
      </div>
    </div>
  )
}
