﻿namespace Webshop_API.Dtos
{
    public record LoginDto(string Email, string Password);
    public record RegisterDto(string Name, string Email, string Password);
    public record UpdateDto(string Name, string OldPassword, string NewPassword);

}
